"""Build the content manifest; no dependencies or downloads. Run after source edits."""
import hashlib,json
from pathlib import Path

def build(root=None):
    root=Path(root or Path(__file__).resolve().parent)
    files=[p for p in (root/'app').rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc']
    files += [root/n for n in ('Installer.ps1','Lancer.ps1','StartupTools.ps1','ReparerStudio.ps1','ReparerModeles.ps1','1_CLIC_TOUT_BAZOR.cmd','BAZOR_DEMARRAGE_VISIBLE.cmd','DEMARRER.cmd','LANCER.cmd','REPARER_STUDIO.cmd','REPARER_MODELES.cmd','BAZOR_INSTALL_EXTENSIONS.cmd','Installer_Extensions_BAZOR.ps1','BAZOR_EXTENSIONS.json','RECHERCHE_QUALITE_IA_2026.md','README.md','LIRE_MOI.html','CORRECTIF_DEMARRAGE.md','RELEASE_NOTES_V3_0_1.md','RELEASE_NOTES_V3_0_2_DEBUG.md','RELEASE_NOTES_V3_0_3_ELEVATION_DEBUG.md','RELEASE_NOTES_V3_0_4_AUTOPILOT_CDP.md','RELEASE_NOTES_V3_0_5_PLAYWRIGHT_INSTALL.md','build_release.py')]
    hashes={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
    build_id=hashlib.sha256(json.dumps(hashes,sort_keys=True).encode()).hexdigest()
    release=dict(version='3.0.5',build_id=build_id,files=hashes)
    (root/'release.json').write_text(json.dumps(release,indent=2,ensure_ascii=True)+'\n')
    return release

if __name__=='__main__':print(json.dumps(build(),indent=2))
