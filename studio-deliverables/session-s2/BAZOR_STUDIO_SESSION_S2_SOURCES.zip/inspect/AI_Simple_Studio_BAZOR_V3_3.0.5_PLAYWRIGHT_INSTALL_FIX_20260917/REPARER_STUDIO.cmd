@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
title BAZOR AI Studio V3 - Outil de reparation
echo.
echo === OUTIL DE REPARATION DE BAZOR AI STUDIO V3 (3.0.5) ===
echo Il demande automatiquement les droits necessaires et conserve ComfyUI.
echo.
if not exist "%~dp0ReparerStudio.ps1" goto incomplete
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0ReparerStudio.ps1" -AIRoot "C:\AI"
if errorlevel 1 goto failed
echo.
echo Reparation terminee. Cette fenetre reste ouverte pour le diagnostic.
pause
exit /b 0
:incomplete
echo DOSSIER INCOMPLET. Extraire tout le ZIP avant de relancer cet outil.
goto failed
:failed
echo.
echo LA REPARATION N'A PAS ABOUTI.
echo Journal : C:\AI\SimpleStudioV2\logs\installation.log
pause
exit /b 1
