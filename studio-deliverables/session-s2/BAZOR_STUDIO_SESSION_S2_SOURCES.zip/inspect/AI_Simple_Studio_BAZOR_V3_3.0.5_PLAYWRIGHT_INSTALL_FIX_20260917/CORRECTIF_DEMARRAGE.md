# V3 (3.0.3) : ancienne version relancée au lancement

1. Télécharge le ZIP BAZOR AI Studio V3 (3.0.3).
2. Clic droit → Extraire tout. Ouvre le nouveau dossier extrait.
3. Double-clique sur DEMARRER.cmd. L’outil demande automatiquement l’élévation Windows si l’ancienne instance a été lancée en administrateur. La mise à jour s’installe dans C:\AI\SimpleStudioV2 et met à jour le raccourci du Bureau.

Si le processus affiché dans le journal refuse encore de s’arrêter, double-clique sur REPARER_STUDIO.cmd. Cet outil vérifie le dossier exact, demande les droits administrateur, revalide le PID et utilise taskkill /PID /T /F uniquement sur l’arbre du Studio identifié. Il conserve ComfyUI et les données, puis relance l’installation. Il n’est plus nécessaire de saisir manuellement taskkill, cd ou DEMARRER.cmd depuis C:\Windows\System32.

Le message « Aucun checkpoint installé » concerne le modèle image, pas Wan. Double-cliquer sur REPARER_MODELES.cmd pour importer un checkpoint Forge valide ou installer automatiquement SDXL officiel (6,94 Go), puis cliquer sur Actualiser les modèles.

Le studio, son ancien historique et les modèles sont conservés. Aucun changement n’est apporté au fichier ._pth du Python portable de ComfyUI.

Défaut reproduit et corrigé : en mode Python isolé, l’import du module workflows situé à côté de studio.py échouait. Le studio ajoute désormais son propre dossier à sa recherche de modules.

Le lancement affiche cinq étapes. Le navigateur s’ouvre dès que le studio répond. Si une étape échoue, la fenêtre reste ouverte avec le détail à photographier ou copier.

Journal : C:\AI\SimpleStudioV2\logs\lancement.log
Contrôle Python : C:\AI\SimpleStudioV2\logs\controle-python.err.log

Les tests ont confirmé le démarrage HTTP réel en Python isolé, y compris sans moteur ComfyUI actif. Le lancement PowerShell et l’état de la machine Windows ne peuvent pas être confirmés depuis cet environnement.


## Pourquoi la capture affichait encore 2.0.1

Le lanceur 2.0.1/2.1.0 vérifiait uniquement le nom de l’application sur le port mémorisé. Une ancienne instance saine pouvait donc être considérée comme la bonne et son interface restait affichée. La V3 (3.0.3) vérifie maintenant la version, une empreinte de livraison et le dossier exact. Elle ignore les anciennes instances, arrête uniquement les processus Studio du dossier cible pendant l’installation, puis ouvre le navigateur après confirmation.
