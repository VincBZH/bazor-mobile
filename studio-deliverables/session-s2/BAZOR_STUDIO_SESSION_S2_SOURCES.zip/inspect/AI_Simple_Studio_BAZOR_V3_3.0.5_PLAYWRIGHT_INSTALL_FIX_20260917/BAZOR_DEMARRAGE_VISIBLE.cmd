@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul
title BAZOR V3 - Diagnostic visible
echo.
echo ============================================================
echo   BAZOR AI STUDIO V3 - DEMARRAGE VISIBLE
echo ============================================================
echo.
set "ROOT=%~dp0"
if exist "%ROOT%DEMARRER.cmd" goto root_found
set "FALLBACK="
for /r "%~dp0" %%F in (DEMARRER.cmd) do (
  if not defined FALLBACK set "FALLBACK=%%~dpF"
  echo %%~dpF| findstr /I "BAZOR V3" >nul && (
    set "ROOT=%%~dpF"
    goto root_found
  )
)
if defined FALLBACK set "ROOT=!FALLBACK!"
if not exist "%ROOT%DEMARRER.cmd" (
  echo DEMARRER.cmd introuvable depuis : %~dp0
  echo Place ce fichier dans le dossier extrait complet.
  goto end
)
:root_found
cd /d "%ROOT%"
echo Dossier utilise : %ROOT%
echo.
echo Lancement du demarrage verifie. Cette fenetre restera ouverte.
echo.
call "%ROOT%DEMARRER.cmd"
set "CODE=!errorlevel!"
echo.
echo ============================================================
echo CODE DE RETOUR : !CODE!
echo ============================================================
echo.
if exist "%ROOT%logs\lancement.log" echo Journal Studio : %ROOT%logs\lancement.log
if exist "C:\AI\SimpleStudioV2\logs\lancement.log" echo Journal installe : C:\AI\SimpleStudioV2\logs\lancement.log
if exist "C:\AI\SimpleStudioV2\logs\controle-python.err.log" echo Controle Python : C:\AI\SimpleStudioV2\logs\controle-python.err.log
echo.
if not "!CODE!"=="0" echo Le demarrage a retourne un code non nul. La fenetre reste ouverte pour lire le detail.
:end
echo.
pause
exit /b 0
