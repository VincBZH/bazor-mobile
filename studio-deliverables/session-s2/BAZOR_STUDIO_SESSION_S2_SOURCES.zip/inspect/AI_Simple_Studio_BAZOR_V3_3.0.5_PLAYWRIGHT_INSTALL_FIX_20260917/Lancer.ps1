﻿param([string]$AIRoot='C:\AI')
$ErrorActionPreference='Stop'
$held=$false
$mutex=$null
$transcript=$false
$studio=$PSScriptRoot
$logs=Join-Path $studio 'logs'
. (Join-Path $studio 'StartupTools.ps1')
function Stage([string]$text) {Write-Host ('['+(Get-Date -Format 'HH:mm:ss')+'] '+$text) -ForegroundColor Cyan}
function Api([string]$url) {
  $response=$null
  try {
    $req=[System.Net.HttpWebRequest]::Create($url)
    $req.Proxy=$null
    $req.Timeout=900
    $req.ReadWriteTimeout=900
    $response=$req.GetResponse()
    $reader=New-Object System.IO.StreamReader($response.GetResponseStream())
    try {return ($reader.ReadToEnd() | ConvertFrom-Json)} finally {$reader.Dispose()}
  } catch {return $null} finally {if($response){$response.Dispose()}}
}
function Busy([int]$port) {
  $tcp=New-Object System.Net.Sockets.TcpClient
  try {
    $async=$tcp.BeginConnect('127.0.0.1',$port,$null,$null)
    if(-not $async.AsyncWaitHandle.WaitOne(180)){return $false}
    $tcp.EndConnect($async)
    return $true
  } catch {return $false} finally {$tcp.Close()}
}
try {
  Stage '1/5 - Preparation du demarrage et du journal...'
  New-Item -ItemType Directory -Path $logs -Force | Out-Null
  New-Item -ItemType Directory -Path (Join-Path $studio 'data') -Force | Out-Null
  try {Start-Transcript -LiteralPath (Join-Path $logs 'lancement.log') -Append -Force | Out-Null;$transcript=$true} catch {}
  $mutex=New-Object System.Threading.Mutex($false,'Local\AI_Simple_Studio_V2_Launch')
  try {$held=$mutex.WaitOne(0)} catch [System.Threading.AbandonedMutexException] {$held=$true}
  if(-not $held){throw 'Un autre lancement est encore actif. Attends sa fin puis relance ce raccourci.'}
  $release=Read-StudioRelease $studio
  $verified=Assert-StudioFiles $studio $release
  Stage ('Livraison '+$release.version+' : '+$verified+' fichiers verifies.')
  $env:AI_ROOT=$AIRoot
  $portable=Join-Path $AIRoot 'ComfyUI\ComfyUI_windows_portable'
  $python=Join-Path $portable 'python_embeded\python.exe'
  if(-not (Test-Path -LiteralPath $python)) {
    Stage 'Recherche du Python portable sous ComfyUI...'
    $candidates=@(Get-ChildItem (Join-Path $AIRoot 'ComfyUI') -Filter 'python.exe' -Recurse -File -ErrorAction SilentlyContinue | Where-Object {$_.FullName -match 'python_embeded'})
    if($candidates.Count -eq 0){throw ('Python portable ComfyUI introuvable sous '+$AIRoot+'\ComfyUI.')}
    $python=$candidates[0].FullName;$portable=Split-Path (Split-Path $python)
  }
  Stage ('2/5 - Controle des fichiers avec '+$python)
  $probeOut=Join-Path $logs 'controle-python.out.log'
  $probeErr=Join-Path $logs 'controle-python.err.log'
  $probeArgs='"'+(Join-Path $studio 'app\check_startup.py')+'"'
  $probe=New-Object System.Diagnostics.Process
  $probe.StartInfo.FileName=$python
  $probe.StartInfo.Arguments=$probeArgs
  $probe.StartInfo.WorkingDirectory=$studio
  $probe.StartInfo.UseShellExecute=$false
  $probe.StartInfo.CreateNoWindow=$true
  $probe.StartInfo.RedirectStandardOutput=$true
  $probe.StartInfo.RedirectStandardError=$true
  try {
    if(-not $probe.Start()){throw 'Le controle Python n''a pas pu etre lance.'}
    $outTask=$probe.StandardOutput.ReadToEndAsync()
    $errTask=$probe.StandardError.ReadToEndAsync()
    if(-not $probe.WaitForExit(20000)) {
      $probe.Kill()
      throw 'Le controle des imports Python ne repond pas apres 20 secondes.'
    }
    $probeCode=$probe.ExitCode
    $probeText=$outTask.GetAwaiter().GetResult()
    $probeErrors=$errTask.GetAwaiter().GetResult()
    Set-Content -LiteralPath $probeOut -Value $probeText -Encoding UTF8
    Set-Content -LiteralPath $probeErr -Value $probeErrors -Encoding UTF8
    if($probeCode -ne 0) {throw ('Le controle Python a echoue :'+[Environment]::NewLine+$probeErrors)}
    $probeResult=$probeText | ConvertFrom-Json
    if(-not $probeResult.ok -or $probeResult.version -ne $release.version -or $probeResult.build_id -ne $release.build_id){throw 'Le Python ne charge pas la livraison attendue. Relance DEMARRER.cmd.'}
    $expected=$probeResult
    Write-Host ('Fichiers OK - version '+$probeResult.version+' - Python '+$probeResult.python) -ForegroundColor Green
  } finally {$probe.Dispose()}
  Stage '3/5 - Recherche rapide de l''interface locale...'
  $port=0
  $candidates=@(8190..8199)
  $portFile=Join-Path $studio 'data\port.txt'
  if(Test-Path $portFile) {
    $cached=0
    if([int]::TryParse((Get-Content $portFile -Raw).Trim(),[ref]$cached) -and $cached -ge 8190 -and $cached -le 8199) {
      $candidates=@($cached)+@(8190..8199 | Where-Object {$_ -ne $cached})
    }
  }
  $selection=Select-StudioPort $candidates $expected
  foreach($other in $selection.ignored) {Stage ('Ancienne interface ignoree : port '+$other.port+', version '+$other.version)}
  $port=$selection.port
  if($port -eq 0){throw 'Tous les ports 8190 a 8199 sont occupes.'}
  $url="http://127.0.0.1:$port"
  if(-not $selection.attached) {
    Stage ('Lancement de l''interface sur le port '+$port+'...')
    $stop=Join-Path $studio 'stop.flag';if(Test-Path $stop){Remove-Item $stop}
    $arguments='"'+(Join-Path $studio 'app\watchdog.py')+'" --port '+$port+' --legacy "'+(Join-Path $AIRoot 'SimpleStudio')+'"'
    Start-Process -FilePath $python -ArgumentList $arguments -WorkingDirectory $studio -WindowStyle Hidden
    $ready=$false
    $clock=[Diagnostics.Stopwatch]::StartNew()
    $lastNotice=-5
    while($clock.Elapsed.TotalSeconds -lt 35) {
      if(Busy $port) {
        $ping=Api "$url/api/ping"
        if(Test-StudioIdentity $ping $expected){$ready=$true;break}
        if($ping -and $ping.app -eq 'ai-simple-studio-v2'){throw ('Le port '+$port+' repond avec la mauvaise version '+$ping.version+'. Le navigateur ne sera pas ouvert.')}
      }
      if($clock.Elapsed.TotalSeconds - $lastNotice -ge 5) {
        Stage ('Attente de l''interface : '+[int]$clock.Elapsed.TotalSeconds+' s / 35 s...')
        $lastNotice=$clock.Elapsed.TotalSeconds
      }
      Start-Sleep -Milliseconds 350
    }
    if(-not $ready) {
      $watchlog=Join-Path $logs 'watchdog.log'
      if(Test-Path $watchlog){Get-Content $watchlog -Tail 22 | ForEach-Object {Write-Host $_}}
      throw ('L''interface ne repond pas. Journal : '+$watchlog)
    }
  }
  $confirmed=Api "$url/api/ping"
  if(-not (Test-StudioIdentity $confirmed $expected)){throw 'La version active ne correspond pas aux fichiers installes. Ouverture du navigateur annulee.'}
  @{expected_version=$expected.version;observed=$confirmed;ignored_instances=$selection.ignored;url=$url;checked_at=(Get-Date -Format o)} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $logs 'verification-version.json') -Encoding UTF8
  Set-Content -LiteralPath $portFile -Value $port -Encoding ASCII
  # Open the browser immediately; do not mistake a console window for the app.
  Stage ('4/5 - Ouverture du navigateur : '+$url)
  $browserUrl=$url+'/?studio_version='+$expected.version+'&build='+$expected.build_id.Substring(0,12)
  Start-Process -FilePath $browserUrl
  Write-Host ('VERSION '+$expected.version+' VERIFIEE ET OUVERTE : '+$url) -ForegroundColor Green
  Stage '5/5 - Verification de ComfyUI, sans redemarrer une instance active...'
  $comfy=Api 'http://127.0.0.1:8188/system_stats'
  if($comfy) {Write-Host 'TOUT EST PRET : interface ouverte et ComfyUI connecte.' -ForegroundColor Green}
  elseif(Busy 8188) {Write-Host 'Le port 8188 est occupe. Le studio reste ouvert ; voir Diagnostic.' -ForegroundColor Yellow}
  else {
    try {
      $starting=@(Get-CimInstance Win32_Process -OperationTimeoutSec 3 -ErrorAction Stop | Where-Object {
        $_.CommandLine -and ($_.CommandLine -match 'main\.py' -or $_.CommandLine -match 'run_nvidia_gpu\.bat')
      })
      if($starting.Count -eq 0) {
        $mainFile=Join-Path $portable 'ComfyUI\main.py'
        if(-not (Test-Path -LiteralPath $mainFile)){throw 'ComfyUI\main.py introuvable.'}
        $engineArgs='-s "'+$mainFile+'" --windows-standalone-build --listen 127.0.0.1 --port 8188'
        $stamp=Get-Date -Format 'yyyyMMdd-HHmmss-fff'
        Start-Process -FilePath $python -ArgumentList $engineArgs -WorkingDirectory $portable -WindowStyle Hidden -RedirectStandardOutput (Join-Path $logs "comfy-$stamp.out.log") -RedirectStandardError (Join-Path $logs "comfy-$stamp.err.log")
        Write-Host 'ComfyUI est en cours de demarrage. Sa connexion apparaitra dans le studio.' -ForegroundColor Green
      } else {Write-Host 'Un moteur semble deja en cours de lancement : aucune seconde instance creee.' -ForegroundColor Yellow}
    } catch {
      Write-Host ('Le studio est ouvert, mais ComfyUI demande une verification : '+$_.Exception.Message) -ForegroundColor Yellow
      Write-Host 'Ouvre au besoin ton raccourci NVIDIA existant, puis clique sur Verifier dans le studio.'
    }
  }
} catch {
  Write-Host ''
  Write-Host ('DEMARRAGE INTERROMPU : '+$_.Exception.Message) -ForegroundColor Red
  Write-Host ('Journal a transmettre : '+(Join-Path $logs 'lancement.log')) -ForegroundColor Yellow
  Read-Host 'Appuyez sur Entree pour fermer cette fenetre'
  exit 1
} finally {
  if($held -and $mutex){$mutex.ReleaseMutex()}
  if($mutex){$mutex.Dispose()}
  if($transcript){try{Stop-Transcript | Out-Null}catch{}}
}
