@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
title BAZOR AI Studio V3 - Installation verifiee
echo.
echo === BAZOR AI STUDIO V3 (3.0.5) : INSTALLATION ET DEMARRAGE ===
echo Les etapes vont s'afficher ci-dessous.
echo.
if not exist "%~dp0Installer.ps1" goto incomplete
if not exist "%~dp0ReparerStudio.ps1" goto incomplete
if not exist "%~dp0app\check_startup.py" goto incomplete
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0ReparerStudio.ps1" -AIRoot "C:\AI"
if errorlevel 1 goto failed
echo.
echo Demarrage termine. Cette fenetre reste ouverte pour le diagnostic.
pause
exit /b 0
:incomplete
echo DOSSIER INCOMPLET. Clic droit sur le ZIP puis EXTRAIRE TOUT.
echo Ouvre ensuite le dossier extrait et relance DEMARRER.cmd.
:failed
echo.
echo LE DEMARRAGE N'A PAS ABOUTI. Copie ou photographie le message ci-dessus.
echo Journal : C:\AI\SimpleStudioV2\logs\lancement.log
echo.
pause
exit /b 1
