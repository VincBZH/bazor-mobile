# BAZOR AI Studio V3 · 3.0.1

Correctif de sortie et d’analyse vidéo.

- Masquage des images fixes auxiliaires lorsqu’une tâche vidéo fournit aussi
  une sortie vidéo. Les fichiers ComfyUI originaux ne sont pas supprimés.
- Conversion effective des workflows H3 au format interface avant patch des
  nœuds et des références.
- Analyse vidéo vérifiée avec extraction du premier et du dernier plan.
- Lecture des rapports JSON Ollama stricts, clôturés par Markdown ou enveloppés
  dans un objet `report`.
- Une réponse Ollama non structurée est affichée comme « à vérifier » et ne
  lance pas de correction automatique.

La cible d’installation reste `C:\AI\SimpleStudioV2`, Studio sur le port
disponible `8190–8199` (8191 habituel), ComfyUI sur `8188`. Les consoles de
lancement restent visibles en cas d’erreur.
