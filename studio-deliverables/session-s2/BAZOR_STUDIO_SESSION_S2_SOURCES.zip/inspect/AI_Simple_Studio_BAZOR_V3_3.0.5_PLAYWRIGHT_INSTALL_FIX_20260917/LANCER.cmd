@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
title Verification et ouverture du studio
echo.
echo === OUVERTURE DE BAZOR AI STUDIO V3 (3.0.5) ===
echo.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Lancer.ps1"
if errorlevel 1 (
  echo.
  echo LE DEMARRAGE N'A PAS ABOUTI. Copie ou photographie le message ci-dessus.
  echo Journal : C:\AI\SimpleStudioV2\logs\lancement.log
  echo.
  pause
  exit /b 1
)
echo.
echo Demarrage termine. Cette fenetre reste ouverte pour le diagnostic.
pause
exit /b 0
