﻿param([string]$AIRoot='C:\AI')
$ErrorActionPreference='Stop'
$transcript=$false;$held=$false;$mutex=$null
$target=Join-Path $AIRoot 'SimpleStudioV2'
$source=$PSScriptRoot

function Invoke-PythonCommand([string]$Python,[string[]]$Arguments) {
  # Native Python writes import/pip failures to stderr. With PowerShell's
  # Stop preference, allowing that stream to escape can abort the installer.
  # Capture both streams and return an explicit exit code instead.
  $previous=$ErrorActionPreference
  $code=1
  $output=@()
  try {
    $ErrorActionPreference='Continue'
    $output=@(& $Python @Arguments 2>&1)
    $code=if($null -ne $LASTEXITCODE){[int]$LASTEXITCODE}else{1}
  } catch {
    $output+=@($_.Exception.Message)
    $code=1
  } finally {$ErrorActionPreference=$previous}
  return @{Code=$code;Output=$output}
}

try {
  . (Join-Path $source 'StartupTools.ps1')
  $release=Read-StudioRelease $source
  Write-Host '=== INSTALLATION VERIFIEE : BAZOR AI STUDIO V3 (3.0.5) ===' -ForegroundColor Cyan
  Write-Host ('Source : '+$source)
  Write-Host ('Destination : '+$target)
  $verified=Assert-StudioFiles $source $release
  New-Item -ItemType Directory -Path (Join-Path $target 'logs') -Force | Out-Null
  try {Start-Transcript -LiteralPath (Join-Path $target 'logs\installation.log') -Append -Force | Out-Null;$transcript=$true} catch {}
  Write-Host ('Source confirmee : version '+$release.version+', '+$verified+' fichiers, '+$source) -ForegroundColor Green
  $mutex=New-Object System.Threading.Mutex($false,'Local\AI_Simple_Studio_V2_Update')
  try {$held=$mutex.WaitOne(0)} catch [System.Threading.AbandonedMutexException] {$held=$true}
  if(-not $held){throw 'Une autre installation du Studio est en cours.'}
  $same=[IO.Path]::GetFullPath($source).TrimEnd('\','/') -eq [IO.Path]::GetFullPath($target).TrimEnd('\','/')
  Write-Host '[INSTALLATION] Fermeture des processus du Studio installe...' -ForegroundColor Cyan
  $stopped=@(Stop-InstalledStudio $target)
  foreach($item in $stopped){Write-Host ('Processus Studio ferme : '+$item.script+', PID '+$item.pid)}
  if(-not $same) {
    if(Test-Path -LiteralPath (Join-Path $target 'app')) {
      $backup=Join-Path $target ('backups\app-'+(Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
      New-Item -ItemType Directory -Path (Split-Path $backup) -Force | Out-Null
      Copy-Item -LiteralPath (Join-Path $target 'app') -Destination $backup -Recurse
    }
    Write-Host '[INSTALLATION] Copie vers les chemins exacts et verification SHA-256...' -ForegroundColor Cyan
    $verified=Copy-StudioRelease $source $target $release
  } else {$verified=Assert-StudioFiles $target $release}
  foreach($name in @('SHA256SUMS.txt','VERIFICATION.json','SOURCES.md')) {
    if(-not $same -and (Test-Path -LiteralPath (Join-Path $source $name))) {Copy-Item -LiteralPath (Join-Path $source $name) -Destination (Join-Path $target $name) -Force}
  }
  @{version=$release.version;build_id=$release.build_id;source=$source;target=$target;verified_files=$verified;stopped_processes=$stopped;installed_at=(Get-Date -Format o)} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $target 'logs\installation-verifiee.json') -Encoding UTF8
  Write-Host ('INSTALLATION '+$release.version+' VERIFIEE : '+$verified+' fichiers conformes.') -ForegroundColor Green
  $autopilotPython=Join-Path $AIRoot 'ComfyUI\ComfyUI_windows_portable\python_embeded\python.exe'
  if(-not (Test-Path -LiteralPath $autopilotPython)) {
    $pythonCandidates=@(Get-ChildItem (Join-Path $AIRoot 'ComfyUI') -Filter 'python.exe' -Recurse -File -ErrorAction SilentlyContinue | Where-Object {$_.FullName -match 'python_embeded'})
    if($pythonCandidates.Count -gt 0){$autopilotPython=$pythonCandidates[0].FullName}
  }
  if(Test-Path -LiteralPath $autopilotPython) {
    Write-Host '[INSTALLATION] Verification du pont Playwright pour Autopilot CDP...' -ForegroundColor Cyan
    $playwrightProbe=Invoke-PythonCommand $autopilotPython @('-c','import playwright')
    if($playwrightProbe.Code -ne 0) {
      Write-Host '[INSTALLATION] Playwright absent : installation dans le Python ComfyUI...' -ForegroundColor Cyan
      $playwrightInstall=Invoke-PythonCommand $autopilotPython @('-m','pip','install','--disable-pip-version-check','playwright')
      if($playwrightInstall.Code -ne 0) {
        Write-Host '[AVERTISSEMENT] Playwright n''a pas pu etre installe. Le Studio restera utilisable, mais Autopilot CDP sera indisponible.' -ForegroundColor Yellow
        @($playwrightInstall.Output | Select-Object -Last 12) | ForEach-Object {Write-Host ('  '+$_) -ForegroundColor DarkYellow}
      } else {Write-Host '[INSTALLATION] Playwright installe.' -ForegroundColor Green}
    } else {Write-Host '[INSTALLATION] Playwright deja disponible.' -ForegroundColor Green}
  } else {Write-Host '[AVERTISSEMENT] Python ComfyUI introuvable : installation Playwright ignoree.' -ForegroundColor Yellow}
  try {
    $shell=New-Object -ComObject WScript.Shell
    $shortcut=$shell.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) 'AI Simple Studio 2.lnk'))
    $shortcut.TargetPath=$env:ComSpec
    $shortcut.Arguments='/d /c ""'+(Join-Path $target 'LANCER.cmd')+'""'
    $shortcut.WorkingDirectory=$target;$shortcut.WindowStyle=1
    $shortcut.Description='BAZOR AI Studio V3 (3.0.5) - version verifiee avant ouverture'
    $shortcut.Save()
  } catch {Write-Host ('Raccourci non cree : '+$_.Exception.Message+'. Utiliser LANCER.cmd dans le dossier installe.') -ForegroundColor Yellow}
  if($transcript){Stop-Transcript | Out-Null;$transcript=$false}
  # A PowerShell script invoked with & does not have to set LASTEXITCODE.
  # An empty value was previously rendered as a false "code ." failure even
  # though Lancer.ps1 had already opened the verified Studio.
  $global:LASTEXITCODE=0
  & (Join-Path $target 'Lancer.ps1') -AIRoot $AIRoot
  $launchCode=if($LASTEXITCODE -is [int]){[int]$LASTEXITCODE}else{0}
  if($launchCode -ne 0){throw ('Le lancement du Studio a retourne le code '+$launchCode+'.')}
} catch {
  Write-Host ('INSTALLATION INTERROMPUE : '+$_.Exception.Message) -ForegroundColor Red
  Write-Host ('Journal : '+(Join-Path $target 'logs\installation.log')) -ForegroundColor Yellow
  Read-Host 'Appuyez sur Entree pour fermer cette fenetre'
  exit 1
} finally {
  if($held -and $mutex){$mutex.ReleaseMutex()}
  if($mutex){$mutex.Dispose()}
  if($transcript){try{Stop-Transcript | Out-Null}catch{}}
}
