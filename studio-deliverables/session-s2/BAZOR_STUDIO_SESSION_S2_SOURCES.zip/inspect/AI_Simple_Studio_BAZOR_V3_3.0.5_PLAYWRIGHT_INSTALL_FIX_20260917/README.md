# BAZOR AI Studio V3 · 3.0.5

## Livraison V3 ultra-compatible MiniMax H3 / I2V

Cette livraison est la V3 runtime `3.0.5`. Elle conserve le chemin d’installation
et les données existants pour rester compatible avec l’environnement local, mais ajoute un correctif de routage : le
Studio identifie les nœuds MiniMax H3 présents dans ComfyUI et utilise le
workflow H3 enregistré localement. Une demande I2V ne peut plus être envoyée
par erreur dans le graphe FL2V Wan.

Pour une photo unique, les nœuds `First frame` et `Last frame` d’un workflow
H3 sont alimentés avec la même image importée. Les anciens noms
`first_frame.png` et `last_frame.png` ne sont donc plus utilisés. La largeur,
la hauteur, le nombre d’images, les étapes, la graine et le préfixe de sortie
sont patchés dans le graphe converti sans modifier le modèle, le VAE, la
projection ou les réglages d’accélération.

## Correctifs de la V3 · 3.0.5

- Une génération vidéo n’affiche plus une photo PNG auxiliaire avant le film :
  la galerie expose uniquement les sorties vidéo du mode vidéo. La photo
  auxiliaire reste dans la sortie ComfyUI pour éviter toute suppression de
  données ; elle est simplement masquée dans le Studio.
- Les workflows H3 enregistrés au format interface (`nodes`) sont maintenant
  convertis avant le raccordement des paramètres, comme les workflows API.
- Le contrôle vidéo extrait une image du début et une image de fin quand elles
  sont disponibles. Le rapport Ollama accepte aussi le JSON entouré de balises
  Markdown ; une réponse non structurée est signalée sans déclencher de
  fausse régénération automatique.
- Le bouton **Envoyer le log à GPT (ZIP)** est disponible dans **Système**.
  Le fichier local `logs\studio-debug.jsonl` conserve les clics, l’état après
  chaque clic, les appels/réponses API et les erreurs ; le ZIP doit ensuite
  être joint manuellement au message GPT.
- Le panneau **Autopilot Chrome / CDP** de **Système** s’attache à Chrome normal
  sur `127.0.0.1:9223`, sans fermer le navigateur ni supprimer le profil
  `C:\BAZOR_EXPORT_AUTOPILOT\chrome_profile`. Le bouton de test du profil
  tente d’abord `locator.click(force=True)`, puis utilise `page.evaluate` pour
  neutraliser temporairement les événements du parent `overflow-x-clip`, cliquer
  le bouton `[data-testid="accounts-profile-button"]` et restaurer exactement
  son style inline. Playwright est installé automatiquement dans le Python
  portable de ComfyUI par `Installer.ps1` quand ce Python est disponible.
- **Galerie** permet de retirer une création terminée et **Prompts** permet de
  retirer un prompt enregistré. Ces actions retirent les entrées du Studio,
  mais conservent les fichiers sources dans ComfyUI.
- Le registre de modèles est recoupé avec les checkpoints validés sur disque.
  Si un checkpoint image existe déjà, l’installation SDXL n’est plus proposée.
- Les choix **Debout** et **Corps entier** sont injectés dans le graphe côté
  serveur et imposent les contraintes de cadrage correspondantes.
- Si l’ancienne instance du Studio est encore active avec des droits élevés,
  le réparateur demande automatiquement l’élévation Windows, revalide le PID
  et utilise un arrêt forcé ciblé avant la copie. Il ne touche jamais
  ComfyUI, Wan, Forge, Ollama ni les données ; si Windows refuse encore, la
  copie est annulée et le détail de taskkill est conservé dans le journal.

La file locale est limitée à deux tâches en attente pour éviter l’empilement
accidentel sur une RTX 4060 de 8 Go. ComfyUI reste en mode ATTACH : le Studio
ne ferme pas et ne remplace pas une instance existante.

Studio local pour l’installation ComfyUI portable + Wan 2.2 TI2V 5B de Vincent, avec une RTX 4060 Laptop de 8 Go. Cette mise à jour ajoute les retouches d’images, les suites vidéo, le montage et une mémoire des prompts.

## Correctif du lancement V3

Le lanceur précédent acceptait un serveur portant le bon nom d’application, quelle que soit sa version ou son dossier. Il pouvait donc rouvrir une ancienne instance encore active. Le texte de la fenêtre CMD indiquait également encore 2.0.1. Ces deux défauts sont corrigés.

Le ZIP et le dossier extrait portent maintenant un numéro de version. Les fichiers sont contrôlés avant et après leur copie vers des chemins explicites. Le lanceur vérifie ensuite la version, l’empreinte de la livraison et le dossier de l’instance qui répond. Une ancienne version est ignorée ; le navigateur s’ouvre seulement après confirmation de la bonne instance. La page et ses scripts utilisent une adresse incluant la version pour éviter la réutilisation d’un ancien contenu en cache.

Trois rapports permettent de vérifier le lancement : `logs\installation.log`, `logs\installation-verifiee.json` et `logs\verification-version.json`. La console affiche **VERSION 3.0.5 VERIFIEE ET OUVERTE** une fois le serveur confirmé. Les processus du Studio installés dans le dossier cible sont arrêtés pour la mise à jour ; ComfyUI et les données sont conservés.

Le scénario d’une ancienne version sur le port mémorisé est testé sous PowerShell 7 sur Linux. La gestion réelle des processus et des raccourcis Windows reste à vérifier sur le PC. La capture 2.0.1 ne suffit pas à identifier lequel des anciens processus ou dossiers était utilisé ; les nouveaux rapports donnent ces informations.

## Installation de la mise à jour

1. Extraire **tout** le ZIP dans un nouveau dossier.
2. Double-cliquer sur **DEMARRER.cmd**, dans le dossier extrait. L’outil demande automatiquement les droits administrateur si une ancienne instance a été lancée en mode élevé.
3. Vérifier que **BAZOR AI Studio V3 · 3.0.5** apparaît dans l’interface. Fermer les anciens onglets et utiliser ensuite le raccourci du Bureau.

L’installation copie le programme vers `C:\AI\SimpleStudioV2`, sauvegarde l’ancien code dans `backups`, conserve `data` et relance les deux processus propres au Studio. Elle n’arrête pas ComfyUI. Si un ancien processus élevé bloque la mise à jour, double-cliquer sur `REPARER_STUDIO.cmd` : il relance la même procédure avec élévation automatique, sans saisir manuellement `taskkill` ou `cd`. Attendre la fin des imports, téléchargements ou exports du Studio avant une future mise à jour. Le raccourci ouvre le port disponible entre 8190 et 8199 ; 8191 est normal si 8190 est déjà occupé.

Le lancement réutilise le Python de ComfyUI et vérifie ses dépendances. Un échec reste visible dans la fenêtre et dans `logs\lancement.log`. Aucune protection Windows n’est désactivée par ces scripts.

## Corriger « Aucun checkpoint installé »

Dans **Créer → Texte vers image** ou **Image + texte vers image**, utiliser **Rechercher les modèles existants**. Le Studio reconnaît les checkpoints SD 1.5 / SDXL au format safetensors dans les dossiers Forge connus et les rend disponibles à ComfyUI ; les originaux sont conservés.

Si aucun modèle compatible n’est présent, cliquer sur **Installer SDXL officiel · 6,94 Go**. La progression apparaît en bas de page. Prévoir environ 10 Go libres et une connexion Internet. Le téléchargement reprend après interruption et le fichier est vérifié par SHA-256 avant activation. Cliquer sur **Actualiser les modèles**, choisir **Checkpoint SD 1.5 / SDXL installé**, puis le checkpoint SDXL.

Pour automatiser toute cette étape, double-cliquer sur **REPARER_MODELES.cmd** dans le dossier extrait. L’outil cherche d’abord un checkpoint valide dans les dossiers Forge connus ; s’il n’en trouve aucun, il installe SDXL officiel, vérifie son empreinte et conserve ComfyUI ainsi que les données. Une fois terminé, revenir dans le Studio et cliquer sur **Actualiser les modèles**.

Le modèle Wan utilisé pour la vidéo n’est pas un checkpoint SDXL. Le ZIP contient le logiciel, pas les poids des modèles. Source : https://huggingface.co/stabilityai/stable-diffusion-xl-base-1.0

## Images et réglages

- **Image + texte → Image** charge réellement l’image dans le VAE du checkpoint. Le curseur **Transformation** règle la liberté de modification ; commencer autour de 35 à 45 % pour une retouche.
- **Image + texte → Vidéo** utilise l’image comme première référence. Les boutons **Animer** et **Retoucher** reprennent aussi une image générée depuis la galerie.
- Pour Wan, **Brouillon** utilise 640 × 352 et 20 étapes, **Équilibré** 832 × 480 et 24 étapes, **Détails** 1280 × 704 et 28 étapes. Les valeurs s’inversent en portrait. La durée est choisie séparément : environ 2, 4 ou 6 secondes à 24 images/s.
- Pour SDXL, les presets utilisent 768²/20 étapes, 1024²/28 étapes ou 1152 × 896/32 étapes. Les tailles sont adaptées aux checkpoints SD 1.5 reconnus. Image + texte → image utilise DPM++ 2M / Karras ; Wan conserve son sampler natif uni_pc / simple, CFG 5, shift 8.
- Au premier démarrage de cette mise à jour, un ancien brouillon reçoit le preset Équilibré ; le texte et la référence sont conservés. Les prochaines modifications restent mémorisées.

Pour les personnages, partir d’une référence correcte et tester un geste simple sur un plan court. Les exclusions et l’augmentation de résolution ne garantissent ni une anatomie parfaite, ni la stabilité du visage. Le mode Détails demande davantage de mémoire et de temps ; les performances doivent être mesurées sur le PC. L’estimation se calibre sur les calculs réellement observés.

## Dépasser six secondes et monter un film

1. Dans **Montage**, cliquer une fois sur **Installer le montage vidéo** si proposé. Le composant FFmpeg est installé depuis PyPI via `imageio-ffmpeg==0.6.0`, sans mise à jour de PyTorch.
2. Ajouter des résultats depuis **Mes créations → Ajouter au montage**, ou importer plusieurs vidéos. Chaque clip reçoit une vignette et quatre images de fin.
3. Cliquer sur **Prolonger ce plan**. Une coupe reprend la dernière image conservée au point de coupe. Pour un clip entier, choisir la dernière image ou l’un des trois aperçus proches de la fin.
4. Décrire le personnage et le contexte commun, puis un mouvement par ligne. **Répartir le prompt en plans** prépare autant de lignes que nécessaire pour la durée visée ; adapter chaque ligne pour faire progresser la scène.
5. Lancer le lot. Avec la continuité activée, chaque nouveau plan reprend la dernière image du précédent. Le Studio lance un calcul à la fois, retrouve une demande déjà soumise et propose de reprendre un lot après redémarrage.
6. Modifier l’ordre avec les vignettes ou les flèches, régler début/fin, ou utiliser **Découper en lot**. Les coupes préservent les originaux.
7. Cliquer sur **Lire les plans à la suite**, puis **Générer le fichier assemblé**. L’export MP4 harmonise les tailles et les fréquences sans étirer l’image ; le son présent est conservé, sauf option sans son.

Wan reçoit **une image de référence et du texte**, pas une mémoire multiframe du mouvement. Une dérive du personnage ou un raccord visible reste possible. La prévisualisation lit les clips successivement ; un bref chargement peut séparer deux plans. Le fichier final les assemble sans ce chargement.

Limites de travail : 60 plans par lot, 120 éléments et 30 minutes par montage ; import de 1 Go et 30 minutes par fichier. Les clips muets reçoivent une piste silencieuse pour fiabiliser l’assemblage. L’export n’invente ni détails ni son. Après un échec définitif d’un plan, conserver les clips acquis et lancer un nouveau lot pour la suite.

## Exclusions, vignettes et prompts

**Mémoriser ces exclusions** les conserve dans SQLite et les ajoute aux prochaines générations et aux lots. L’onglet **Prompts** permet de les modifier. Les prompts des générations sont enregistrés avec leurs paramètres, graine, exclusions et référence. La galerie et les clips permettent de reprendre le prompt associé à la vignette ; les clips importés peuvent recevoir un prompt éditable.

La base propose recherche, réutilisation et export/import JSON. L’export contient aussi les préférences à titre de sauvegarde ; l’import JSON restaure les prompts, sans remplacer automatiquement les préférences courantes.

Dans **Chercher sur vos sites**, saisir jusqu’à cinq URL publiques, une par ligne, et éventuellement un mot clé. **Chercher et importer** examine jusqu’à trois pages par source et importe jusqu’à vingt nouveaux prompts par source, avec leur lien d’origine. Les textes sont enregistrés pour réutilisation, sans lancer de génération. Les restrictions robots.txt sont respectées. Les pages protégées, les sites refusant la collecte ou les contenus chargés uniquement en JavaScript peuvent ne rien retourner ; le résultat précise chaque source. Aucun contournement de connexion n’est prévu.

## Données et limites de validation

L’historique, les exclusions et les projets sont dans `C:\AI\SimpleStudioV2\data\studio.sqlite3`. Les clips importés, images de raccord et films exportés se trouvent dans `data\montage` et `data\assets`. Les sorties originales restent dans `ComfyUI\output\AI_Simple_Studio_2`. La galerie nécessite ComfyUI ouvert ; les clips déjà importés au montage restent locaux au Studio. Sauvegarder tout le dossier `data`, Studio fermé, pour conserver l’ensemble.

La réanimation d’une vidéo dans l’onglet Créer utilise uniquement sa première image : elle ne transfère pas son mouvement ou son son. Le réglage artistique reste limité aux représentations non sexuelles d’adultes, sans détail génital explicite.

Les tests couvrent le serveur local, l’image de référence dans les workflows, SQLite, la reprise sans doublon, les téléchargements vérifiés, les imports de prompts et les actions de l’interface. **La découpe, l’extraction de la dernière image et l’assemblage avec son ont été exécutés sur de vrais fichiers vidéo de test.** ComfyUI et Ollama sont remplacés par des services contrôlés dans les tests ; aucune génération IA réelle n’est revendiquée. L’exécution Windows/PowerShell, le rendu visuel du navigateur et la qualité sur la RTX 4060 restent à vérifier sur le PC. Les comptes de tests sont dans `VERIFICATION.json`.

Développement : `python -m unittest discover -s tests -p "test_*.py" -v`. Les deux tests DOM nécessitent jsdom ; Node et jsdom ne sont pas nécessaires à l’utilisation du Studio.

## Extensions qualité ComfyUI et veille concours

Le dossier contient `BAZOR_INSTALL_EXTENSIONS.cmd`. Il télécharge les trois
extensions officielles retenues dans `ComfyUI\custom_nodes` : ControlNet Aux,
IPAdapter Plus et VideoHelperSuite. Il ne remplace pas un dossier déjà présent,
ne tue pas ComfyUI. Si ComfyUI est ouvert, l’étape est reportée proprement et le
Studio continue avec l’instance existante. Pour les deux
extensions optionnelles, utiliser `-InstallOptional`; pour une mise à jour
fast-forward d’un dépôt Git propre, ajouter `-UpdateExisting`. L’installation
des dépendances Python reste volontaire avec `-InstallDependencies`.

Pour tout enchaîner en un clic, lance `1_CLIC_TOUT_BAZOR.cmd`. Si ComfyUI est
déjà ouvert, l’étape d’extensions est reportée automatiquement et le Studio
est lancé quand même ; aucun second moteur n’est créé.

Si une fenêtre se ferme trop vite, lance `BAZOR_DEMARRAGE_VISIBLE.cmd` : il
garde la console ouverte et affiche le code de retour ainsi que les journaux.

Les poids supplémentaires (IP-Adapter, preprocessors, détecteurs) ne sont pas
téléchargés automatiquement : ils sont plus lourds et ne sont pas nécessaires
à tous les plans. Cette décision protège l’espace disque et les 8 Go de VRAM.
La synthèse des techniques et des gagnants vérifiés est dans
`RECHERCHE_QUALITE_IA_2026.md`.
