﻿param(
  [string]$AIRoot='C:\AI',
  [switch]$Elevated
)
$ErrorActionPreference='Stop'
$source=$PSScriptRoot

function Test-Administrator {
  $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
  $principal=New-Object Security.Principal.WindowsPrincipal($identity)
  return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Quote-Argument([string]$Value) { return '"'+$Value+'"' }

try {
  if(-not (Test-Administrator)) {
    Write-Host 'Droits administrateur requis pour écrire dans les dossiers de modèles.' -ForegroundColor Yellow
    $powershell=(Get-Command powershell.exe -ErrorAction Stop).Source
    $args='-NoLogo -NoProfile -ExecutionPolicy Bypass -File '+(Quote-Argument $PSCommandPath)+' -AIRoot '+(Quote-Argument $AIRoot)+' -Elevated'
    $child=Start-Process -FilePath $powershell -ArgumentList $args -Verb RunAs -Wait -PassThru
    exit $child.ExitCode
  }

  $portable=Join-Path $AIRoot 'ComfyUI\ComfyUI_windows_portable'
  $python=Join-Path $portable 'python_embeded\python.exe'
  if(-not (Test-Path -LiteralPath $python)) {
    $candidates=@(Get-ChildItem (Join-Path $AIRoot 'ComfyUI') -Filter 'python.exe' -Recurse -File -ErrorAction SilentlyContinue | Where-Object {$_.FullName -match 'python_embeded'})
    if($candidates.Count -eq 0){throw ('Python portable ComfyUI introuvable sous '+$AIRoot+'\ComfyUI.')}
    $python=$candidates[0].FullName
  }
  $script=Join-Path $source 'app\model_cli.py'
  if(-not (Test-Path -LiteralPath $script)){throw 'app\model_cli.py absent. Extraire tout le nouveau ZIP.'}
  $logRoot=Join-Path $AIRoot 'SimpleStudioV2\logs'
  if(-not (Test-Path -LiteralPath $logRoot)){New-Item -ItemType Directory -Path $logRoot -Force | Out-Null}
  $log=Join-Path $logRoot ('model-repair-'+(Get-Date -Format 'yyyyMMdd-HHmmss-fff')+'.log')
  Write-Host '=== REPARATION AUTOMATIQUE DU CHECKPOINT IMAGE ===' -ForegroundColor Cyan
  Write-Host 'Recherche des checkpoints Forge, puis installation SDXL officielle si nécessaire.'
  Write-Host 'ComfyUI et les données ne sont pas arrêtés.' -ForegroundColor Green
  & $python -I $script repair --air-root $AIRoot 2>&1 | Tee-Object -FilePath $log
  if($LASTEXITCODE -ne 0){throw ('La réparation du modèle a échoué. Journal : '+$log)}
  Write-Host ''
  Write-Host 'TERMINE : retourne dans le Studio puis clique sur Actualiser les modèles.' -ForegroundColor Green
  Write-Host ('Journal : '+$log)
} catch {
  Write-Host ''
  Write-Host ('REPARATION MODELE INTERROMPUE : '+$_.Exception.Message) -ForegroundColor Red
  Write-Host 'ComfyUI et les données n''ont pas été supprimés.' -ForegroundColor Yellow
  Read-Host 'Appuyez sur Entree pour fermer cette fenetre'
  exit 1
}
