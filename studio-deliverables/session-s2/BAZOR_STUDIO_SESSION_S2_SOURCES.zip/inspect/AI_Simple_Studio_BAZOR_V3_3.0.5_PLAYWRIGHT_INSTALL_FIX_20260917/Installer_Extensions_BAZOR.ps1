﻿[CmdletBinding()]
param(
  [string]$AIRoot = 'C:\AI',
  [switch]$InstallOptional,
  [switch]$UpdateExisting,
  [switch]$InstallDependencies
)
$ErrorActionPreference = 'Stop'
trap {
  Write-Host ''
  Write-Host ('EXTENSIONS INTERROMPU : '+$_.Exception.Message) -ForegroundColor Red
  Write-Host ('Journal attendu : '+$logPath) -ForegroundColor Yellow
  Read-Host 'Appuyez sur Entree pour fermer cette fenetre'
  exit 1
}
$source = $PSScriptRoot
$portable = Join-Path $AIRoot 'ComfyUI\ComfyUI_windows_portable'
$custom = Join-Path $portable 'ComfyUI\custom_nodes'
$python = Join-Path $portable 'python_embeded\python.exe'
$manifestPath = Join-Path $source 'BAZOR_EXTENSIONS.json'
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$backupRoot = Join-Path $AIRoot ('..\BAZOR TOOL\backups\comfy-extensions-' + $stamp)
$logPath = Join-Path $source ('extensions-install-' + $stamp + '.json')

function Fail([string]$Message) { throw $Message }
if (-not (Test-Path -LiteralPath $manifestPath)) { Fail 'BAZOR_EXTENSIONS.json est introuvable.' }
if (-not (Test-Path -LiteralPath $custom)) { Fail "Dossier custom_nodes introuvable : $custom" }
if (-not (Get-Command git -ErrorAction SilentlyContinue)) { Fail 'Git est requis. Installe Git for Windows puis relance ce script.' }
$running = @(Get-CimInstance Win32_Process -Filter "Name='python.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -match 'ComfyUI[\\/]main\.py' })
if ($running.Count) {
  Write-Host '[INFO] ComfyUI est deja ouvert : connexion a cette instance conservee.' -ForegroundColor Cyan
  Write-Host '[INFO] Extensions laissees intactes pour eviter tout verrouillage ou redemarrage.' -ForegroundColor Yellow
  Write-Host '[OK] Etape extensions reportee sans bloquer le demarrage du Studio.' -ForegroundColor Green
  exit 0
}

$manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
$selected = @($manifest.extensions | Where-Object { $manifest.default_install -contains $_.id -or ($InstallOptional -and $manifest.optional_install -contains $_.id) })
$results = @()
foreach ($item in $selected) {
  $target = Join-Path $custom $item.folder
  $entry = [ordered]@{ id=$item.id; folder=$item.folder; repo=$item.repo; action='skipped'; status='ok'; message='' }
  try {
    if (Test-Path -LiteralPath $target) {
      if (-not $UpdateExisting) {
        $entry.message = 'Déjà présent : aucun écrasement.'
      } elseif (-not (Test-Path -LiteralPath (Join-Path $target '.git'))) {
        $entry.status = 'warning'; $entry.message = 'Dossier existant non-Git : laissé intact.'
      } else {
        $dirty = git -C $target status --porcelain
        if ($dirty) { $entry.status='warning'; $entry.message='Dépôt modifié localement : mise à jour ignorée.' }
        else {
          New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null
          Copy-Item -LiteralPath $target -Destination $backupRoot -Recurse
          git -C $target pull --ff-only
          $entry.action='updated'; $entry.message='Mis à jour en fast-forward.'
        }
      }
    } else {
      git clone --depth 1 --branch $item.branch $item.repo $target
      $entry.action='installed'; $entry.message='Dépôt officiel téléchargé.'
    }
    if ($InstallDependencies) {
      $requirements = Join-Path $target 'requirements.txt'
      if ((Test-Path -LiteralPath $requirements) -and (Test-Path -LiteralPath $python)) {
        & $python -s -m pip install --disable-pip-version-check -r $requirements
        $entry.message += ' Dépendances installées dans le Python ComfyUI.'
      }
    }
  } catch {
    $entry.status='error'; $entry.message=$_.Exception.Message
  }
  $results += [pscustomobject]$entry
  Write-Host ("[{0}] {1} : {2}" -f $entry.status.ToUpperInvariant(),$item.id,$entry.message)
}
$report = [ordered]@{ created=(Get-Date -Format o); comfy_root=$portable; custom_nodes=$custom; comfyui_candidate=$manifest.comfyui_candidate; results=$results }
$report | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $logPath -Encoding UTF8
Write-Host "Rapport : $logPath" -ForegroundColor Cyan
Write-Host "Installation terminee. Relance ComfyUI manuellement, puis utilise Diagnostic dans BAZOR." -ForegroundColor Green
