# Références techniques consultées

- Cahier de passation personnel : Passation_IA_Locale_Image_Video.pdf.
- Documentation PowerShell Microsoft sur Copy-Item et exécution locale.
- Ancien outil : AI_Simple_Studio_v1_6_9_LAYOUT_FIX.zip (lecture de son README, du serveur et de l’interface).
- Workflow natif Wan 2.2 : https://docs.comfy.org/tutorials/video/wan/wan2_2
- Modèle de workflow : https://github.com/Comfy-Org/workflow_templates/blob/main/templates/video_wan2_2_5B_ti2v.json
- ComfyUI v0.34.0, schémas vidéo : https://github.com/Comfy-Org/ComfyUI/blob/v0.34.0/comfy_extras/nodes_video.py
- ComfyUI, conditionnement Wan : https://github.com/Comfy-Org/ComfyUI/blob/master/comfy_extras/nodes_wan.py
- API et messages : https://docs.comfy.org/development/comfyui-server/comms_routes et https://docs.comfy.org/development/comfyui-server/comms_messages
- Ollama : https://docs.ollama.com/api/chat et https://docs.ollama.com/faq

Le contrôle de livraison V3 (3.0.5) utilise un manifeste local SHA-256 ; il ne remplace pas une signature de code Windows.

Les poids, ComfyUI et ses dépendances ne sont pas redistribués dans ce paquet ; le logiciel réutilise l’installation existante. Les sources externes restent sous leurs licences respectives.
