"""Execute the actual PowerShell launcher with an old HTTP server on the saved port.
Only Windows browser-opening and hidden-process APIs are adapted for the Linux test host.
"""
import asyncio,json,os,shutil,signal,sys,tempfile,unittest
from pathlib import Path
from aiohttp import web
from aiohttp.test_utils import TestServer
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'app'))
from runtime_identity import identity,matches

class IdentityTests(unittest.TestCase):
    def test_old_and_other_installations_rejected(self):
        current=identity('3.0.5',verify=True)
        self.assertTrue(matches(current,current))
        for other in ({'app':current['app'],'version':'2.0.1'},dict(current,install_root='other'),dict(current,build_id='other')):
            self.assertFalse(matches(other,current))

class LauncherTests(unittest.IsolatedAsyncioTestCase):
    async def test_watchdog_refuses_old_server_and_obeys_stop_flag(self):
        app=web.Application();app.router.add_get('/api/ping',lambda r:web.json_response({'app':'ai-simple-studio-v2','version':'2.0.1'}))
        async with TestServer(app) as server:
            with tempfile.TemporaryDirectory(prefix='studio supervisor ') as d:
                dest=Path(d)/'studio';shutil.copytree(ROOT,dest,ignore=shutil.ignore_patterns('data','logs','__pycache__'))
                async def run():
                    child=await asyncio.create_subprocess_exec(sys.executable,'-I',str(dest/'app/watchdog.py'),'--port',str(server.port),stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE)
                    try:out,err=await asyncio.wait_for(child.communicate(),10)
                    finally:
                        if child.returncode is None:child.kill();await child.wait()
                    return child.returncode,err.decode()
                code,err=await run();self.assertEqual(code,2,err)
                self.assertFalse((dest/'data/server_pid.json').exists())
                (dest/'stop.flag').touch();code,err=await run();self.assertEqual(code,0,err)

    @unittest.skipUnless(os.environ.get('STUDIO_TEST_PWSH'),'Set STUDIO_TEST_PWSH for the actual PowerShell launch test.')
    async def test_real_launcher_ignores_cached_201_and_opens_verified_211(self):
        comfy=web.Application();comfy.router.add_get('/system_stats',lambda r:web.json_response({'devices':[]}))
        old=web.Application();old.router.add_get('/api/ping',lambda r:web.json_response({'app':'ai-simple-studio-v2','version':'2.0.1'}))
        async with TestServer(comfy,port=8188),TestServer(old,port=8191):
            with tempfile.TemporaryDirectory(prefix='studio launcher ') as d:
                base=Path(d);dest=base/'SimpleStudioV2';shutil.copytree(ROOT,dest,ignore=shutil.ignore_patterns('data','logs','__pycache__'))
                (dest/'data').mkdir();(dest/'data/port.txt').write_text('8191')
                py=base/'ComfyUI/ComfyUI_windows_portable/python_embeded/python.exe';py.parent.mkdir(parents=True);py.symlink_to(sys.executable)
                wrapper=base/'run-launcher.ps1'
                wrapper.write_text('''param([string]$AIRoot,[string]$Studio)
function Start-Process($FilePath,$ArgumentList,$WorkingDirectory,$WindowStyle) {
  if($FilePath -match '^http://') {Set-Content -LiteralPath (Join-Path $Studio 'browser-url.txt') -Value $FilePath;return}
  $p=New-Object System.Diagnostics.Process
  $p.StartInfo.FileName=$FilePath;$p.StartInfo.Arguments=$ArgumentList
  $p.StartInfo.WorkingDirectory=$WorkingDirectory;$p.StartInfo.UseShellExecute=$false
  $p.StartInfo.RedirectStandardOutput=$true;$p.StartInfo.RedirectStandardError=$true
  $p.StartInfo.CreateNoWindow=$true
  [void]$p.Start()
  $p.StandardOutput.ReadToEndAsync() | Out-Null;$p.StandardError.ReadToEndAsync() | Out-Null
  Add-Content -LiteralPath (Join-Path $Studio 'spawned-pids.txt') -Value $p.Id
}
& (Join-Path $Studio 'Lancer.ps1') -AIRoot $AIRoot
''')
                child=None
                try:
                    child=await asyncio.create_subprocess_exec(os.environ['STUDIO_TEST_PWSH'],'-NoLogo','-NoProfile','-File',str(wrapper),'-AIRoot',str(base),'-Studio',str(dest),stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE)
                    out,err=await asyncio.wait_for(child.communicate(),55)
                    self.assertEqual(child.returncode,0,out.decode()+err.decode())
                    report=json.loads((dest/'logs/verification-version.json').read_text(encoding='utf-8-sig'))
                    self.assertEqual(report['observed']['version'],'3.0.5')
                    self.assertEqual(report['observed']['install_root'],str(dest))
                    self.assertNotEqual(report['url'],'http://127.0.0.1:8191')
                    self.assertTrue(any(x['port']==8191 and x['version']=='2.0.1' for x in report['ignored_instances']))
                    url=(dest/'browser-url.txt').read_text().strip();self.assertIn('studio_version=3.0.5',url)
                    (ROOT.parent/'launcher-scenario.log').write_bytes(out+err)
                finally:
                    if child and child.returncode is None:child.kill();await child.wait()
                    (dest/'stop.flag').touch()
                    ids=[]
                    if (dest/'spawned-pids.txt').exists():ids=[int(x) for x in (dest/'spawned-pids.txt').read_text().split()]
                    if (dest/'data/server_pid.json').exists():ids.append(json.loads((dest/'data/server_pid.json').read_text())['pid'])
                    for process_id in ids:
                        try:
                            if str(dest).encode() in Path(f'/proc/{process_id}/cmdline').read_bytes():os.kill(process_id,signal.SIGTERM)
                        except (FileNotFoundError,ProcessLookupError):pass

if __name__=='__main__':unittest.main(verbosity=2)
