import asyncio,io,json,subprocess,sys,tempfile,unittest,uuid
from pathlib import Path
from unittest.mock import AsyncMock,patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app'))
from aiohttp.test_utils import TestClient,TestServer
from PIL import Image
from workflows import parameters,build,detect_profile,patch_h3_graph
from studio import create_app,Store,local_url,parse_visual_report
from media_tools import ffmpeg_path
try:
    from fake_comfy import FakeComfy,object_info
except ModuleNotFoundError:
    from .fake_comfy import FakeComfy,object_info

class WorkflowTests(unittest.TestCase):
    def test_h3_profile_patches_both_reference_frames(self):
        info={'ModelSamplingMiniMaxH3':{},'ComfyUI-Spectrum-MiniMax-H3':{}}
        self.assertEqual(detect_profile(info)['family'],'h3')
        graph={
            '1':{'class_type':'CLIPTextEncode','inputs':{'text':'old','clip':['4',0]},'_meta':{'title':'Positive'}},
            '2':{'class_type':'CLIPTextEncode','inputs':{'text':'old','clip':['4',0]},'_meta':{'title':'Negative'}},
            '3':{'class_type':'FL2VConnect','inputs':{'width':608,'height':352,'length':49,'steps':20,'seed':1,'first_frame':['5',0],'last_frame':['6',0]}},
            '5':{'class_type':'LoadImage','inputs':{'image':'first_frame.png'},'_meta':{'title':'Load First Frame'}},
            '6':{'class_type':'LoadImage','inputs':{'image':'last_frame.png'},'_meta':{'title':'Load Last Frame'}},
            '7':{'class_type':'SaveVideo','inputs':{'filename_prefix':'old'}},
        }
        p=parameters({'mode':'i2v','prompt':'lake','asset_id':'abc','width':832,'height':480,'frames':81,'steps':20})
        result=patch_h3_graph(graph,p,'studio_photo.png','AI_Simple_Studio_2/test')
        self.assertEqual(graph['5']['inputs']['image'],'studio_photo.png')
        self.assertEqual(graph['6']['inputs']['image'],'studio_photo.png')
        self.assertEqual(graph['3']['inputs']['width'],832)
        self.assertEqual(graph['3']['inputs']['height'],480)
        self.assertEqual(graph['3']['inputs']['length'],81)
        self.assertEqual(graph['7']['inputs']['filename_prefix'],'AI_Simple_Studio_2/test')

    def test_h3_rejects_missing_reference(self):
        graph={'1':{'class_type':'CLIPTextEncode','inputs':{'text':'old'}},
               '2':{'class_type':'CLIPTextEncode','inputs':{'text':'old'}},
               '3':{'class_type':'FL2VConnect','inputs':{'width':608,'height':352,'length':49,'steps':20,'seed':1}},
               '4':{'class_type':'LoadImage','inputs':{'image':'first_frame.png'}}}
        p=parameters({'mode':'i2v','prompt':'lake','asset_id':'abc'})
        with self.assertRaisesRegex(ValueError,'image de départ'):
            patch_h3_graph(graph,p,None)

    def test_h3_accepts_qwen_or_clipproj_text_encoder_names(self):
        graph={'1':{'class_type':'TextEncodeQwen3VL','inputs':{'prompt':'old','clip':['4',0]},'_meta':{'title':'Positive prompt'}},
               '2':{'class_type':'ClipProjTextEncoder','inputs':{'text':'old','clip':['4',0]},'_meta':{'title':'Negative prompt'}},
               '3':{'class_type':'KSampler','inputs':{'width':608,'height':352,'length':49,'steps':20,'seed':1}}}
        p=parameters({'mode':'t2v','prompt':'a red boat','negative':'blur'})
        patch_h3_graph(graph,p)
        self.assertTrue(graph['1']['inputs']['prompt'].startswith('a red boat'))
        self.assertIn('blur',graph['2']['inputs']['text'])

    def test_h3_accepts_converter_prompt_wrapper(self):
        graph={'prompt':{'1':{'class_type':'TextEncodeMiniMaxH3','inputs':{'text':'old'}},
                         '3':{'class_type':'KSampler','inputs':{'width':608,'height':352,'length':49,'steps':20,'seed':1}}}}
        p=parameters({'mode':'t2v','prompt':'a quiet lake'})
        result=patch_h3_graph(graph,p)
        self.assertTrue(result['graph']['1']['inputs']['text'].startswith('a quiet lake'))

    def test_native_photo_connection(self):
        p=parameters({'mode':'i2v','prompt':'lake','asset_id':'abc'})
        g=build(p,object_info(),'studio_photo.png')
        self.assertEqual(g['55']['inputs']['start_image'],['56',0])
        self.assertEqual(g['56']['inputs']['image'],'studio_photo.png')
        self.assertEqual(g['58']['inputs']['format.codec'],'auto')
    def test_text_video_does_not_load_reference(self):
        g=build(parameters({'prompt':'lake'}),object_info())
        self.assertNotIn('56',g);self.assertNotIn('start_image',g['55']['inputs'])
    def test_still_is_image_output_only(self):
        g=build(parameters({'mode':'t2i','engine':'sd','checkpoint':'sdxl_test.safetensors','prompt':'lake'}),object_info())
        self.assertEqual(g['55']['class_type'],'EmptyLatentImage');self.assertEqual(g['58']['class_type'],'SaveImage');self.assertNotIn('57',g)
    def test_still_rejects_video_engine_without_image_checkpoint(self):
        with self.assertRaisesRegex(ValueError,'checkpoint image'):
            parameters({'mode':'t2i','engine':'wan','prompt':'lake'})
    def test_legacy_save_video_schema(self):
        g=build(parameters({'prompt':'lake'}),object_info(False))
        self.assertEqual(g['58']['inputs']['codec'],'auto');self.assertNotIn('format.codec',g['58']['inputs'])
    def test_sd_checkpoint_workflow(self):
        p=parameters({'mode':'t2i','engine':'sd','checkpoint':'sdxl_test.safetensors','prompt':'lake'})
        g=build(p,object_info());self.assertEqual(g['6']['inputs']['clip'],['37',1]);self.assertNotIn('38',g)
    def test_selected_style_is_enforced_in_native_graph(self):
        p=parameters({'mode':'t2i','engine':'sd','checkpoint':'sdxl_test.safetensors','prompt':'adult fashion portrait',
                      'style_presets':['standing','fullbody','realistic']})
        g=build(p,object_info())
        self.assertIn('STRICT standing pose',g['6']['inputs']['text'])
        self.assertIn('STRICT full-body framing',g['6']['inputs']['text'])
        self.assertIn('cut-off feet',g['7']['inputs']['text'])
        self.assertIn('pornographic content',g['7']['inputs']['text'])
    def test_invalid_dimensions_frames_and_seed(self):
        for raw in ({'width':641},{'frames':50},{'seed':2**54},{'steps':0},{'width':600.3},{'mode':'i2v'}):
            with self.subTest(raw=raw),self.assertRaises(ValueError):parameters({'prompt':'lake',**raw})
    def test_missing_model_is_actionable(self):
        info=object_info();info['VAELoader']['input']['required']['vae_name']=[[]]
        with self.assertRaisesRegex(ValueError,'wan2.2_vae'):build(parameters({'prompt':'lake'}),info)
    def test_missing_reference_input_is_rejected(self):
        info=object_info();info['Wan22ImageToVideoLatent']['input']['optional']={}
        with self.assertRaisesRegex(ValueError,'photo'):build(parameters({'prompt':'lake'}),info,'image.png')
    def test_loopback_enforced(self):
        for u in ('http://example.com','http://127.0.0.1.evil.com','http://user@127.0.0.1','file:///etc/passwd'):
            with self.assertRaises(ValueError):local_url(u)
    def test_visual_report_accepts_fenced_json_without_false_correction(self):
        report=parse_visual_report('```json\n{"score":88,"needs_correction":false,"detected":[],"correction":"","preserved":["lake"]}\n```')
        self.assertTrue(report['analysis_valid']);self.assertEqual(report['score'],88);self.assertFalse(report['needs_correction'])
        invalid=parse_visual_report('The result looks good.')
        self.assertFalse(invalid['analysis_valid']);self.assertFalse(invalid['needs_correction'])

class IntegrationTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.fake=FakeComfy();self.engine=TestServer(self.fake.app());await self.engine.start_server()
        self.url=str(self.engine.make_url('')).rstrip('/')
        await self.start_ui()
    async def start_ui(self):
        self.app=create_app(self.tmp.name,self.url,self.url);self.client=TestClient(TestServer(self.app));await self.client.start_server();self.s=self.app['studio']
        self.token=(await (await self.client.get('/api/config')).json())['token']
    async def asyncTearDown(self):
        await self.client.close();await self.engine.close();self.tmp.cleanup()
    async def post(self,path,data,key=None):
        h={'X-Studio-Token':self.token}
        if key:h['Idempotency-Key']=key
        r=await self.client.post(path,json=data,headers=h)
        return r,await r.json()
    async def job(self,key=None,**extra):
        key=key or uuid.uuid4().hex
        return await self.post('/api/jobs',{'prompt':'A quiet lake','seed':42,**extra},key)
    async def test_health_and_no_initial_fake_eta(self):
        h=await (await self.client.get('/api/health')).json();self.assertTrue(h['ready'])
        _,e=await self.post('/api/estimate',{'prompt':'lake'});self.assertIsNone(e['seconds']);self.assertEqual(e['samples'],0)
    async def test_token_and_origin_required(self):
        r=await self.client.post('/api/jobs',json={'prompt':'evil'});self.assertEqual(r.status,403)
        r=await self.client.get('/api/config',headers={'Origin':'https://example.com'});self.assertEqual(r.status,403)
    async def test_upload_real_png_and_generate_photo(self):
        out=io.BytesIO();Image.new('RGB',(120,80),'red').save(out,'PNG')
        r=await self.client.post('/api/upload',data=out.getvalue(),headers={'X-Studio-Token':self.token});a=await r.json()
        self.assertEqual(r.status,200);self.assertEqual(a['width'],120)
        r,j=await self.job(mode='i2v',asset_id=a['id']);self.assertEqual(r.status,200)
        self.assertEqual(self.fake.upload_count,1);self.assertEqual(self.fake.last_payload['prompt']['55']['inputs']['start_image'],['56',0])
    async def test_broken_upload_rejected(self):
        r=await self.client.post('/api/upload',data=b'not an image',headers={'X-Studio-Token':self.token});self.assertEqual(r.status,400)
    async def test_idempotent_double_click(self):
        key=uuid.uuid4().hex
        results=await asyncio.gather(self.job(key),self.job(key))
        self.assertEqual(self.fake.post_count,1);self.assertEqual(results[0][1]['id'],results[1][1]['id'])
    async def test_crash_recovery_finished_task(self):
        _,j=await self.job();self.fake.complete(j['prompt_id']);await self.client.close();await self.start_ui();await self.s.reconcile()
        got=self.s.store.get('job',j['id']);self.assertEqual(got['status'],'done');self.assertTrue(got['outputs']);self.assertEqual(self.fake.post_count,1)
    async def test_video_result_hides_auxiliary_still(self):
        _,j=await self.job(mode='t2v');self.fake.complete(j['prompt_id']);await self.s.reconcile()
        got=self.s.store.get('job',j['id']);self.assertEqual(got['status'],'done');self.assertEqual([o['media'] for o in got['outputs']],['video']);self.assertEqual(got['outputs'][0]['filename'],'fixture.mp4')
        public=self.s.public_job(got);self.assertEqual(public['outputs'][0]['_source_index'],0);self.assertTrue(public['outputs'][0]['url'].endswith('/0'))
        old=dict(got,outputs=[{'filename':'auxiliary-preview.png','media':'image'},{'filename':'fixture.mp4','media':'video'}])
        public=self.s.public_job(old);self.assertEqual(public['outputs'][0]['_source_index'],1);self.assertTrue(public['outputs'][0]['url'].endswith('/1'))
    async def test_h3_interface_workflow_is_converted_before_patch(self):
        workflow=Path(self.tmp.name)/'minimax_h3_t2v.json';workflow.write_text(json.dumps({'nodes':[{'id':1,'type':'CLIPTextEncode'}]}),encoding='utf-8')
        converted={'1':{'class_type':'CLIPTextEncode','inputs':{'text':'old','clip':['4',0]},'_meta':{'title':'Positive'}},'2':{'class_type':'CLIPTextEncode','inputs':{'text':'old','clip':['4',0]},'_meta':{'title':'Negative'}},'3':{'class_type':'MiniMaxH3ImageToVideo','inputs':{'width':608,'height':352,'length':49,'steps':20,'seed':1}},'5':{'class_type':'LoadImage','inputs':{'image':'old.png'}},'7':{'class_type':'SaveVideo','inputs':{'filename_prefix':'old'}}}
        p=parameters({'mode':'t2v','engine':'h3','prompt':'lake'})
        with patch.object(self.s,'h3_workflow_candidates',return_value=[workflow]),patch.object(self.s,'request',new=AsyncMock(return_value={'prompt':converted})):
            graph,profile=await self.s.graph_for(p,{'ModelSamplingMiniMaxH3':{}},'ref.png','prefix')
        self.assertEqual(profile['family'],'h3');self.assertTrue(graph['1']['inputs']['text'].startswith('lake'));self.assertEqual(graph['5']['inputs']['image'],'ref.png');self.assertEqual(graph['7']['inputs']['filename_prefix'],'prefix')
    async def test_video_analysis_extracts_frames_and_accepts_report(self):
        video=Path(self.tmp.name)/'analysis.mp4'
        subprocess.run([ffmpeg_path(),'-hide_banner','-loglevel','error','-y','-f','lavfi','-i','color=c=red:s=160x96:d=1:r=8','-c:v','libx264','-pix_fmt','yuv420p',str(video)],check=True,capture_output=True,timeout=30)
        self.fake.video=video.read_bytes();_,j=await self.job(mode='t2v',frames=25,fps=24);self.fake.complete(j['prompt_id']);await self.s.reconcile()
        self.fake.chat_response='```json\n{"score":88,"needs_correction":false,"detected":[],"correction":"","preserved":["A quiet lake"]}\n```'
        r,analysis=await self.post('/api/jobs/'+j['id']+'/analyze',{'model':'gemma3:4b'})
        self.assertEqual(r.status,200);self.assertTrue(analysis['analysis_valid']);self.assertEqual(analysis['score'],88);self.assertFalse(analysis['needs_correction']);self.assertEqual(analysis['output_index'],0);self.assertGreaterEqual(len(self.fake.last_chat['messages'][1]['images']),1)
    async def test_debug_events_and_deletion_are_persistent_and_scoped(self):
        r,debug=await self.post('/api/debug/event',{'events':[{'event':'click','id':'generate','state':{'mode':'t2v'}},{'event':'after_click','status':'error'}]})
        self.assertEqual(r.status,200);self.assertEqual(debug['accepted'],2);self.assertIn('client.click',self.s.debug_path.read_text(encoding='utf-8'))
        _,j=await self.job();self.fake.complete(j['prompt_id']);await self.s.reconcile()
        r,_=await self.post('/api/jobs/'+j['id']+'/delete',{});self.assertEqual(r.status,200);self.assertFalse(self.s.store.get('job',j['id']))
        saved=self.s.prompt_library.save({'prompt':'prompt to delete','mode':'t2v'});r,_=await self.post('/api/prompts/'+saved['id']+'/delete',{});self.assertEqual(r.status,200);self.assertFalse(self.s.store.get('prompt',saved['id']))
    async def test_uncertain_response_is_reconciled_without_resubmit(self):
        self.fake.timeout_reply=True;_,j=await self.job();self.assertEqual(j['status'],'uncertain');self.assertIsNone(j['prompt_id'])
        await self.client.close();await self.start_ui();await self.s.reconcile()
        got=self.s.store.get('job',j['id']);self.assertEqual(got['status'],'queued');self.assertTrue(got['prompt_id']);self.assertEqual(self.fake.post_count,1)
    async def test_verify_endpoint_reconciles_ambiguous_submission(self):
        self.fake.timeout_reply=True;_,j=await self.job();self.assertEqual(j['status'],'uncertain')
        self.fake.timeout_reply=False
        r,verified=await self.post('/api/jobs/'+j['id']+'/verify',{})
        self.assertEqual(r.status,200);self.assertEqual(verified['status'],'queued');self.assertTrue(verified['prompt_id']);self.assertEqual(self.fake.post_count,1)
    async def test_scoped_progress_and_completion(self):
        _,j=await self.job();pid=j['prompt_id']
        await self.s.on_event({'type':'executing','data':{'prompt_id':pid,'node':'3'}})
        await self.s.on_event({'type':'progress','data':{'prompt_id':'different','node':'3','value':4,'max':20}})
        self.assertNotIn('sample_value',self.s.store.get('job',j['id']))
        await self.s.on_event({'type':'progress','data':{'prompt_id':pid,'node':'3','value':7,'max':20}})
        self.assertEqual(self.s.store.get('job',j['id'])['sample_value'],7)
        self.fake.complete(pid);await self.s.reconcile();got=self.s.store.get('job',j['id']);self.assertEqual(got['status'],'done')
    async def test_cancel_only_requested_job(self):
        _,a=await self.job();_,b=await self.job();await self.post('/api/jobs/'+a['id']+'/cancel',{});await self.s.reconcile()
        self.assertEqual(self.s.store.get('job',a['id'])['status'],'cancelled');self.assertTrue(any(x[1]==b['prompt_id'] for x in self.fake.queued))
    async def test_ollama_unload_and_busy_guard(self):
        r,a=await self.post('/api/optimize',{'prompt':'lake','ollama_model':'gemma3:4b'});self.assertEqual(r.status,200);self.assertEqual(self.fake.last_chat['keep_alive'],0)
        await self.job();r,a=await self.post('/api/optimize',{'prompt':'lake','ollama_model':'gemma3:4b'});self.assertEqual(r.status,400)
    async def test_output_download_and_path_restriction(self):
        _,j=await self.job();self.fake.complete(j['prompt_id']);await self.s.reconcile()
        r=await self.client.get('/api/media/'+j['id']+'/0?download=1');self.assertEqual(r.status,200);self.assertIn('attachment',r.headers['Content-Disposition'])
        r=await self.client.get('/api/assets/..%2F..%2Fetc%2Fpasswd');self.assertNotEqual(r.status,200)
    async def test_sqlite_survives_reopen(self):
        self.s.store.put('meta','example',{'a':1});await self.client.close();await self.start_ui();self.assertEqual(self.s.store.get('meta','example'),{'a':1})

if __name__=='__main__':unittest.main(verbosity=2)
