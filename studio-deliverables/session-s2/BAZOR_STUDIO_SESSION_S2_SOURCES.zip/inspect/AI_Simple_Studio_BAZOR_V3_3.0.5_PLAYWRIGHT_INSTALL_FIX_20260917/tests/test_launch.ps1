param([string]$Root=(Split-Path $PSScriptRoot))
$ErrorActionPreference='Stop'
. (Join-Path $Root 'StartupTools.ps1')
function Check($Condition,[string]$Message){if(-not $Condition){throw $Message}}
$release=Read-StudioRelease $Root
$helper=Join-Path $Root 'ReparerStudio.ps1'
Check (Test-Path -LiteralPath $helper) 'L''outil d''elevation manque du paquet.'
$demarrer=Get-Content -LiteralPath (Join-Path $Root 'DEMARRER.cmd') -Raw
Check ($demarrer.Contains('ReparerStudio.ps1')) 'DEMARRER.cmd ne passe pas par l''outil de reparation.'
$startupText=Get-Content -LiteralPath (Join-Path $Root 'StartupTools.ps1') -Raw
Check ($startupText.Contains('Stop-Process -Id $processId -Force')) 'L''arret force cible du Studio manque.'
Check ($startupText.Contains('taskkill.exe /PID ([string]$processId) /T /F')) 'Le secours taskkill cible du Studio manque.'
$expected=@{app='ai-simple-studio-v2';version=$release.version;build_id=$release.build_id;install_root='C:\AI\SimpleStudioV2'}
$script:replies=@{}
function Busy([int]$Port){return $script:replies.ContainsKey($Port)}
function Api([string]$Url){return $script:replies[([uri]$Url).Port]}
$script:replies[8191]=@{app='ai-simple-studio-v2';version='2.0.1'}
$script:replies[8192]=@{app='ai-simple-studio-v2';version='3.0.3';build_id='other';install_root=$expected.install_root}
$script:replies[8193]=@{app='ai-simple-studio-v2';version='3.0.3';build_id=$expected.build_id;install_root='C:\OTHER\SimpleStudioV2'}
$result=Select-StudioPort @(8191,8192,8193,8194) $expected
Check ($result.port -eq 8194 -and -not $result.attached) 'Old cached port, wrong build or another folder was accepted.'
Check ($result.ignored.Count -eq 3) 'Ignored instances were not recorded.'
$script:replies[8195]=$expected
$result=Select-StudioPort @(8191,8192,8193,8194,8195) $expected
Check ($result.port -eq 8195 -and $result.attached) 'Exact installed server was not reused.'
$result=Select-StudioPort @(8191,8192,8193) $expected
Check ($result.port -eq 0) 'Occupied old ports must not be used as a fallback.'

$tmp=Join-Path ([IO.Path]::GetTempPath()) ('studio-update-'+[guid]::NewGuid().ToString())
try {
  New-Item -ItemType Directory -Path (Join-Path $tmp 'app/static'),(Join-Path $tmp 'data') -Force | Out-Null
  Set-Content -LiteralPath (Join-Path $tmp 'app/studio.py') -Value 'OLD 2.0.1'
  Set-Content -LiteralPath (Join-Path $tmp 'app/static/index.html') -Value 'OLD 2.0.1'
  Set-Content -LiteralPath (Join-Path $tmp 'data/history.txt') -Value 'PRESERVE USER DATA'
  $count=Copy-StudioRelease $Root $tmp $release
  Check ($count -gt 10) 'Copied files were not verified.'
  Check ((Get-Content -LiteralPath (Join-Path $tmp 'app/studio.py') -Raw).Contains("VERSION='3.0.5'")) 'Old backend was not replaced at exact path.'
  Check ((Get-Content -LiteralPath (Join-Path $tmp 'app/static/index.html') -Raw).Contains('V3 · Local')) 'Old UI was not replaced.'
  Check ((Get-Content -LiteralPath (Join-Path $tmp 'data/history.txt')) -eq 'PRESERVE USER DATA') 'User data was changed.'
  Check (Test-Path -LiteralPath (Join-Path $tmp 'ReparerStudio.ps1')) 'L''outil de reparation n''a pas ete copie dans la destination.'
  Add-Content -LiteralPath (Join-Path $tmp 'app/static/index.html') -Value 'BROKEN COPY'
  $rejected=$false
  try {Assert-StudioFiles $tmp $release | Out-Null} catch {$rejected=$true}
  Check $rejected 'Incomplete copy must be rejected.'

  $script:stopped=@()
  $script:processes=@(
    @{Name='python.exe';ProcessId=901001;CommandLine='python "'+(Join-Path $tmp 'app/studio.py')+'" --port 8191';CreationDate='one'},
    @{Name='python.exe';ProcessId=901002;CommandLine='python "'+(Join-Path $tmp 'app/watchdog.py')+'"';CreationDate='two'},
    @{Name='python.exe';ProcessId=901003;CommandLine='python "C:\AI\ComfyUI\main.py"';CreationDate='three'},
    @{Name='python.exe';ProcessId=901004;CommandLine='python "'+(Join-Path $tmp 'other/app/studio.py')+'"';CreationDate='four'}
  )
  function Get-CimInstance($ClassName,$Filter,$ErrorAction) {
    if($Filter){return $script:processes | Where-Object {$_.ProcessId -eq [int]($Filter -replace 'ProcessId=','')}}
    return $script:processes
  }
  function Stop-Process($Id,$ErrorAction,$Force){$script:stopped+=@($Id);$script:processes=@($script:processes | Where-Object {$_.ProcessId -ne $Id})}
  function Wait-Process($Id,$Timeout,$ErrorAction){}
  function Get-Process($Id,$ErrorAction){return $script:processes | Where-Object {$_.ProcessId -eq $Id}}
  Stop-InstalledStudio $tmp | Out-Null
  Check (($script:stopped -join ',') -eq '901002,901001') 'Must stop only owned watchdog then owned server, never ComfyUI or other installations.'
} finally {Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue}
Write-Output 'PowerShell: port selection, existing-folder update, corrupt-copy rejection, data preservation and scoped process handling passed.'
