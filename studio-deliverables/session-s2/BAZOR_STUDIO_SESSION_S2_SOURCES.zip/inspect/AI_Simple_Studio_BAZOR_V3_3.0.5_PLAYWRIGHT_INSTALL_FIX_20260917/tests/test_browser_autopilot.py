import sys
import unittest
from pathlib import Path

APP = Path(__file__).resolve().parents[1] / 'app'
sys.path.insert(0, str(APP))

from browser_autopilot import BrowserAutopilot, StudioAutomation


class FakeLocator:
    def __init__(self):
        self.calls = []

    async def click(self, **kwargs):
        self.calls.append(kwargs)
        raise RuntimeError('intercepted by overflow-x-clip parent')


class FakePage:
    def __init__(self):
        self.evaluations = []

    async def evaluate(self, script, selector):
        self.evaluations.append((script, selector))
        return {'ok': True, 'parent': 'DIV'}


class BrowserAutopilotTests(unittest.IsolatedAsyncioTestCase):
    async def test_profile_click_uses_force_then_page_evaluate_fallback(self):
        automation = StudioAutomation()
        page = FakePage()
        locator = FakeLocator()

        result = await automation.click_profile_button(
            page, locator, '[data-testid="accounts-profile-button"]'
        )

        self.assertTrue(result['ok'])
        self.assertEqual(locator.calls[0].get('force'), True)
        self.assertEqual(len(page.evaluations), 1)
        script, selector = page.evaluations[0]
        self.assertEqual(selector, '[data-testid="accounts-profile-button"]')
        self.assertIn('pointer-events', script)
        self.assertIn('finally', script)

    def test_requested_public_class_is_used(self):
        self.assertIs(BrowserAutopilot, StudioAutomation)


if __name__ == '__main__':
    unittest.main(verbosity=2)
