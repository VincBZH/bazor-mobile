"""Controlled engine used only by tests. No AI generation is simulated as real output."""
import asyncio,io,uuid
from aiohttp import web
from PIL import Image


def object_info(dynamic=True):
    # Public node input contracts checked against ComfyUI v0.34.0 sources.
    def node(required,optional=None):return {'input':{'required':required,'optional':optional or {}}}
    def fields(**kwargs):return {k:[v] for k,v in kwargs.items()}
    info={
      'UNETLoader':node({'unet_name':[['wan2.2_ti2v_5B_fp16.safetensors']],'weight_dtype':[['default']]}),
      'CLIPLoader':node({'clip_name':[['umt5_xxl_fp8_e4m3fn_scaled.safetensors']],'type':[['wan']]},{'device':[['default','cpu']]}),
      'VAELoader':node({'vae_name':[['wan2.2_vae.safetensors']]}),
      'ModelSamplingSD3':node(fields(model='MODEL',shift='FLOAT')),
      'CLIPTextEncode':node(fields(text='STRING',clip='CLIP')),
      'Wan22ImageToVideoLatent':node(fields(vae='VAE',width='INT',height='INT',length='INT',batch_size='INT'),fields(start_image='IMAGE')),
      'LoadImage':node(fields(image='STRING')),
      'KSampler':node(fields(model='MODEL',positive='CONDITIONING',negative='CONDITIONING',latent_image='LATENT',seed='INT',steps='INT',cfg='FLOAT',sampler_name='STRING',scheduler='STRING',denoise='FLOAT')),
      'VAEDecode':node(fields(samples='LATENT',vae='VAE')),
      'VAEDecodeTiled':node(fields(samples='LATENT',vae='VAE',tile_size='INT',overlap='INT',temporal_size='INT',temporal_overlap='INT')),
      'CreateVideo':node(fields(images='IMAGE',fps='FLOAT')),
      'SaveImage':node(fields(images='IMAGE',filename_prefix='STRING')),
      'SaveVideo':node(fields(video='VIDEO',filename_prefix='STRING',format='STRING',codec='STRING')),
      'CheckpointLoaderSimple':node({'ckpt_name':[['sdxl_test.safetensors']]}),
      'EmptyLatentImage':node(fields(width='INT',height='INT',batch_size='INT')),
      'ImageScale':node(fields(image='IMAGE',upscale_method='STRING',width='INT',height='INT',crop='STRING')),
      'VAEEncode':node(fields(pixels='IMAGE',vae='VAE')),
    }
    if dynamic:
        codec=['COMFY_DYNAMICCOMBO_V3',{'options':[{'key':'auto','inputs':{'required':{}}}]}]
        info['SaveVideo']=node({**fields(video='VIDEO',filename_prefix='STRING'), 'format':['COMFY_DYNAMICCOMBO_V3',{'options':[{'key':'auto','inputs':{'required':{'codec':codec}}}]}]},{'codec':codec})
    return info


class FakeComfy:
    def __init__(self):
        self.info=object_info();self.queued=[];self.running=[];self.history={};self.post_count=0;self.upload_count=0;self.last_payload=None;self.last_chat=None;self.sockets={};self.timeout_reply=False;self.video=b'';self.chat_response=None
        image=Image.new('RGB',(640,352),'#b8bad9');out=io.BytesIO();image.save(out,'PNG');self.png=out.getvalue()
    async def event(self,pid,kind,**data):
        for ws in self.sockets.values():await ws.send_json({'type':kind,'data':{'prompt_id':pid,**data}})
    def complete(self,pid):
        row=next(x for x in self.queued+self.running if x[1]==pid)
        self.queued=[x for x in self.queued if x[1]!=pid];self.running=[x for x in self.running if x[1]!=pid]
        is_video=any(isinstance(node,dict) and node.get('class_type')=='SaveVideo' for node in row[2].values())
        outputs={'58':{'images':[{'filename':'auxiliary-preview.png','subfolder':'','type':'output'}]}}
        if is_video:outputs['58']['videos']=[{'filename':'fixture.mp4','subfolder':'','type':'output'}]
        self.history[pid]={'prompt':row,'status':{'completed':True,'status_str':'success'},'outputs':outputs}
    def app(self):
        app=web.Application();r=web.RouteTableDef()
        @r.get('/system_stats')
        async def stats(req):return web.json_response({'devices':[{'name':'TEST · RTX 4060 mock','vram_total':8*1024**3}]})
        @r.get('/object_info')
        async def obj(req):return web.json_response(self.info)
        @r.get('/queue')
        async def queue(req):return web.json_response({'queue_running':self.running,'queue_pending':self.queued})
        @r.post('/prompt')
        async def prompt(req):
            payload=await req.json();self.last_payload=payload;self.post_count+=1;pid=uuid.uuid4().hex
            self.queued.append([self.post_count,pid,payload['prompt'],payload.get('extra_data',{}),['58']])
            if self.timeout_reply:return web.json_response({'error':'lost response'},status=503)
            return web.json_response({'prompt_id':pid})
        @r.get('/history')
        async def hist(req):return web.json_response(self.history)
        @r.get('/history/{pid}')
        async def one(req):return web.json_response({req.match_info['pid']:self.history[req.match_info['pid']]} if req.match_info['pid'] in self.history else {})
        @r.post('/upload/image')
        async def upload(req):
            data=await req.post();self.upload_count+=1
            with Image.open(data['image'].file) as im:im.verify()
            return web.json_response({'name':data['image'].filename,'subfolder':'','type':'input'})
        @r.get('/view')
        async def view(req):
            if req.query.get('filename','').endswith('.mp4'):return web.Response(body=self.video,content_type='video/mp4')
            return web.Response(body=self.png,content_type='image/png',headers={'Accept-Ranges':'bytes'})
        @r.get('/ws')
        async def ws(req):
            socket=web.WebSocketResponse();await socket.prepare(req);key=req.query.get('clientId');self.sockets[key]=socket
            try:
                async for _ in socket:pass
            finally:self.sockets.pop(key,None)
            return socket
        @r.get('/api/tags')
        async def tags(req):return web.json_response({'models':[{'name':'gemma3:4b'}]})
        @r.post('/api/chat')
        async def chat(req):self.last_chat=await req.json();return web.json_response({'message':{'content':self.chat_response or 'A quiet lakeside cabin, warm dawn light, slow camera push.'}})
        @r.post('/api/jobs/{pid}/cancel')
        async def cancel(req):
            pid=req.match_info['pid'];self.queued=[x for x in self.queued if x[1]!=pid];self.running=[x for x in self.running if x[1]!=pid]
            self.history[pid]={'status':{'status_str':'error','completed':False,'messages':[['execution_interrupted',{}]]}}
            return web.json_response({'cancelled':True})
        app.add_routes(r);return app

if __name__=='__main__':web.run_app(FakeComfy().app(),host='127.0.0.1',port=18188)
