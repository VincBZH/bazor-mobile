// DOM unit tests, without a browser or network. Run with JSDOM_MODULE pointing to jsdom.
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {JSDOM}=require(process.env.JSDOM_MODULE||'jsdom');
const root=path.join(__dirname,'../app/static');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8').replace('<script src="/static/app.js" defer></script>','');
const dom=new JSDOM(html,{url:'http://localhost:8190',runScripts:'outside-only',pretendToBeVisual:true});
const w=dom.window;let records=[],postCount=0,lastParams,errors=[];
w.addEventListener('error',e=>errors.push(e.message));w.scrollTo=()=>{};w.HTMLElement.prototype.scrollIntoView=()=>{};
w.WebSocket=class{constructor(){setTimeout(()=>this.onopen?.(),0)}close(){}};
w.fetch=async(url,opts={})=>{
 let result={};const body=opts.body?JSON.parse(opts.body):{};
 if(url==='/api/config')result={token:'test',version:'3.0.5'};
 if(url==='/api/health')result={ready:true,comfy:true,ollama:true,models:['gemma3:4b'],checkpoints:['sdxl_test.safetensors'],devices:[]};
 if(url==='/api/estimate')result={seconds:null,samples:0};
 if(url==='/api/optimize')result={prompt:'A quiet lake at dawn.',original:body.prompt};
 if(url==='/api/log')result={lines:['Test in memory']};
 if(url==='/api/jobs'&&opts.method==='POST'){
   postCount++;lastParams=body;
   const j={id:'fixture-job',created:100,status:'done',params:body,stage:'Création terminée',outputs:[{media:'image',url:'/api/media/fixture-job/0'}]};records=[j];result=j;
 }else if(url==='/api/jobs')result={jobs:records};
 return {ok:true,text:async()=>JSON.stringify(result)};
};
w.eval(fs.readFileSync(path.join(root,'app.js'),'utf8'));
const wait=()=>new Promise(r=>setTimeout(r,25));
const click=sel=>{const e=w.document.querySelector(sel);assert(e,'Missing '+sel);e.click()};
const field=(id,value)=>{const e=w.document.getElementById(id);e.value=value;e.dispatchEvent(new w.Event('input',{bubbles:true}))};
(async()=>{
 await wait();assert(w.document.getElementById('connectionText').textContent.includes('prêt'));assert.equal(w.document.getElementById('frames').max,'241');assert.equal(w.document.querySelector('#engine option').value,'sd');assert.equal(w.document.querySelectorAll('#engine option').length,1);
 click('[data-mode="i2v"]');assert(w.document.getElementById('uploadLabel').textContent==='Photo de départ ');
 field('prompt','A quiet lake');click('#generate');await wait();assert.equal(postCount,0);assert(w.document.getElementById('formError').textContent.includes('Ajoutez'));
 click('[data-mode="t2i"]');assert(w.document.getElementById('uploadArea').classList.contains('hidden'));assert(w.document.getElementById('frames').disabled);
 click('[data-preset="balanced"]');assert.equal(w.document.getElementById('width').value,'1024');
 click('#rotate');assert.equal(w.document.getElementById('width').value,'1024');assert.equal(w.document.getElementById('height').value,'1024');
 click('#optimize');await wait();assert.equal(w.document.getElementById('prompt').value,'A quiet lake at dawn.');
 click('#undoPrompt');assert.equal(w.document.getElementById('prompt').value,'A quiet lake');
 click('#generate');await wait();assert.equal(postCount,1);assert.equal(lastParams.frames,1);assert.equal(lastParams.mode,'t2i');assert(w.document.querySelector('#result img'));
 click('[data-view="gallery"]');assert(w.document.querySelector('.gallery-card'));assert.equal(w.document.getElementById('count').textContent,'1');
 click('[data-variant]');assert.equal(w.document.getElementById('seed').value,'-1');assert(!w.document.getElementById('view-create').classList.contains('hidden'));assert.equal(postCount,1);
 click('[data-view="diagnostic"]');await wait();assert(w.document.getElementById('logs').textContent.includes('Test in memory'));
 assert.equal(errors.length,0,errors.join('\n'));console.log('11 DOM scenarios passed: modes, required photo, still frames, presets, rotation, optimization, undo, submission, gallery, variant, diagnostics.');dom.window.close();
})().catch(e=>{console.error(e);dom.window.close();process.exitCode=1});
