"""Real FFmpeg assembly; controlled Comfy HTTP; no AI or GPU quality claims."""
import asyncio, hashlib, io, json, os, shutil, struct, subprocess, sys, tempfile, unittest, uuid
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch, AsyncMock
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app'))
from aiohttp import web, ClientSession
from aiohttp.test_utils import TestServer
from PIL import Image
try:
    from test_studio import IntegrationTests as BaseFixture
except ModuleNotFoundError:
    from .test_studio import IntegrationTests as BaseFixture
from workflows import parameters,build
from fake_comfy import object_info
from media_tools import ffmpeg_path,MediaTools
from model_setup import ModelSetup,family
from prompt_library import public_url,PromptParser,merge_negative,PublicResolver


class ImageAndSourceTests(unittest.TestCase):
    def test_i2i_encodes_reference_and_respects_transformation(self):
        p=parameters(dict(mode='i2i',engine='sd',prompt='lake',asset_id='ref',checkpoint='sdxl_test.safetensors',denoise=.32))
        g=build(p,object_info(),'reference.png')
        self.assertEqual(p['frames'],1)
        self.assertEqual(g['55']['class_type'],'VAEEncode')
        self.assertEqual(g['54']['inputs']['image'],['56',0])
        self.assertEqual(g['55']['inputs']['pixels'],['54',0])
        self.assertEqual(g['3']['inputs']['latent_image'],['55',0])
        self.assertEqual(g['3']['inputs']['denoise'],.32)
        self.assertEqual(g['58']['class_type'],'SaveImage')
        for d in (0,float('nan'),1.1):
            with self.assertRaises(ValueError):parameters(dict(prompt='lake',denoise=d))

    def test_public_source_urls_and_plaintext_parser(self):
        for u in ('file:///a','http://127.0.0.1/a','http://[::1]/','http://192.168.1.1','https://user:pass@example.com','http://localhost.','http://localhost','http://169.254.169.254','http://[::ffff:127.0.0.1]'):
            if u=='http://localhost.':continue # Resolver rejects trailing-dot localhost.
            with self.subTest(url=u),self.assertRaises(ValueError):public_url(u)
        self.assertEqual(public_url('https://example.com/prompts'),'https://example.com/prompts')
        p=PromptParser();p.feed('<pre><code>A slow camera along the calm lake.</code></pre><script type="application/json">{"meta":{"prompt":"A forest in the early morning light."}}</script><script>alert(1)</script>')
        self.assertEqual(len(p.prompts),2);self.assertNotIn('alert',str(p.prompts))
        self.assertEqual(merge_negative('hands, blur','Blur, extra arms'),'hands, blur, extra arms')

    def test_checkpoint_header_families_without_loading_tensors(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'m.safetensors'
            for key,want in [('conditioner.embedders.1.model.transformer.resblocks.0','sdxl'),('cond_stage_model.transformer.text_model.embeddings.position_embedding.weight','sd15'),('lora_unet.foo',None)]:
                data=json.dumps({'model.diffusion_model.input_blocks.0.0.weight':{},key:{}}).encode()
                p.write_bytes(struct.pack('<Q',len(data))+data)
                self.assertEqual(family(p),want)
            p.write_bytes(b'not a model');self.assertIsNone(family(p))


class AtelierTests(unittest.IsolatedAsyncioTestCase):
    asyncSetUp=BaseFixture.asyncSetUp
    start_ui=BaseFixture.start_ui
    asyncTearDown=BaseFixture.asyncTearDown
    post=BaseFixture.post
    job=BaseFixture.job

    @classmethod
    def setUpClass(cls):
        cls.fixture_dir=tempfile.TemporaryDirectory()
        cls.video=Path(cls.fixture_dir.name)/'two-colors.mp4'
        subprocess.run([ffmpeg_path(),'-hide_banner','-loglevel','error','-y','-f','lavfi','-i','color=red:s=256x256:d=1:r=24','-f','lavfi','-i','color=blue:s=256x256:d=1:r=24','-f','lavfi','-i','sine=frequency=440:duration=2','-filter_complex','[0:v][1:v]concat=n=2:v=1:a=0[v]','-map','[v]','-map','2:a','-c:v','libx264','-threads','2','-pix_fmt','yuv420p','-c:a','aac',str(cls.video)],check=True,capture_output=True,timeout=30)
    @classmethod
    def tearDownClass(cls):cls.fixture_dir.cleanup()

    async def test_preferences_prompt_memory_and_i2i_http(self):
        await self.post('/api/preferences',dict(negative='no letters, blurry eyes',sources='https://example.com/prompts'))
        data=io.BytesIO();Image.new('RGB',(128,96),'green').save(data,'PNG')
        a=await (await self.client.post('/api/upload',data=data.getvalue(),headers={'X-Studio-Token':self.token})).json()
        r,j=await self.job(mode='i2i',engine='sd',checkpoint='sdxl_test.safetensors',asset_id=a['id'],negative='no letters, duplicates',denoise=.3)
        self.assertEqual(r.status,200,j)
        self.assertEqual(j['params']['negative'],'no letters, blurry eyes, duplicates')
        self.assertEqual(self.fake.last_payload['prompt']['55']['class_type'],'VAEEncode')
        self.fake.complete(j['prompt_id']);await self.s.reconcile()
        r,res=await self.post('/api/image-reference',{'job_id':j['id'],'index':0});self.assertEqual(r.status,200,res)
        self.assertTrue(self.s.store.get('asset',res['asset']['id']))
        records=await (await self.client.get('/api/prompts')).json()
        self.assertEqual(records['prompts'][0]['job_id'],j['id']);self.assertEqual(records['prompts'][0]['asset_id'],a['id'])
        await self.client.close();await self.start_ui()
        prefs=await (await self.client.get('/api/preferences')).json()
        self.assertEqual(prefs['negative'],'no letters, blurry eyes')

    async def test_actual_video_import_tail_cut_split_preview_export(self):
        w=self.s.workshop;clip=await w.register(self.video,'Color fixture','Two color test')
        self.assertAlmostEqual(clip['duration'],2,delta=.07);self.assertTrue(clip['audio'])
        for name in clip['tail']:self.assertTrue((w.root/clip['id']/name).is_file())
        last=await w.reference(clip['id']);cut=await w.reference(clip['id'],end=.75)
        with Image.open(self.s.assets/(last['id']+'.png')) as im:r,g,b=im.getpixel((32,32));self.assertGreater(b,r+150)
        with Image.open(self.s.assets/(cut['id']+'.png')) as im:r,g,b=im.getpixel((32,32));self.assertGreater(r,b+150)
        p=w.new_project('Cut film');p=w.append(p['id'],clip,end=2)
        response,split=await self.post('/api/projects/'+p['id']+'/split',{'revision':p['revision'],'seconds':.5})
        self.assertEqual(response.status,200,split);self.assertEqual(len(split['items']),4)
        # Reorder to blue then red; remove the other two sections.
        p=w.save_project(p['id'],{**split,'items':[split['items'][2],split['items'][0]]})
        with self.assertRaisesRegex(ValueError,'timeline'):await w.export(p['id'],{'revision':0},lambda *args:None)
        result=await w.export(p['id'],{'revision':p['revision'],'width':256,'height':256,'fps':24},lambda *args:None)
        self.assertAlmostEqual(result['duration'],1,delta=.12);self.assertTrue(result['audio'])
        path=w.root/result['id']/'film.mp4';await w.media.pictures(path,path.parent,result)
        with Image.open(path.parent/'last.png') as im:r,g,b=im.getpixel((32,32));self.assertGreater(r,b+150)
        audio_log=await w.media.run([*w.media.input(path),'-vn','-af','volumedetect','-f','null','-'])
        self.assertNotIn('mean_volume: -inf',audio_log);self.assertIn('mean_volume:',audio_log)
        response=await self.client.get(result['url']+'?download=1');self.assertEqual(response.status,200);self.assertIn('attachment',response.headers['Content-Disposition'])

    async def test_batch_chains_once_and_resumes_without_duplicate_generations(self):
        # Disable periodic tick for deterministic controlled advancement.
        for task in self.s.tasks:
            if getattr(task.get_coro(),'__qualname__','')=='Workshop.monitor':task.cancel()
        self.fake.video=self.video.read_bytes();w=self.s.workshop;p=w.new_project('Story')
        p=w.save_project(p['id'],{**p,'context':'A person in a blue coat by the lake.'})
        raw=dict(params=dict(prompt='lake',seed=11),prompts=['Walk slowly.','Look toward the water.'],chain=True)
        key=uuid.uuid4().hex;b=w.batch(p['id'],raw,key)
        self.assertEqual(w.batch(p['id'],raw,key)['job_ids'],b['job_ids'])
        await w.tick();first=self.s.store.get('job',b['job_ids'][0]);self.assertEqual(self.fake.post_count,1)
        await w.tick();self.assertEqual(self.fake.post_count,1)
        self.fake.complete(first['prompt_id']);self.fake.history[first['prompt_id']]['outputs']={'58':{'videos':[dict(filename='fixture.mp4',type='output',subfolder='')]}}
        await self.s.reconcile();await w.tick();self.assertEqual(w.get('batch',key)['index'],1)
        await self.client.close();await self.start_ui();w=self.s.workshop
        self.assertEqual(w.get('batch',key)['status'],'paused')
        r,_=await self.post('/api/batches/'+key+'/resume',{});self.assertEqual(r.status,200)
        await w.tick();second=self.s.store.get('job',b['job_ids'][1]);self.assertIsNotNone(second)
        self.assertEqual(self.fake.post_count,2);self.assertIn('blue coat',second['params']['prompt'])
        self.assertEqual(second['params']['mode'],'i2v');self.assertTrue(second['params']['asset_id'])
        self.assertEqual(self.fake.last_payload['prompt']['55']['inputs']['start_image'],['56',0])
        await self.post('/api/batches/'+key+'/pause',{});await w.tick();self.assertEqual(self.fake.post_count,2)
        self.fake.complete(second['prompt_id']);self.fake.history[second['prompt_id']]['outputs']={'58':{'videos':[dict(filename='fixture.mp4',type='output',subfolder='')]}}
        await self.s.reconcile();await self.post('/api/batches/'+key+'/resume',{});await w.tick();await w.tick()
        self.assertEqual(w.get('batch',key)['status'],'done');items=w.get('project',p['id'])['items']
        self.assertEqual(len(items),2);self.assertAlmostEqual(items[1]['start'],1/24);self.assertEqual(self.fake.post_count,2)

    async def test_source_import_filters_and_deduplicates(self):
        async def fetch(session,url,redirects=0):
            return ('',url) if url.endswith('/robots.txt') else ('<pre>A golden lake at dawn, a slow camera movement.</pre><pre>A forest under heavy rain, trees sway.</pre>',url)
        with patch.object(self.s.prompt_library,'fetch',side_effect=fetch):
            result=await self.s.prompt_library.harvest(dict(sources='https://example.com/prompts',keyword='lake'),lambda *a:None)
            self.assertEqual(result['count'],1)
            again=await self.s.prompt_library.harvest(dict(sources='https://example.com/prompts',keyword='lake'),lambda *a:None)
            self.assertEqual(again['count'],0)
        self.assertEqual(self.s.store.all('prompt')[0]['source'],'https://example.com/prompts')
        with patch.object(asyncio.get_running_loop(),'getaddrinfo',new=AsyncMock(return_value=[(2,1,6,'',('127.0.0.1',80))])):
            with self.assertRaisesRegex(ValueError,'non publique'):await PublicResolver().resolve('test.example',80)


class ModelDownloadTests(unittest.IsolatedAsyncioTestCase):
    async def test_scan_existing_model_preserves_original_and_ignores_lora(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);comfy=root/'ComfyUI';comfy.mkdir();(comfy/'main.py').touch()
            forge=root/'Forge'/'webui'/'models'/'Stable-diffusion';forge.mkdir(parents=True)
            data=json.dumps({'model.diffusion_model.input_blocks.0.0.weight':{},'conditioner.embedders.1.model.transformer.resblocks.0':{}}).encode()
            source=forge/'existing.safetensors';source.write_bytes(struct.pack('<Q',len(data))+data)
            (forge/'lora.safetensors').write_bytes(b'not a checkpoint')
            setup=ModelSetup(SimpleNamespace(info_at=1));setup.comfy=comfy;setup.air=root
            result=await setup.scan(lambda *args:None);self.assertEqual(len(result['found']),1)
            linked=setup.checkpoint_dir()/result['found'][0]
            self.assertEqual(linked.read_bytes(),source.read_bytes());self.assertTrue(source.exists())
            self.assertEqual((await setup.scan(lambda *args:None))['found'],[])
            self.assertEqual(setup.details()['models'][0]['family'],'sdxl')

    async def test_verified_resumable_download_and_no_overwrite(self):
        data=b'checkpoint fixture bytes'*50;offset=93;seen=[]
        async def serve(req):
            seen.append(req.headers.get('Range'));start=int(req.headers.get('Range','bytes=0-').split('=')[1].split('-')[0])
            return web.Response(body=data[start:],status=206,headers={'Content-Range':f'bytes {start}-{len(data)-1}/{len(data)}'})
        app=web.Application();app.router.add_get('/model',serve)
        async with TestServer(app) as server,ClientSession() as session:
            with tempfile.TemporaryDirectory() as d:
                root=Path(d);(root/'main.py').touch();s=SimpleNamespace(session=session,info_at=1);setup=ModelSetup(s);setup.comfy=root
                target=setup.checkpoint_dir()/'fixture.safetensors';part=target.with_suffix('.safetensors.part');part.write_bytes(data[:offset])
                with patch.multiple('model_setup',MODEL_NAME=target.name,MODEL_URL=str(server.make_url('/model')),MODEL_SHA256=hashlib.sha256(data).hexdigest(),MODEL_SIZE=len(data)):
                    await setup.install(lambda *args:None);self.assertEqual(target.read_bytes(),data);self.assertEqual(seen,['bytes=93-']);self.assertFalse(part.exists())
                    await setup.install(lambda *args:None);self.assertEqual(len(seen),1)
                    target.write_bytes(b'user model')
                    with self.assertRaisesRegex(ValueError,'conservé'):await setup.install(lambda *args:None)
                    self.assertEqual(target.read_bytes(),b'user model')

del BaseFixture  # Imported fixture helpers should not duplicate the original test suite.
if __name__=='__main__':unittest.main(verbosity=2)
