// Both scripts execute in the same DOM global scope; HTTP and playback are controlled fixtures.
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const {JSDOM}=require(process.env.JSDOM_MODULE||'jsdom');
const root=path.join(__dirname,'../app/static');
const dom=new JSDOM(fs.readFileSync(path.join(root,'index.html'),'utf8'),{url:'http://localhost:8191',runScripts:'outside-only',pretendToBeVisual:true});
const w=dom.window,d=w.document,clone=x=>JSON.parse(JSON.stringify(x));let errors=[],requests=[],serial=1,lastGeneration,lastBatch;
w.addEventListener('error',e=>errors.push(e.message));w.scrollTo=()=>{};w.HTMLElement.prototype.scrollIntoView=()=>{};
w.HTMLMediaElement.prototype.pause=function(){};
w.HTMLMediaElement.prototype.play=function(){this.onplay?.();return Promise.resolve()};
w.HTMLMediaElement.prototype.load=function(){queueMicrotask(()=>this.onloadedmetadata?.())};
w.WebSocket=class{close(){}};
let state={projects:[{id:'p1',name:'Film',context:'Same blue coat',items:[],revision:0}],clips:['a','b'].map((id,i)=>({id,title:'Clip '+id,prompt:'A calm lake '+id,params:{mode:'i2v',width:832,height:480,frames:49,fps:24,steps:24},duration:4,fps:24,width:832,height:480,url:'/clip/'+id,thumbnail:'/thumb/'+id,tail:['tail0.jpg','tail1.jpg','tail2.jpg','last.png']})),batches:[],operations:[],exports:[],ffmpeg:true};
let prefs={negative:'flicker, extra hands',sources:'https://example.com/prompts',keyword:'lake'},jobs=[],prompts=[];
w.fetch=async(url,opts={})=>{
 const body=opts.body?JSON.parse(opts.body):{},method=opts.method||'GET';requests.push({url,method,body});let out={};
 if(url==='/api/config')out={token:'test',version:'3.0.5'};
 else if(url==='/api/health')out={ready:true,comfy:true,ollama:true,models:['gemma3:4b'],checkpoints:['sdxl_test.safetensors'],devices:[]};
 else if(url==='/api/estimate')out={seconds:null};
 else if(url==='/api/preferences'){if(method==='POST')prefs={...prefs,...body};out=prefs}
 else if(url==='/api/image-models')out={models:[{name:'sdxl_test.safetensors',family:'sdxl'}]};
 else if(url==='/api/workshop')out=state;
 else if(url==='/api/prompts'){if(method==='POST')prompts.push({...body,id:'prompt'+serial++,mode:body.mode});out=method==='POST'?prompts.at(-1):{prompts}}
 else if(url==='/api/jobs'&&method==='POST'){lastGeneration=body;out={id:'job'+serial++,status:'done',params:body,created:1,stage:'done',outputs:[{media:'image',url:'/generated.png'}]};jobs.unshift(out)}
 else if(url==='/api/jobs')out={jobs};
 else if(url==='/api/image-reference')out={asset:{id:'ref',url:'/ref.png'},prompt:'A person beside a calm lake'};
 else if(url==='/api/projects'){out={id:'p'+serial++,name:body.name,context:'',items:[],revision:0};state.projects.push(out)}
 else if(/^\/api\/projects\/[^/]+$/.test(url)){out={...body,revision:body.revision+1};state.projects=state.projects.map(p=>p.id===out.id?out:p)}
 else if(url.endsWith('/reference'))out={asset:{id:'tailref',url:'/tailref.png'},clip:state.clips.find(c=>url.includes('/'+c.id+'/'))};
 else if(url.endsWith('/batch')){lastBatch=body;out={id:'batch',status:'running',project_id:url.split('/')[3],index:0,prompts:body.prompts,stage:'queued'};state.batches.push(out)}
 else if(url.endsWith('/export'))out={id:'op',status:'queued'};
 else if(url==='/api/log')out={lines:[]};
 const text=JSON.stringify(clone(out));return {ok:true,text:async()=>text,json:async()=>JSON.parse(text)};
};
for(const script of ['app.js','atelier.js'])vm.runInContext(fs.readFileSync(path.join(root,script),'utf8'),dom.getInternalVMContext());
const wait=()=>new Promise(r=>setTimeout(r,35)),click=sel=>{assert(d.querySelector(sel),'Missing '+sel);d.querySelector(sel).click()},field=(id,value,event='input')=>{const el=d.getElementById(id);el.value=value;el.dispatchEvent(new w.Event(event,{bubbles:true}))};
(async()=>{
 await wait();assert.equal(d.getElementById('globalNegative').value,prefs.negative);assert.equal(d.querySelectorAll('.bin-card').length,2);
 click('[data-mode="i2i"]');assert.equal(d.getElementById('engine').value,'sd');assert(!d.getElementById('uploadArea').classList.contains('hidden'));assert(!d.getElementById('denoiseArea').classList.contains('hidden'));
 // Reuse a generated image via the actual delegated action.
 const ref=d.createElement('button');ref.dataset.imageJob='existing-image';ref.dataset.imageMode='i2i';d.body.appendChild(ref);ref.click();await wait();field('denoise','.35');click('#generate');await wait();
 assert.equal(lastGeneration.asset_id,'ref');assert.equal(lastGeneration.mode,'i2i');assert.equal(lastGeneration.denoise,.35);assert.equal(lastGeneration.frames,1);assert.equal(lastGeneration.width,1024);
 click('#savePrompt');await wait();assert.equal(prompts[0].asset_id,'ref');assert.equal(d.querySelectorAll('.prompt-card').length,1);
 field('negative','no captions, no duplicates');click('#rememberNegative');await wait();assert.equal(prefs.negative,'no captions, no duplicates');
 click('[data-mode="i2v"]');field('clipDuration','97','change');click('[data-preset="quality"]');assert.equal(d.getElementById('frames').value,'97');assert.equal(d.getElementById('width').value,'1280');
 click('[data-view="montage"]');await wait();assert(d.getElementById('exportFilm').disabled);
 click('[data-add-clip="a"]');await wait();click('[data-add-clip="b"]');await wait();assert.equal(state.projects[0].items.length,2);assert.equal(d.querySelectorAll('.timeline-card').length,2);
 click('.timeline-card [data-move="1"]');await wait();assert.equal(state.projects[0].items[0].clip_id,'b');
 const trim=d.querySelector('.timeline-card [data-trim="end"]');trim.value='2';trim.dispatchEvent(new w.Event('change',{bubbles:true}));await wait();assert.equal(state.projects[0].items[0].end,2);
 click('#playTimeline');await wait();assert(!d.getElementById('exportFilm').disabled);assert(d.getElementById('filmPreview').src.endsWith('/b'));
 const video=d.getElementById('filmPreview');video.currentTime=2;video.ontimeupdate();await wait();assert(video.src.endsWith('/a'));assert(d.getElementById('previewLabel').textContent.includes('2 / 2'));
 click('#exportFilm');await wait();assert.equal(requests.filter(r=>r.url.endsWith('/export')).length,1);
 click('.timeline-card [data-continue-clip]');await wait();assert(d.getElementById('tailNote').textContent.includes('coupe'));assert.equal(requests.filter(r=>r.url.endsWith('/reference')).at(-1).body.end,2);
 field('scenePrompts','Turn slowly.\nWalk toward the lake.');click('#startBatch');await wait();assert.equal(lastBatch.initial_clip,'b');assert.equal(lastBatch.initial_asset,'tailref');assert.equal(lastBatch.prompts.length,2);assert(lastBatch.chain);
 assert.equal(lastBatch.params.mode,'i2v');assert.equal(lastBatch.params.frames,97);
 click('[data-view="prompts"]');await wait();click('[data-library-prompt]');await wait();assert.equal(d.getElementById('denoise').value,'0.35');assert(!d.getElementById('uploadArea').classList.contains('hidden'));assert.equal(d.getElementById('assetPreview').getAttribute('src'),'/api/assets/ref');
 click('[data-mode="t2i"]');assert(d.getElementById('installSDXL').classList.contains('hidden'),'SDXL déjà présent : le bouton d’installation doit être masqué');
 assert.deepEqual(errors,[]);console.log('14 atelier DOM scenarios passed: initialization, i2i, generated reference, prompt save, exclusions, duration, clips, order, cuts, preview, export, continuation, batch, model install.');dom.window.close();
})().catch(e=>{console.error(e);dom.window.close();process.exitCode=1});
