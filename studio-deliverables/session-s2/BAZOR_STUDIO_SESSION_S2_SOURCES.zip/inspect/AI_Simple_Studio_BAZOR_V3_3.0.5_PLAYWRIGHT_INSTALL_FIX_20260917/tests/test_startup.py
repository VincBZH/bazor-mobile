"""Regression checks for embedded/isolated Python and startup diagnostics."""
import json,os,shutil,socket,subprocess,sys,tempfile,time,unittest,urllib.request
from pathlib import Path
APP=Path(__file__).resolve().parents[1]/'app'

class StartupTests(unittest.TestCase):
    def test_isolated_import_from_other_working_directory(self):
        with tempfile.TemporaryDirectory(prefix='studio cwd ') as d:
            r=subprocess.run([sys.executable,'-I',str(APP/'studio.py'),'--help'],cwd=d,capture_output=True,text=True,timeout=15)
            self.assertEqual(r.returncode,0,r.stderr)
            self.assertIn('--port',r.stdout)
    def test_preflight_in_isolated_python(self):
        r=subprocess.run([sys.executable,'-I',str(APP/'check_startup.py')],capture_output=True,text=True,timeout=15)
        self.assertEqual(r.returncode,0,r.stderr)
        self.assertEqual(json.loads(r.stdout)['version'],'3.0.5')
        self.assertTrue(json.loads(r.stdout)['isolated'])
    def test_missing_module_report_is_visible_and_nonzero(self):
        with tempfile.TemporaryDirectory() as d:
            for name in ('check_startup.py','studio.py'):
                shutil.copyfile(APP/name,Path(d)/name)
            r=subprocess.run([sys.executable,'-I',str(Path(d)/'check_startup.py')],cwd=d,capture_output=True,text=True,timeout=15)
            self.assertEqual(r.returncode,1)
            self.assertIn('CONTROLE DU DEMARRAGE EN ECHEC',r.stderr)
            self.assertIn('workflows',r.stderr)
    def test_actual_http_server_starts_isolated_without_comfy(self):
        with tempfile.TemporaryDirectory(prefix='studio data ') as tmp:
            with socket.socket() as s:
                s.bind(('127.0.0.1',0));port=s.getsockname()[1]
            env=os.environ.copy();env['COMFY_URL']='http://127.0.0.1:1';env['OLLAMA_URL']='http://127.0.0.1:1'
            child=subprocess.Popen([sys.executable,'-I',str(APP/'studio.py'),'--port',str(port),'--data',str(Path(tmp)/'data')],cwd=tmp,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
            try:
                deadline=time.monotonic()+12;data=None
                while time.monotonic()<deadline and child.poll() is None:
                    try:
                        with opener.open(f'http://127.0.0.1:{port}/api/ping',timeout=.3) as r:data=json.load(r)
                        break
                    except (OSError,ValueError):time.sleep(.06)
                self.assertIsNotNone(data,'Isolated server did not become healthy')
                self.assertEqual(data['version'],'3.0.5')
                with opener.open(f'http://127.0.0.1:{port}/',timeout=2) as r:page=r.read().decode()
                self.assertIn('AI Simple Studio',page)
                with opener.open(f'http://127.0.0.1:{port}/static/app.js',timeout=2) as r:self.assertEqual(r.status,200)
            finally:
                child.terminate()
                try:child.communicate(timeout=7)
                except subprocess.TimeoutExpired:child.kill();child.communicate()

if __name__=='__main__':unittest.main(verbosity=2)
