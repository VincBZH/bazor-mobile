import json
import struct
import tempfile
import unittest
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))

from model_cli import repair, scan


class ModelCliTests(unittest.TestCase):
    def test_repair_imports_valid_forge_checkpoint_without_download(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "ComfyUI" / "main.py").parent.mkdir(parents=True)
            (root / "ComfyUI" / "main.py").touch()
            forge = root / "Forge" / "webui" / "models" / "Stable-diffusion"
            forge.mkdir(parents=True)
            header = json.dumps({
                "model.diffusion_model.input_blocks.0.0.weight": {},
                "conditioner.embedders.1.model.transformer.resblocks.0": {},
            }).encode()
            source = forge / "portrait.safetensors"
            source.write_bytes(struct.pack("<Q", len(header)) + header)

            scanned = scan(root)
            self.assertEqual(scanned["status"], "ready")
            self.assertEqual(len(scanned["found"]), 1)
            result = repair(root)
            self.assertEqual(result["status"], "ready")
            imported = root / "ComfyUI" / "models" / "checkpoints" / scanned["found"][0]
            self.assertTrue(imported.is_file())
            self.assertEqual(imported.read_bytes(), source.read_bytes())
            self.assertTrue(source.is_file())


if __name__ == "__main__":
    unittest.main(verbosity=2)
