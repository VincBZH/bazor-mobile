import unittest
from pathlib import Path


class InstallerScriptTests(unittest.TestCase):
    def test_playwright_probe_cannot_abort_stop_preference_installer(self):
        script = (Path(__file__).resolve().parents[1] / 'Installer.ps1').read_text(encoding='utf-8-sig')
        self.assertIn('function Invoke-PythonCommand', script)
        self.assertIn("$ErrorActionPreference='Continue'", script)
        self.assertIn('$output=@(& $Python @Arguments 2>&1)', script)
        self.assertIn("@('-c','import playwright')", script)
        self.assertNotIn('& $autopilotPython -c "import playwright" 2>$null', script)


if __name__ == '__main__':
    unittest.main(verbosity=2)
