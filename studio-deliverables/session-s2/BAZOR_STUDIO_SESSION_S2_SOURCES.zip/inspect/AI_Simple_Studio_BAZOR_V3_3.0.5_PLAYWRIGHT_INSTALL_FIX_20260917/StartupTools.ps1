﻿# Shared by installation and launch. Compatible with Windows PowerShell 5.1.
function Read-StudioRelease([string]$Root) {
  $path=Join-Path $Root 'release.json'
  if(-not (Test-Path -LiteralPath $path -PathType Leaf)){throw 'release.json absent. Extraire tout le nouveau ZIP.'}
  $release=Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json
  if($release.version -ne '3.0.5' -or $release.build_id -notmatch '^[a-f0-9]{64}$' -or -not $release.files) {
    throw 'Le dossier extrait ne correspond pas a la livraison V3 (3.0.5) attendue.'
  }
  return $release
}

function Assert-StudioFiles([string]$Root,$Release) {
  $count=0
  foreach($entry in $Release.files.PSObject.Properties) {
    if($entry.Name -notmatch '^[A-Za-z0-9_./-]+$' -or $entry.Name.StartsWith('/') -or $entry.Name.Split('/') -contains '..') {throw 'Chemin de livraison invalide.'}
    $file=Join-Path $Root $entry.Name
    if(-not (Test-Path -LiteralPath $file -PathType Leaf)){throw ('Fichier absent : '+$file)}
    if((Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash -ne $entry.Value){throw ('Fichier incomplet ou mauvaise version : '+$file)}
    $count++
  }
  if($count -lt 10){throw 'Liste de fichiers de livraison incomplete.'}
  return $count
}

function Test-StudioIdentity($Ping,$Expected) {
  if(-not $Ping -or -not $Expected){return $false}
  return ($Ping.app -eq 'ai-simple-studio-v2' -and $Ping.version -eq $Expected.version -and
    $Ping.build_id -eq $Expected.build_id -and $Ping.install_root -eq $Expected.install_root)
}

function Select-StudioPort($Candidates,$Expected) {
  $free=0;$ignored=@()
  foreach($candidate in $Candidates) {
    if(Busy $candidate) {
      $ping=Api "http://127.0.0.1:$candidate/api/ping"
      if(Test-StudioIdentity $ping $Expected){return @{port=$candidate;attached=$true;ignored=$ignored}}
      if($ping -and $ping.app -eq 'ai-simple-studio-v2') {
        $ignored+=@{port=$candidate;version=$ping.version;install_root=$ping.install_root}
      }
    } elseif($free -eq 0){$free=$candidate}
  }
  return @{port=$free;attached=$false;ignored=$ignored}
}

function Copy-StudioRelease([string]$Source,[string]$Target,$Release) {
  # Copy each manifest file to its exact path, then independently verify the installed bytes.
  foreach($entry in $Release.files.PSObject.Properties) {
    $dest=Join-Path $Target $entry.Name
    New-Item -ItemType Directory -Path (Split-Path $dest) -Force | Out-Null
    Copy-Item -LiteralPath (Join-Path $Source $entry.Name) -Destination $dest -Force
  }
  Copy-Item -LiteralPath (Join-Path $Source 'release.json') -Destination (Join-Path $Target 'release.json') -Force
  return (Assert-StudioFiles $Target $Release)
}

function Get-StudioProcessPattern([string]$Root,[string]$ScriptName) {
  $full=[IO.Path]::GetFullPath((Join-Path $Root ('app/'+$ScriptName)))
  return '(?:^|[\s"])'+[regex]::Escape($full)+'(?:[\s"]|$)'
}

function Get-LiveOwnedStudioProcess([int]$ProcessId,[string]$CreationDate,[string]$Pattern) {
  $live=Get-CimInstance Win32_Process -Filter ('ProcessId='+$ProcessId) -ErrorAction SilentlyContinue
  if($live -and $live.CommandLine -and $live.CommandLine -match $Pattern -and $live.CreationDate -eq $CreationDate){return $live}
  return $null
}

function Stop-InstalledStudio([string]$Root) {
  $stopped=@()
  if(-not (Test-Path -LiteralPath (Join-Path $Root 'app'))){return $stopped}
  Set-Content -LiteralPath (Join-Path $Root 'stop.flag') -Value 'update' -Encoding Ascii
  foreach($name in @('watchdog.py','studio.py')) {
    $pattern=Get-StudioProcessPattern $Root $name
    $found=@(Get-CimInstance Win32_Process -ErrorAction Stop | Where-Object {
      $_.Name -match '^python(?:w|[0-9.]*)?\.exe$' -and $_.CommandLine -match $pattern
    })
    foreach($item in $found) {
      $processId=[int]$item.ProcessId
      $live=Get-LiveOwnedStudioProcess $processId $item.CreationDate $pattern
      if(-not $live){continue}
      $method='Stop-Process -Force';$stopError=''
      try {Stop-Process -Id $processId -Force -ErrorAction Stop}
      catch {$stopError=$_.Exception.Message}

      # Stop-Process can return successfully while a Python child or a
      # process owned by an earlier elevated launcher is still alive. Recheck
      # the exact command line and terminate only this verified Studio
      # process tree. ComfyUI (8188) never matches this pattern.
      $live=Get-LiveOwnedStudioProcess $processId $item.CreationDate $pattern
      if($live) {
        $method='taskkill /PID /T /F'
        $killOutput=@(& taskkill.exe /PID ([string]$processId) /T /F 2>&1)
        $killCode=$LASTEXITCODE
        if($killCode -ne 0) {
          $detail=($killOutput -join ' ').Trim()
          if(-not $detail){$detail=$stopError}
          throw ('Arret refuse pour le PID '+$processId+' (taskkill '+$killCode+') : '+$detail)
        }
      }
      $deadline=(Get-Date).AddSeconds(10)
      do {
        Start-Sleep -Milliseconds 250
        $live=Get-LiveOwnedStudioProcess $processId $item.CreationDate $pattern
      } while($live -and (Get-Date) -lt $deadline)
      if($live){throw ('Ancien Studio encore actif : PID '+$processId+'. Arret impossible avec les droits actuels. '+$stopError)}
      $stopped+=@{pid=$processId;script=$name;method=$method}
    }
  }
  return $stopped
}
