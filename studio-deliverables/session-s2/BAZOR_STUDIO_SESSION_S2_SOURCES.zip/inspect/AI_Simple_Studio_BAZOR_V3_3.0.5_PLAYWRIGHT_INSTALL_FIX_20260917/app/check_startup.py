"""Bounded import check for the actual portable Python. No engine, model or user data is touched."""
import json,sys,traceback
from pathlib import Path


def main():
    try:
        appdir=Path(__file__).resolve().parent
        sys.path.insert(0,str(appdir))
        import studio
        from runtime_identity import identity
        for name in ('index.html','app.js','atelier.js','style.css'):
            if not (appdir/'static'/name).is_file():
                raise FileNotFoundError('Fichier absent : app/static/'+name+' ; extraire tout le ZIP.')
        with studio.sqlite3.connect(':memory:') as db:db.execute('SELECT 1')
        print(json.dumps({**identity(studio.VERSION,verify=True),'ok':True,'python':sys.version.split()[0],
                          'isolated':bool(sys.flags.isolated),'message':'Imports et fichiers de l’interface OK'},ensure_ascii=True))
        return 0
    except Exception:
        print('CONTROLE DU DEMARRAGE EN ECHEC',file=sys.stderr)
        traceback.print_exc()
        return 1

if __name__=='__main__':raise SystemExit(main())
