"""Watch only the Studio process, using one OS lock. Never manage ComfyUI."""
import argparse,contextlib,json,os,socket,subprocess,sys,time,urllib.request
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from runtime_identity import identity,matches


def acquire(path):
    f=open(path,'a+b');f.seek(0);f.write(b'0');f.flush();f.seek(0)
    try:
        if os.name=='nt':
            import msvcrt
            msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1)
        else:
            import fcntl
            fcntl.flock(f.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        return f
    except OSError:f.close();return None


def ping(port):
    try:
        opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(f'http://127.0.0.1:{port}/api/ping',timeout=2) as r:return json.load(r)
    except Exception:return None

def occupied(port):
    try:
        with socket.create_connection(('127.0.0.1',port),timeout=.3):return True
    except OSError:return False


def main():
    p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=8190);p.add_argument('--legacy',default=r'C:\AI\SimpleStudio');args=p.parse_args()
    root=Path(__file__).resolve().parent.parent;(root/'data').mkdir(exist_ok=True);(root/'logs').mkdir(exist_ok=True)
    expected=identity('3.0.5',verify=True)
    lock=acquire(root/'data'/'watchdog.lock')
    if lock is None:return
    flags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0
    with (root/'logs'/'watchdog.log').open('a',encoding='utf-8',buffering=1) as log:
        while True:
            if (root/'stop.flag').exists():return
            actual=ping(args.port)
            if matches(actual,expected):time.sleep(3);continue
            if actual or occupied(args.port):
                log.write(f'Port {args.port} occupé par une autre version ou installation. Aucune nouvelle instance sur ce port.\n')
                return 2
            log.write(time.strftime('%Y-%m-%d %H:%M:%S')+' Démarrage de l’interface uniquement.\n')
            child=subprocess.Popen([sys.executable,str(root/'app'/'studio.py'),'--port',str(args.port),'--data',str(root/'data'),'--legacy',args.legacy],cwd=root,stdout=log,stderr=log,creationflags=flags)
            (root/'data'/'server_pid.json').write_text(json.dumps({**expected,'pid':child.pid,'port':args.port}),encoding='utf-8')
            code=child.wait()
            log.write(f'Interface arrêtée ({code}). Reprise dans 4 secondes.\n');time.sleep(4)


if __name__=='__main__':raise SystemExit(main())
