"""Local Chrome/CDP bridge for the BAZOR Studio diagnostic panel.

The bridge attaches to an already running normal Chrome through the loopback
CDP endpoint. It never exposes a remote port and never removes the persistent
BAZOR profile. Playwright is optional at import time so the Studio remains
usable when the dependency has not yet been installed.
"""
from __future__ import annotations

import asyncio
import json
import os
import shutil
import subprocess
import time
from pathlib import Path
from urllib.request import ProxyHandler, Request, build_opener


class StudioAutomation:
    """Attach to BAZOR Chrome and exercise the ChatGPT profile menu safely."""

    def __init__(self, logger=None, debugger=None, logs_dir=None):
        self.logger = logger or (lambda message: None)
        self.debugger = debugger or (lambda event, **values: None)
        self.logs_dir = Path(logs_dir or Path.cwd() / "logs")
        self.port = int(os.environ.get("BAZOR_CDP_PORT", "9223"))
        self.profile = Path(os.environ.get(
            "BAZOR_EXPORT_AUTOPILOT_PROFILE",
            r"C:\BAZOR_EXPORT_AUTOPILOT\chrome_profile",
        ))
        self._lock = asyncio.Lock()
        self._playwright = None
        self._browser = None
        self._owned_chrome = None
        self._last = {
            "ok": False,
            "cdp": False,
            "playwright_attached": False,
            "port": self.port,
            "profile": str(self.profile),
            "pages": [],
        }

    def _log(self, message):
        self.logger("Autopilot Chrome : " + str(message))

    def _debug(self, event, **values):
        try:
            self.debugger("autopilot." + event, **values)
        except Exception:
            pass

    @property
    def endpoint(self):
        return f"http://127.0.0.1:{self.port}"

    @staticmethod
    def playwright_available():
        try:
            import playwright.async_api  # noqa: F401
            return True
        except Exception:
            return False

    def _cdp_json_sync(self, path):
        opener = build_opener(ProxyHandler({}))
        request = Request(self.endpoint + path, headers={"Accept": "application/json"})
        with opener.open(request, timeout=2) as response:
            raw = response.read(2 * 1024 * 1024)
        return json.loads(raw.decode("utf-8", "replace"))

    async def _cdp_json(self, path):
        try:
            return await asyncio.to_thread(self._cdp_json_sync, path)
        except Exception:
            return None

    async def _targets(self):
        targets = await self._cdp_json("/json")
        return targets if isinstance(targets, list) else []

    def _find_chrome(self):
        candidates = [
            os.path.join(os.environ.get("PROGRAMFILES", r"C:\Program Files"),
                         r"Google\Chrome\Application\chrome.exe"),
            os.path.join(os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)"),
                         r"Google\Chrome\Application\chrome.exe"),
            os.path.join(os.environ.get("LOCALAPPDATA", r"C:\Users\Public\AppData\Local"),
                         r"Google\Chrome\Application\chrome.exe"),
        ]
        for candidate in candidates:
            if Path(candidate).is_file():
                return candidate
        return shutil.which("chrome") or shutil.which("chrome.exe")

    async def status(self):
        version = await self._cdp_json("/json/version")
        targets = await self._targets()
        pages = [
            {"url": str(item.get("url") or "")[:500], "title": str(item.get("title") or "")[:200]}
            for item in targets
            if isinstance(item, dict) and item.get("type") == "page"
        ]
        result = {
            "ok": bool(version),
            "cdp": bool(version),
            "playwright_installed": self.playwright_available(),
            "playwright_attached": bool(self._browser),
            "endpoint": self.endpoint,
            "port": self.port,
            "profile": str(self.profile),
            "browser": str((version or {}).get("Browser") or "")[:200],
            "pages": pages,
            "last_action": self._last.get("action"),
            "last_message": self._last.get("message"),
        }
        self._last = {**self._last, **result}
        return result

    async def _wait_for_cdp(self, timeout=25):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            version = await self._cdp_json("/json/version")
            if isinstance(version, dict) and version.get("webSocketDebuggerUrl"):
                return version
            await asyncio.sleep(.4)
        return None

    async def _start_chrome(self):
        chrome = self._find_chrome()
        if not chrome:
            return {"ok": False, "code": "CHROME_NOT_FOUND", "message": "Google Chrome introuvable."}
        try:
            self.profile.mkdir(parents=True, exist_ok=True)
            args = [
                chrome,
                f"--user-data-dir={self.profile}",
                f"--remote-debugging-port={self.port}",
                "--remote-debugging-address=127.0.0.1",
                "--remote-allow-origins=http://127.0.0.1:" + str(self.port),
                "--no-first-run",
                "--no-default-browser-check",
                "--hide-crash-restore-bubble",
                "--start-maximized",
                "https://chatgpt.com/",
            ]
            creationflags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
            self._owned_chrome = subprocess.Popen(args, creationflags=creationflags)
            self._log(f"Chrome normal lancé avec CDP local sur {self.port}.")
            version = await self._wait_for_cdp()
            if not version:
                return {"ok": False, "code": "CDP_TIMEOUT", "message": "Chrome est ouvert, mais le CDP local ne répond pas."}
            return {"ok": True, "started": True}
        except Exception as exc:
            self._debug("chrome_start_error", error=str(exc)[:2000])
            return {"ok": False, "code": "CHROME_START_FAILED", "message": str(exc)[:2000]}

    async def _connect(self, start_if_missing=True):
        if not self.playwright_available():
            return {
                "ok": False,
                "code": "PLAYWRIGHT_MISSING",
                "message": "Playwright n’est pas installé dans le Python du Studio. Relance l’installation de cette version.",
            }
        version = await self._cdp_json("/json/version")
        started = False
        if not isinstance(version, dict) and start_if_missing:
            result = await self._start_chrome()
            if not result.get("ok"):
                return result
            started = True
            version = await self._cdp_json("/json/version")
        if not isinstance(version, dict) or not version.get("webSocketDebuggerUrl"):
            return {
                "ok": False,
                "code": "CDP_UNAVAILABLE",
                "message": f"Chrome normal n’est pas disponible sur le port CDP {self.port}.",
            }
        try:
            if self._browser and getattr(self._browser, "is_connected", lambda: False)():
                return {"ok": True, "started": started, "reused": True}
        except Exception:
            self._browser = None
        try:
            from playwright.async_api import async_playwright
            self._playwright = await async_playwright().start()
            self._browser = await self._playwright.chromium.connect_over_cdp(self.endpoint)
            self._log("Playwright rattaché à Chrome via CDP : OK.")
            self._debug("cdp_attach", endpoint=self.endpoint, started=started)
            return {"ok": True, "started": started, "reused": False}
        except Exception as exc:
            self._debug("cdp_attach_error", error=str(exc)[:2500])
            await self.disconnect()
            return {"ok": False, "code": "PLAYWRIGHT_ATTACH_FAILED", "message": str(exc)[:2500]}

    async def _chatgpt_page(self, open_if_missing=True):
        contexts = list(self._browser.contexts) if self._browser else []
        pages = [page for context in contexts for page in context.pages]
        page = next((p for p in pages if "chatgpt.com" in (p.url or "").lower()), None)
        if page:
            return page
        if not open_if_missing:
            return None
        context = contexts[0] if contexts else await self._browser.new_context()
        page = await context.new_page()
        await page.goto("https://chatgpt.com/", wait_until="domcontentloaded", timeout=30000)
        return page

    async def _profile_locator(self, page):
        selectors = [
            '[data-testid="accounts-profile-button"]',
            '[data-testid="profile-button"]',
            '[role="button"][aria-label*="profil"]',
            '[role="button"][aria-label*="profile"]',
            '[role="button"][aria-label*="compte"]',
        ]
        for selector in selectors:
            locator = page.locator(selector).first
            try:
                if await locator.count() and await locator.is_visible() and await locator.is_enabled():
                    return locator, selector
            except Exception:
                continue
        return None, None

    async def click_profile_button(self, page, locator, selector):
        """Click the profile control despite the sidebar pointer-event overlay.

        The first attempt deliberately uses Playwright's force click. If the
        action still fails, the second attempt runs in the page context: it
        temporarily disables pointer events on the intercepting parent, clicks
        the profile element, and restores the exact inline style in a finally
        block. No permanent DOM or CSS change is left behind.
        """
        attempts=[]; errors=[]
        try:
            await locator.click(force=True, timeout=5000)
            attempts.append("locator.click(force=True)")
            # Let the menu start its transition. If the site silently ignores
            # the forced event, continue to the requested page.evaluate path.
            await page.wait_for_timeout(250)
            state = await self._profile_state(page, locator)
            if str(state.get("ariaExpanded", "")).lower() == "true" or str(state.get("dataState", "")).lower() == "open" or state.get("visible_menu_count", 0):
                return {"ok": True, "method": attempts[-1], "attempts": attempts, "errors": errors}
            attempts.append("locator.click(force=True):no_menu")
        except Exception as exc:
            errors.append(str(exc)[:1200])
            attempts.append("locator.click(force=True):failed")
            self._debug("profile_force_click_failed", selector=selector, error=str(exc)[:1800])

        try:
            evaluated = await page.evaluate("""selector => {
                const el = document.querySelector(selector);
                if (!el) return {ok:false, reason:'target-not-found'};
                const parent = el.closest('div[class*="overflow-x-clip"]') || el.parentElement;
                if (!parent) return {ok:false, reason:'parent-not-found'};
                const oldValue = parent.style.getPropertyValue('pointer-events');
                const oldPriority = parent.style.getPropertyPriority('pointer-events');
                parent.style.setProperty('pointer-events', 'none', 'important');
                try {
                    el.click();
                    return {ok:true, parent:parent.tagName, parentClass:String(parent.className || '').slice(0,240)};
                } finally {
                    if (oldValue) parent.style.setProperty('pointer-events', oldValue, oldPriority);
                    else parent.style.removeProperty('pointer-events');
                }
            }""", selector)
            attempts.append("page.evaluate(pointer-events parent temporaire)")
            if not isinstance(evaluated, dict) or not evaluated.get("ok"):
                errors.append(json.dumps(evaluated, ensure_ascii=False)[:1000])
            return {"ok": bool(isinstance(evaluated, dict) and evaluated.get("ok")),
                    "method": attempts[-1], "attempts": attempts, "errors": errors,
                    "evaluate": evaluated}
        except Exception as exc:
            errors.append(str(exc)[:1200])
            attempts.append("page.evaluate(pointer-events parent temporaire):failed")
            self._debug("profile_evaluate_click_failed", selector=selector, error=str(exc)[:1800])
            return {"ok": False, "method": attempts[-1], "attempts": attempts, "errors": errors}

    async def _profile_state(self, page, locator):
        try:
            state = await locator.evaluate("""el => ({
                tag: el.tagName,
                ariaExpanded: el.getAttribute('aria-expanded'),
                dataState: el.getAttribute('data-state'),
                label: el.getAttribute('aria-label') || '',
                child: el.querySelector('img')?.getAttribute('alt') || ''
            })""")
        except Exception:
            state = {}
        try:
            state["visible_menu_count"] = await page.locator('[role="menu"]:visible').count()
        except Exception:
            state["visible_menu_count"] = 0
        return state

    async def _menu_open(self, page, locator):
        for _ in range(8):
            state = await self._profile_state(page, locator)
            if str(state.get("ariaExpanded", "")).lower() == "true" or str(state.get("dataState", "")).lower() == "open" or state.get("visible_menu_count", 0):
                return True, state
            await page.wait_for_timeout(150)
        return False, await self._profile_state(page, locator)

    async def _save_ui_debug(self, page, label):
        try:
            folder = self.logs_dir / "autopilot_ui"
            folder.mkdir(parents=True, exist_ok=True)
            stamp=time.strftime("%Y%m%d_%H%M%S")
            await page.screenshot(path=str(folder / f"{stamp}_{label}.png"), full_page=False)
            buttons = await page.locator('button,[role="button"]').evaluate_all("""els => els.map(el => ({
                text: (el.innerText || '').slice(0,240),
                aria: el.getAttribute('aria-label') || '',
                testid: el.getAttribute('data-testid') || '',
                tag: el.tagName
            })).slice(0,300)""")
            (folder / f"{stamp}_{label}.json").write_text(json.dumps(buttons, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as exc:
            self._debug("ui_debug_error", error=str(exc)[:1200])

    async def open_profile_menu(self, start_if_missing=True):
        async with self._lock:
            connected = await self._connect(start_if_missing=start_if_missing)
            if not connected.get("ok"):
                self._last = {**connected, "action": "profile_menu"}
                return self._last
            try:
                page = await self._chatgpt_page(open_if_missing=True)
                locator, selector = await self._profile_locator(page)
                if not locator:
                    await self._save_ui_debug(page, "profile_menu_missing")
                    result = {"ok": False, "code": "PROFILE_BUTTON_MISSING", "message": "Bouton du profil ChatGPT introuvable.", "page_url": page.url}
                    self._last = {**result, "action": "profile_menu"}
                    self._debug("profile_button_missing", page_url=page.url)
                    return self._last

                click_result = await self.click_profile_button(page, locator, selector)
                attempts=list(click_result.get("attempts", []))
                errors=list(click_result.get("errors", []))
                opened, state = await self._menu_open(page, locator)

                if not opened:
                    await self._save_ui_debug(page, "profile_menu_blocked")
                message = "Menu du profil ouvert." if opened else "Le clic du profil reste bloqué après les secours DOM/CDP."
                result = {
                    "ok": opened,
                    "action": "profile_menu",
                    "selector": selector,
                    "method": attempts[-1] if attempts else None,
                    "attempts": attempts,
                    "errors": errors[-4:],
                    "state": state,
                    "page_url": page.url,
                    "message": message,
                }
                self._last = result
                self._log(message)
                self._debug("profile_click", **{k: v for k, v in result.items() if k != "errors"}, errors=errors[-4:])
                return result
            except Exception as exc:
                result = {"ok": False, "action": "profile_menu", "code": "PROFILE_CLICK_FAILED", "message": str(exc)[:2500]}
                self._last = result
                self._debug("profile_click_error", error=str(exc)[:2500])
                return result

    async def attach(self, start_if_missing=True):
        """Attach to Chrome without navigating or clicking anything."""
        async with self._lock:
            result = await self._connect(start_if_missing=start_if_missing)
            status = await self.status()
            result = {**status, **result, "action": "attach"}
            self._last = result
            return result

    async def disconnect(self):
        """Disconnect Playwright without closing Chrome or deleting its profile."""
        try:
            if self._playwright:
                await self._playwright.stop()
        except Exception as exc:
            self._debug("disconnect_error", error=str(exc)[:1200])
        finally:
            self._playwright = None
            self._browser = None

    async def close(self):
        await self.disconnect()


# Compatibility name used by the Studio server while exposing the requested
# public automation class to integrations and tests.
BrowserAutopilot = StudioAutomation
