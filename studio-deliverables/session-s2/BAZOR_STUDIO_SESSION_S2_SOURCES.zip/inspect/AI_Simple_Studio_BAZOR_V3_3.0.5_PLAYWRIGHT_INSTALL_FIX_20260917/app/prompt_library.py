"""Local prompt memory and bounded import from user-selected public pages."""
import asyncio, hashlib, ipaddress, json, re, socket, time
from html.parser import HTMLParser
from urllib.parse import urlparse, urljoin
from urllib.robotparser import RobotFileParser
import aiohttp
from aiohttp import web

DEFAULT_NEGATIVE='flicker, morphing, extra limbs, extra hands, extra fingers, deformed hands, unstable faces, jitter, duplicate subjects, text artifacts'


def merge_negative(*values):
    seen=set();parts=[]
    for value in values:
        for part in re.split('[,\n]',str(value or '')):
            part=part.strip()
            if part and part.casefold() not in seen:seen.add(part.casefold());parts.append(part)
    return ', '.join(parts)[:6000]


def public_url(value):
    u=urlparse(str(value).strip())
    if u.scheme not in ('https','http') or not u.hostname or u.username or u.password or u.port not in (None,80,443):
        raise ValueError('Indique une URL publique complète, commençant par https://.')
    if u.hostname.lower() in ('localhost','metadata.google.internal') or u.hostname.lower().endswith(('.localhost','.local','.internal')):raise ValueError('Adresse locale interdite pour l’import de prompts.')
    try:
        if not ipaddress.ip_address(u.hostname).is_global:raise ValueError('Adresse privée interdite.')
    except ValueError as e:
        if 'interdite' in str(e):raise
    return u.geturl()


class PublicResolver(aiohttp.abc.AbstractResolver):
    async def resolve(self,host,port=0,family=socket.AF_INET):
        entries=await asyncio.get_running_loop().getaddrinfo(host,port,type=socket.SOCK_STREAM,family=family)
        result=[]
        for fam,_,proto,_,addr in entries:
            if not ipaddress.ip_address(addr[0]).is_global:raise ValueError('Le site pointe vers une adresse non publique.')
            result.append(dict(hostname=host,host=addr[0],port=port,family=fam,proto=proto,flags=socket.AI_NUMERICHOST))
        return result
    async def close(self):pass


class PromptParser(HTMLParser):
    def __init__(self):super().__init__();self.depth=0;self.parts=[];self.prompts=[];self.links=[];self.json_depth=0;self.json_parts=[]
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if tag=='a' and a.get('href'):self.links.append(a['href'])
        if a.get('data-prompt'):self.prompts.append(a['data-prompt'])
        if tag in ('pre','code','textarea'):
            if not self.depth:self.parts=[]
            self.depth+=1
        if tag=='script' and a.get('type') in ('application/json','application/ld+json'):self.json_depth=1;self.json_parts=[]
    def handle_data(self,data):
        if self.depth:self.parts.append(data)
        if self.json_depth:self.json_parts.append(data)
    def handle_endtag(self,tag):
        if tag in ('pre','code','textarea') and self.depth:
            self.depth-=1
            if not self.depth:self.prompts.append(''.join(self.parts))
        if tag=='script' and self.json_depth:
            self.json_depth=0
            try:
                def walk(x,depth=0):
                    if depth>12:return
                    if isinstance(x,dict):
                        for k,v in x.items():
                            if k.lower() in ('prompt','positiveprompt','positive_prompt') and isinstance(v,str):self.prompts.append(v)
                            elif isinstance(v,(dict,list)):walk(v,depth+1)
                    elif isinstance(x,list):
                        for v in x[:200]:walk(v,depth+1)
                walk(json.loads(''.join(self.json_parts)))
            except (ValueError,RecursionError):pass


class PromptLibrary:
    def __init__(self,s):self.s=s;self.store=s.store
    def preferences(self):return self.store.get('meta','preferences',{'negative':DEFAULT_NEGATIVE,'sources':'','keyword':''})
    def save(self,raw):
        prompt=str(raw.get('prompt','')).strip()
        if not 1<=len(prompt)<=6000:raise ValueError('Le prompt doit contenir entre 1 et 6000 caractères.')
        negative=str(raw.get('negative',''))[:6000];mode=str(raw.get('mode','t2v'))[:10]
        key=hashlib.sha256((prompt+'\0'+negative+'\0'+mode).encode()).hexdigest()[:32]
        old=self.store.get('prompt',key,{})
        p=dict(id=key,title=str(raw.get('title') or prompt[:80])[:120],prompt=prompt,negative=negative,mode=mode,
            params=raw.get('params') if isinstance(raw.get('params'),dict) else old.get('params',{}),source=str(raw.get('source',old.get('source','')))[:1500],
            job_id=raw.get('job_id') or old.get('job_id'),asset_id=raw.get('asset_id') or old.get('asset_id'),clip_id=raw.get('clip_id') or old.get('clip_id'),created=old.get('created',time.time()),updated=time.time())
        self.store.put('prompt',key,p);return p
    def remember_job(self,j):
        p=j['params'];return self.save(dict(prompt=p['prompt'],negative=p['negative'],mode=p['mode'],params=p,job_id=j['id'],asset_id=p.get('asset_id')))
    def delete(self,key):
        key=str(key)
        if not re.fullmatch('[a-f0-9]{32}',key):raise ValueError('Identifiant de prompt invalide.')
        if not self.store.get('prompt',key):raise ValueError('Prompt introuvable dans la bibliothèque.')
        self.store.delete('prompt',key)
        self.s.log('Prompt retiré de la bibliothèque : '+key)
        return {'ok':True,'id':key}

    async def fetch(self,session,url,redirects=0):
        url=public_url(url)
        if redirects>4:raise ValueError('Trop de redirections.')
        async with session.get(url,allow_redirects=False,timeout=aiohttp.ClientTimeout(total=20)) as r:
            if r.status in (301,302,303,307,308):return await self.fetch(session,urljoin(url,r.headers.get('Location','')),redirects+1)
            if r.status==404:return '',url
            if r.status!=200:raise ValueError(f'Page indisponible (HTTP {r.status}) : '+url)
            kind=r.headers.get('Content-Type','').lower()
            if not any(x in kind for x in ('text/','json','xhtml')):raise ValueError('La source ne contient pas une page texte.')
            out=bytearray()
            async for chunk in r.content.iter_chunked(65536):
                out.extend(chunk)
                if len(out)>2*1024*1024:raise ValueError('Page trop volumineuse.')
            return out.decode(r.charset or 'utf-8','replace'),url

    async def harvest(self,raw,progress):
        urls=[public_url(x.strip()) for x in str(raw.get('sources','')).splitlines() if x.strip()]
        if not 1<=len(urls)<=5:raise ValueError('Indique de 1 à 5 URL, une par ligne.')
        keyword=str(raw.get('keyword','')).strip().casefold()[:200];count=0;reports=[]
        connector=aiohttp.TCPConnector(resolver=PublicResolver(),use_dns_cache=False)
        async with aiohttp.ClientSession(connector=connector,trust_env=False,headers={'User-Agent':'AI-Simple-Studio/2.1 (user-requested prompt import)'}) as session:
            for n,url in enumerate(urls):
                progress(f'Lecture de la source {n+1}/{len(urls)}',n/len(urls))
                try:
                    origin=urlparse(url);robots_text,_=await self.fetch(session,urljoin(url,'/robots.txt'))
                    robots=RobotFileParser();robots.parse(robots_text.splitlines())
                    if robots_text and not robots.can_fetch('AI-Simple-Studio',url):raise ValueError('Le site refuse la collecte automatique dans robots.txt.')
                    todo=[url];visited=set();added=0
                    while todo and len(visited)<3:
                        page=todo.pop(0)
                        if page in visited:continue
                        if robots_text and not robots.can_fetch('AI-Simple-Studio',page):continue
                        visited.add(page);content,final_url=await self.fetch(session,page);parser=PromptParser();parser.feed(content)
                        for text in parser.prompts[:100]:
                            text=text.strip()
                            if not 25<=len(text)<=3000 or (keyword and keyword not in text.casefold()):continue
                            if any(x in text for x in ('import torch','pip install','<script','function(','def ')):continue
                            before=len(self.store.all('prompt'));self.save({'prompt':text,'source':final_url,'mode':raw.get('mode','t2v')})
                            if len(self.store.all('prompt'))>before:count+=1;added+=1
                            if added>=20:break
                        if added>=20:break
                        for link in parser.links:
                            full=urljoin(final_url,link);u=urlparse(full)
                            if u.hostname==origin.hostname and u.scheme in ('https','http') and re.search(r'prompt|example|gallery',u.path,re.I) and full not in visited and full not in todo:todo.append(full)
                    reports.append({'source':url,'message':f'{added} nouveaux prompts importés.' if added else 'Aucun nouveau prompt accessible trouvé. Les pages avec connexion ou contenu chargé uniquement en JavaScript nécessitent un import manuel.'})
                except Exception as e:reports.append({'source':url,'message':str(e)})
        return {'count':count,'reports':reports}

    def routes(self):
        r=web.RouteTableDef()
        @r.get('/api/preferences')
        async def prefs(req):return web.json_response(self.preferences())
        @r.post('/api/preferences')
        async def setprefs(req):
            d=await req.json();p=self.preferences()
            for k,limit in [('negative',6000),('sources',8000),('keyword',200)]:
                if k in d:p[k]=str(d[k])[:limit]
            self.store.put('meta','preferences',p);return web.json_response(p)
        @r.get('/api/prompts')
        async def prompts(req):
            p=sorted(self.store.all('prompt'),key=lambda x:x['updated'],reverse=True)
            for entry in p[:500]:
                j=self.store.get('job',entry.get('job_id')) if entry.get('job_id') else None
                if j and j.get('status')=='done' and j.get('outputs'):
                    entry['output']=self.s.public_job(j)['outputs'][0]
            return web.json_response({'prompts':p[:500]})
        @r.post('/api/prompts')
        async def save(req):return web.json_response(self.save(await req.json()))
        @r.post('/api/prompts/{key}/delete')
        async def delete(req):return web.json_response(self.delete(req.match_info['key']))
        @r.post('/api/prompts/harvest')
        async def harvest(req):
            raw=await req.json();return web.json_response(self.s.workshop.launch('prompt_import',lambda progress:self.harvest(raw,progress)))
        @r.get('/api/prompts/export')
        async def export(req):return web.json_response({'prompts':self.store.all('prompt'),'preferences':self.preferences()},headers={'Content-Disposition':'attachment; filename="mes_prompts.json"'})
        @r.post('/api/prompts/import')
        async def restore(req):
            d=await req.json();items=d.get('prompts',[])
            if not isinstance(items,list) or len(items)>500:raise ValueError('500 prompts maximum par import.')
            valid=[p for p in items if isinstance(p,dict) and 1<=len(str(p.get('prompt','')).strip())<=6000]
            if len(valid)!=len(items):raise ValueError('Le fichier contient un prompt invalide.')
            for p in valid:self.save(p)
            return web.json_response({'count':len(valid)})
        return r
