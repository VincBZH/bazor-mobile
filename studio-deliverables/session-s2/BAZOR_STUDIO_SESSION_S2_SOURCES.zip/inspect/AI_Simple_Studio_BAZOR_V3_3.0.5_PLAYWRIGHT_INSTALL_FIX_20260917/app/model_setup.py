"""Discover existing safe-format image checkpoints; install an official SDXL base on request."""
import asyncio, hashlib, json, os, shutil, struct, subprocess, sys, time
from pathlib import Path
from aiohttp import web, ClientTimeout
from media_tools import available, ffmpeg_path

MODEL_NAME='sd_xl_base_1.0.safetensors'
MODEL_URL='https://huggingface.co/stabilityai/stable-diffusion-xl-base-1.0/resolve/main/'+MODEL_NAME
MODEL_SHA256='31e35c80fc4829d14f90153f4c74cd59c90b779f6afe05a74cd6120b893f7e5b'
MODEL_SIZE=6938078334


def family(path):
    try:
        with Path(path).open('rb') as f:
            length=struct.unpack('<Q',f.read(8))[0]
            if not 2<=length<=16*1024*1024:return None
            header=json.loads(f.read(length))
        keys=header.keys()
        if not any(k.startswith('model.diffusion_model.input_blocks.') for k in keys):return None
        if any(k.startswith('conditioner.embedders.1.model.') for k in keys):return 'sdxl'
        if any(k.startswith('cond_stage_model.transformer.text_model.') for k in keys):return 'sd15'
    except (OSError,ValueError,struct.error):pass
    return None


class ModelSetup:
    def __init__(self,s):
        self.s=s;self.lock=asyncio.Lock()
        air=Path(os.environ.get('AI_ROOT',r'C:\AI'))
        portable=Path(sys.executable).parent.parent
        self.comfy=portable/'ComfyUI' if (portable/'ComfyUI'/'main.py').exists() else air/'ComfyUI'/'ComfyUI_windows_portable'/'ComfyUI'
        self.air=air

    def checkpoint_dir(self):
        if not (self.comfy/'main.py').is_file():raise ValueError('Dossier ComfyUI local introuvable. Relance avec le raccourci AI Simple Studio.')
        folder=self.comfy/'models'/'checkpoints';folder.mkdir(parents=True,exist_ok=True);return folder

    def details(self):
        models=[]
        folder=self.comfy/'models'/'checkpoints'
        if folder.exists():
            for p in folder.rglob('*.safetensors'):
                fam=family(p)
                if fam:models.append(dict(name=p.relative_to(folder).as_posix(),family=fam,size=p.stat().st_size))
        return dict(models=models,download_bytes=MODEL_SIZE,source='https://huggingface.co/stabilityai/stable-diffusion-xl-base-1.0',license='CreativeML Open RAIL++-M',ffmpeg=available())

    async def scan(self,progress):
        async with self.lock:
            progress('Recherche dans ComfyUI et les dossiers Forge existants')
            def work():
                dest=self.checkpoint_dir();found=[];skipped=[]
                roots=[self.air/'Forge'/'webui'/'models'/'Stable-diffusion',self.air/'Forge'/'models'/'Stable-diffusion',self.air/'stable-diffusion-webui'/'models'/'Stable-diffusion']
                for root in roots:
                    if not root.exists():continue
                    for i,p in enumerate(root.rglob('*.safetensors')):
                        if i>=500:break
                        fam=family(p)
                        if not fam:continue
                        sub=dest/'Studio_Imported';sub.mkdir(exist_ok=True)
                        tag=hashlib.sha256(str(p.resolve()).encode()).hexdigest()[:8]
                        target=sub/(tag+'_'+p.name)
                        if target.exists():continue
                        try:os.link(p,target)
                        except OSError:
                            if shutil.disk_usage(dest).free<p.stat().st_size+3*1024**3:
                                skipped.append(p.name+' : espace insuffisant pour une copie');continue
                            temp=target.with_suffix('.part')
                            try:shutil.copy2(p,temp);temp.replace(target)
                            finally:temp.unlink(missing_ok=True)
                        found.append(target.relative_to(dest).as_posix())
                return dict(found=found,skipped=skipped)
            result=await asyncio.to_thread(work)
            self.s.info_at=0
            result['message']='Recherche terminée. Actualise les modèles.' if result['found'] else 'Aucun nouveau checkpoint SD 1.5/SDXL trouvé dans les dossiers connus. Le modèle vidéo Wan ne remplace pas un checkpoint image.'
            return result

    async def install(self,progress):
        async with self.lock:
            folder=self.checkpoint_dir();target=folder/MODEL_NAME;part=folder/(MODEL_NAME+'.part')
            def sha(path):
                h=hashlib.sha256()
                with path.open('rb') as f:
                    for chunk in iter(lambda:f.read(8*1024*1024),b''):h.update(chunk)
                return h.hexdigest()
            if target.exists():
                progress('Vérification du modèle déjà présent')
                if await asyncio.to_thread(sha,target)==MODEL_SHA256:return {'name':MODEL_NAME,'message':'SDXL est déjà installé et vérifié.'}
                raise ValueError('Un fichier de ce nom existe avec une empreinte différente. Il est conservé ; ne pas le remplacer automatiquement.')
            offset=part.stat().st_size if part.exists() else 0
            if offset>MODEL_SIZE:raise ValueError('Téléchargement partiel trop grand ; consulte Diagnostic.')
            if shutil.disk_usage(folder).free<MODEL_SIZE-offset+3*1024**3:raise ValueError('Il faut environ 10 Go libres pour installer ce modèle en gardant une marge de travail.')
            if offset<MODEL_SIZE:
                headers={'Range':f'bytes={offset}-'} if offset else {}
                async with self.s.session.get(MODEL_URL,headers=headers,allow_redirects=True,max_redirects=5,timeout=ClientTimeout(total=None,sock_read=90)) as r:
                    if r.status not in (200,206):raise ValueError(f'Téléchargement officiel indisponible (HTTP {r.status}).')
                    if r.status==206 and not r.headers.get('Content-Range','').startswith(f'bytes {offset}-'):raise ValueError('Le serveur ne confirme pas le point de reprise.')
                    if r.status==200:offset=0
                    current=offset;last=0
                    with part.open('ab' if offset else 'wb') as f:
                        async for chunk in r.content.iter_chunked(1024*1024):
                            current+=len(chunk)
                            if current>MODEL_SIZE:raise ValueError('La taille téléchargée ne correspond pas au modèle attendu.')
                            f.write(chunk)
                            if time.time()-last>.5:
                                progress(f'SDXL : {current/1e9:.2f} / {MODEL_SIZE/1e9:.2f} Go',current/MODEL_SIZE*.94);last=time.time()
            if part.stat().st_size!=MODEL_SIZE:raise ValueError('Téléchargement incomplet. Le prochain essai reprendra au même endroit.')
            progress('Vérification de l’empreinte SHA-256',.95)
            if await asyncio.to_thread(sha,part)!=MODEL_SHA256:
                part.rename(folder/(MODEL_NAME+'.verification-failed-'+str(int(time.time()))))
                raise ValueError('Empreinte différente de la publication officielle. Le fichier ne sera pas chargé.')
            part.replace(target);self.s.info_at=0
            return {'name':MODEL_NAME,'message':'SDXL officiel installé et vérifié. Clique sur Actualiser les modèles.'}

    async def montage(self,progress):
        if available():return {'message':'Le montage est déjà disponible.'}
        progress('Installation du composant vidéo depuis PyPI')
        args=[sys.executable,'-s','-m','pip','install','--only-binary=:all:','--no-deps','--index-url','https://pypi.org/simple','imageio-ffmpeg==0.6.0']
        flags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0
        proc=await asyncio.create_subprocess_exec(*args,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.STDOUT,creationflags=flags)
        try:
            out,_=await asyncio.wait_for(proc.communicate(),600)
            if proc.returncode:raise ValueError('Installation du montage interrompue : '+out.decode('utf-8','replace')[-2000:])
        finally:
            if proc.returncode is None:proc.kill();await proc.wait()
        ffmpeg_path.cache_clear()
        if not available():raise ValueError('Le composant est installé mais ne répond pas. Consulte le message Windows et Diagnostic.')
        return {'message':'Montage prêt : import, découpe et export MP4 disponibles.'}

    def routes(self):
        r=web.RouteTableDef()
        @r.get('/api/image-models')
        async def details(req):return web.json_response(await asyncio.to_thread(self.details))
        @r.post('/api/image-models/scan')
        async def scan(req):return web.json_response(self.s.workshop.launch('model_scan',self.scan))
        @r.post('/api/image-models/install')
        async def install(req):
            active=next((o for o in self.s.store.all('operation') if o['kind']=='model_install' and o['status'] in ('queued','running')),None)
            return web.json_response(active or self.s.workshop.launch('model_install',self.install))
        @r.post('/api/montage/install')
        async def montage(req):
            active=next((o for o in self.s.store.all('operation') if o['kind']=='montage_install' and o['status'] in ('queued','running')),None)
            return web.json_response(active or self.s.workshop.launch('montage_install',self.montage))
        return r
