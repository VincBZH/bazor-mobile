"""Bind the running server to the release and installation that started it."""
import hashlib, json, os
from pathlib import Path

APP_ID='ai-simple-studio-v2'

def identity(version, root=None, verify=False):
    root=Path(root or Path(__file__).resolve().parent.parent).resolve()
    release=json.loads((root/'release.json').read_text(encoding='utf-8-sig'))
    if release.get('version')!=version:raise ValueError('Version du programme différente de release.json. Relance DEMARRER.cmd depuis le ZIP complet.')
    if verify:
        for name,digest in release['files'].items():
            target=root/name
            if not target.resolve().is_relative_to(root):raise ValueError('Chemin de livraison invalide.')
            if not target.is_file() or hashlib.sha256(target.read_bytes()).hexdigest()!=digest:
                raise ValueError('Fichier incomplet ou différent de la livraison : '+name+'. Réextraire tout le ZIP puis lancer DEMARRER.cmd.')
    return dict(app=APP_ID,version=version,build_id=release['build_id'],install_root=str(root),pid=os.getpid())

def matches(actual, expected):
    if not isinstance(actual,dict):return False
    return all(actual.get(k)==expected.get(k) for k in ('app','version','build_id','install_root'))
