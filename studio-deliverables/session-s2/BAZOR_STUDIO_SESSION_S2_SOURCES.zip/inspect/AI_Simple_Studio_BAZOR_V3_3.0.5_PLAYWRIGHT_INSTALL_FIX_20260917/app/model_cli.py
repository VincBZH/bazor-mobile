"""One-click checkpoint repair for a local ComfyUI/Forge installation."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import sys
import time
import urllib.request
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
if str(APP_DIR) not in sys.path:
    sys.path.insert(0, str(APP_DIR))

from model_setup import MODEL_NAME, MODEL_SHA256, MODEL_SIZE, MODEL_URL, family


def comfy_root(air: Path) -> Path:
    candidates = [
        air / "ComfyUI" / "ComfyUI_windows_portable" / "ComfyUI",
        air / "ComfyUI" / "ComfyUI_windows_portable",
        air / "ComfyUI" / "ComfyUI",
        air / "ComfyUI",
    ]
    for root in candidates:
        if (root / "main.py").is_file():
            return root
    for root in candidates:
        if root.is_dir():
            return root
    raise RuntimeError(f"Dossier ComfyUI introuvable sous {air / 'ComfyUI'}.")


def checkpoint_dir(air: Path) -> Path:
    folder = comfy_root(air) / "models" / "checkpoints"
    folder.mkdir(parents=True, exist_ok=True)
    return folder


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def forge_roots(air: Path) -> list[Path]:
    return [
        air / "Forge" / "webui" / "models" / "Stable-diffusion",
        air / "Forge" / "models" / "Stable-diffusion",
        air / "stable-diffusion-webui" / "models" / "Stable-diffusion",
    ]


def valid_existing(folder: Path) -> list[Path]:
    return [p for p in sorted(folder.rglob("*.safetensors")) if family(p)]


def scan(air: Path) -> dict:
    destination = checkpoint_dir(air)
    found: list[str] = []
    skipped: list[str] = []
    for root in forge_roots(air):
        if not root.is_dir():
            continue
        for source in sorted(root.rglob("*.safetensors"))[:500]:
            if not family(source):
                continue
            target_dir = destination / "Studio_Imported"
            target_dir.mkdir(exist_ok=True)
            tag = hashlib.sha256(str(source.resolve()).encode()).hexdigest()[:8]
            target = target_dir / f"{tag}_{source.name}"
            if target.exists():
                continue
            try:
                os.link(source, target)
            except OSError:
                if shutil.disk_usage(destination).free < source.stat().st_size + 3 * 1024**3:
                    skipped.append(f"{source.name} : espace insuffisant pour une copie")
                    continue
                temporary = target.with_suffix(target.suffix + ".part")
                try:
                    shutil.copy2(source, temporary)
                    temporary.replace(target)
                finally:
                    temporary.unlink(missing_ok=True)
            found.append(target.relative_to(destination).as_posix())
    return {
        "status": "ready" if valid_existing(destination) else "scanned",
        "found": found,
        "skipped": skipped,
        "checkpoint_dir": str(destination),
        "message": (
            "Checkpoint image importé dans ComfyUI. Clique sur Actualiser les modèles."
            if found
            else "Aucun checkpoint SD 1.5/SDXL valide trouvé dans Forge."
        ),
    }


def install(air: Path) -> dict:
    destination = checkpoint_dir(air)
    target = destination / MODEL_NAME
    partial = destination / (MODEL_NAME + ".part")
    if target.exists():
        if sha256(target) == MODEL_SHA256:
            return {"status": "ready", "name": MODEL_NAME, "message": "SDXL officiel déjà présent et vérifié."}
        raise RuntimeError(f"{target.name} existe mais son empreinte est différente ; il est conservé.")
    offset = partial.stat().st_size if partial.exists() else 0
    if offset > MODEL_SIZE:
        raise RuntimeError("Téléchargement partiel trop grand ; supprime uniquement le fichier .part puis réessaie.")
    if shutil.disk_usage(destination).free < MODEL_SIZE - offset + 3 * 1024**3:
        raise RuntimeError("Il faut environ 10 Go libres pour installer SDXL avec une marge de travail.")
    if offset < MODEL_SIZE:
        request = urllib.request.Request(MODEL_URL)
        if offset:
            request.add_header("Range", f"bytes={offset}-")
        try:
            response = urllib.request.urlopen(request, timeout=90)
        except Exception as exc:
            raise RuntimeError(f"Téléchargement officiel indisponible : {exc}") from exc
        with response:
            status = getattr(response, "status", response.getcode())
            if status not in (200, 206):
                raise RuntimeError(f"Téléchargement officiel indisponible (HTTP {status}).")
            if status == 206 and not response.headers.get("Content-Range", "").startswith(f"bytes {offset}-"):
                raise RuntimeError("Le serveur ne confirme pas le point de reprise.")
            if status == 200:
                offset = 0
            current = offset
            last_report = 0.0
            with partial.open("ab" if offset else "wb") as handle:
                while True:
                    chunk = response.read(1024 * 1024)
                    if not chunk:
                        break
                    current += len(chunk)
                    if current > MODEL_SIZE:
                        raise RuntimeError("La taille téléchargée dépasse celle du modèle officiel attendu.")
                    handle.write(chunk)
                    now = time.time()
                    if now - last_report > 0.5:
                        print(f"SDXL : {current / 1e9:.2f} / {MODEL_SIZE / 1e9:.2f} Go ({current / MODEL_SIZE:.1%})", flush=True)
                        last_report = now
    if not partial.is_file() or partial.stat().st_size != MODEL_SIZE:
        raise RuntimeError("Téléchargement incomplet ; le prochain lancement reprendra le fichier .part.")
    print("Vérification SHA-256 de SDXL…", flush=True)
    if sha256(partial) != MODEL_SHA256:
        failed = destination / (MODEL_NAME + f".verification-failed-{int(time.time())}")
        partial.replace(failed)
        raise RuntimeError("Empreinte différente de la publication officielle ; le fichier n’est pas chargé.")
    partial.replace(target)
    return {"status": "installed", "name": MODEL_NAME, "message": "SDXL officiel installé et vérifié."}


def repair(air: Path) -> dict:
    result = scan(air)
    if result["found"]:
        result["status"] = "ready"
        return result
    existing = valid_existing(Path(result["checkpoint_dir"]))
    if existing:
        result["status"] = "ready"
        result["message"] = "Un checkpoint image valide est déjà présent dans ComfyUI."
        return result
    installed = install(air)
    installed["checkpoint_dir"] = result["checkpoint_dir"]
    return installed


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Répare les checkpoints image de ComfyUI.")
    parser.add_argument("action", choices=("scan", "install", "repair"))
    parser.add_argument("--air-root", default=os.environ.get("AI_ROOT", r"C:\AI"))
    args = parser.parse_args(argv)
    air = Path(args.air_root).expanduser()
    if args.action == "scan":
        result = scan(air)
    elif args.action == "install":
        result = install(air)
    else:
        result = repair(air)
    print(json.dumps(result, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"REPARATION MODELE IMPOSSIBLE : {exc}", file=sys.stderr)
        raise SystemExit(1)
