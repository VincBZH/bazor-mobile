'use strict';
let workshop={projects:[],clips:[],batches:[],operations:[],exports:[]},projectId='',promptRecords=[],selectedTail='last.png',referenceAsset=null,continuationEnd=null;
let projectDirty=false,projectSaving=false,previewRevision=null,previewItems=[],previewIndex=-1,previewSerial=0,playingTimeline=false,atelierReady=false,pollingAtelier=false;
const operationSeen=new Set();let toastTimer,activeBatchRequest=null;
const project=()=>workshop.projects.find(p=>p.id===projectId);
const clipById=id=>workshop.clips.find(c=>c.id===id);
const seconds=x=>Number(x||0).toLocaleString('fr-FR',{maximumFractionDigits:2})+' s';
const requestKey=()=>crypto.randomUUID().replaceAll('-','');
function notice(text,bad=false){$('atelierToast').textContent=text;$('atelierToast').classList.remove('hidden');$('atelierToast').classList.toggle('bad',bad);clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('atelierToast').classList.add('hidden'),bad?18000:7000)}
async function act(button,fn){if(button?.disabled)return;if(button)button.disabled=true;try{return await fn()}catch(e){notice(e.message,true)}finally{if(button)button.disabled=false}}
function putProject(p){workshop.projects=workshop.projects.filter(x=>x.id!==p.id).concat(p);projectId=p.id;projectDirty=false;previewRevision=null;renderMontage(true)}
async function ensureProject(){if(project())return project();const p=await api('/api/projects',{name:'Mon film'});putProject(p);return p}
async function saveProject(){
 const p=await ensureProject();if(projectSaving)throw Error('Enregistrement en cours.');projectSaving=true;
 try{const got=await api('/api/projects/'+p.id,{...p,name:$('projectName').value||p.name,context:$('sceneContext').value});putProject(got);$('projectStatus').textContent='Enregistré';return got}finally{projectSaving=false}
}
async function modifyTimeline(fn){
 const p=await ensureProject();if(workshop.batches.some(b=>b.project_id===p.id&&b.status==='running'))throw Error('Mets le lot en pause avant de modifier la timeline.');
 const items=JSON.parse(JSON.stringify(p.items));fn(items);const got=await api('/api/projects/'+p.id,{...p,name:$('projectName').value||p.name,context:$('sceneContext').value,items});putProject(got)
}
function renderMontage(force=false){
 const select=$('projectSelect'),options=workshop.projects.map(p=>`<option value="${esc(p.id)}">${esc(p.name)}</option>`).join('');
 if(select.innerHTML!==options)select.innerHTML=options;if(!project()&&workshop.projects.length)projectId=workshop.projects[0].id;select.value=projectId;
 const p=project();if(p){if(force||!projectDirty){$('projectName').value=p.name;$('sceneContext').value=p.context}$('projectStatus').textContent=projectDirty?'Modifications à enregistrer':'Enregistré';}
 const signature=JSON.stringify([p?.items,workshop.clips.map(c=>[c.id,c.prompt]),previewRevision]);
 if($('timeline').dataset.signature!==signature){
  $('timeline').dataset.signature=signature;
  $('timeline').innerHTML=p?.items.length?p.items.map((item,i)=>{const c=clipById(item.clip_id);if(!c)return '';return `<article class="timeline-card" draggable="true" data-entry="${esc(item.id)}" data-position="${i}"><button class="thumb-play" data-preview-index="${i}" aria-label="Lire le plan ${i+1}"><img src="${esc(c.thumbnail)}" alt="Plan ${i+1}" loading="lazy"><span>${i+1}</span><b>${seconds(item.end-item.start)}</b></button><strong>${esc(c.title)}</strong><div class="trim-fields"><label>Début<input data-trim="start" data-entry="${esc(item.id)}" type="number" min="0" max="${c.duration}" step="0.04" value="${item.start.toFixed(3)}"></label><label>Fin<input data-trim="end" data-entry="${esc(item.id)}" type="number" min="0" max="${c.duration}" step="0.04" value="${item.end.toFixed(3)}"></label></div><div class="toolbar"><button class="text-button" data-move="-1" data-entry="${esc(item.id)}" aria-label="Avancer le plan">←</button><button class="text-button" data-move="1" data-entry="${esc(item.id)}" aria-label="Reculer le plan">→</button><button class="text-button" data-delete-entry="${esc(item.id)}">Retirer</button></div><details><summary>Prompt associé</summary><p>${esc(c.prompt||'Vidéo importée · aucun prompt enregistré.')}</p><button class="text-button" data-use-clip-prompt="${esc(c.id)}">Reprendre le prompt</button></details><button class="secondary" data-continue-clip="${esc(c.id)}" data-continue-end="${item.end}">Prolonger ce plan</button></article>`}).join(''):'<p class="hint timeline-empty">Importez des clips ou générez vos premiers plans. La timeline se remplit ici.</p>';
 }
 const duration=(p?.items||[]).reduce((s,x)=>s+x.end-x.start,0);$('timelineDuration').textContent=`${p?.items.length||0} plan(s) · ${seconds(duration)}`;
 $('exportFilm').disabled=!p?.items.length||previewRevision!==p?.revision||!workshop.ffmpeg;
 const cs=JSON.stringify(workshop.clips);
 if($('clipBin').dataset.signature!==cs){$('clipBin').dataset.signature=cs;$('clipBin').innerHTML=workshop.clips.slice().reverse().map(c=>`<article class="bin-card"><img src="${esc(c.thumbnail)}" alt="${esc(c.title)}" loading="lazy"><strong>${esc(c.title)}</strong><small>${seconds(c.duration)} · ${c.width} × ${c.height}</small><div class="toolbar"><button class="secondary" data-add-clip="${esc(c.id)}">Ajouter</button><button class="text-button" data-continue-clip="${esc(c.id)}">Prolonger</button></div><details><summary>Prompt et contexte</summary><textarea data-clip-prompt="${esc(c.id)}" rows="3" maxlength="6000">${esc(c.prompt)}</textarea><button class="text-button" data-save-clip-prompt="${esc(c.id)}">Enregistrer ce prompt</button></details></article>`).join('')||'<p class="hint">Les clips importés et les plans terminés apparaîtront ici.</p>';
  const current=$('continueFrom').value;$('continueFrom').innerHTML='<option value="">Réglages et image de l’onglet Créer</option>'+workshop.clips.map(c=>`<option value="${esc(c.id)}">${esc(c.title)}</option>`).join('');if(clipById(current))$('continueFrom').value=current;
 }
 const bs=workshop.batches.filter(b=>b.project_id===p?.id).slice(-3);
 $('batchStatus').innerHTML=bs.map(b=>`<div class="batch-row"><b>${b.index}/${b.prompts.length} plans · ${esc({running:'en cours',paused:'en pause',done:'terminé',cancelled:'arrêté'}[b.status]||b.status)}</b><p>${esc(b.stage)}</p><div class="toolbar">${b.status==='running'?`<button class="secondary" data-batch-action="pause" data-batch-id="${b.id}">Pause</button>`:b.status==='paused'?`<button class="secondary" data-batch-action="resume" data-batch-id="${b.id}">Reprendre</button>`:''}${['running','paused'].includes(b.status)?`<button class="text-button" data-batch-action="cancel" data-batch-id="${b.id}">Arrêter le lot</button>`:''}</div></div>`).join('');
 $('installMontage').classList.toggle('hidden',!!workshop.ffmpeg);$('montageHint').textContent=workshop.ffmpeg?'Montage prêt. Le calcul vidéo et l’assemblage restent sur votre PC.':'Installez le composant vidéo une seule fois pour importer et assembler.';
 $('exportResults').innerHTML=workshop.exports.filter(e=>e.project_id===p?.id).slice().reverse().slice(0,5).map(e=>`<div class="export-result"><a class="secondary" href="${esc(e.url)}?download=1" download>Télécharger ${esc(e.project.name)} · ${seconds(e.duration)}</a></div>`).join('');
 updateBatchEstimate();
}
function renderTails(){
 continuationEnd=null;
 const c=clipById($('continueFrom').value);referenceAsset=null;selectedTail='last.png';
 $('tailFrames').innerHTML=c?c.tail.map((f,i)=>`<button class="tail-choice ${f==='last.png'?'selected':''}" data-tail="${esc(f)}"><img src="/api/clips/${esc(c.id)}/${esc(f)}" alt="Image de fin ${i+1}"><small>${['−0,75 s','−0,5 s','−0,25 s','Dernière image'][i]}</small></button>`).join(''):'';
 $('tailNote').textContent=c?'Choisis une image de fin pour le départ. Wan reçoit cette image et le contexte écrit ; il ne reçoit pas les quatre images comme une mémoire du mouvement.':'La dernière image sert de référence pour la suite. L’identité peut encore dériver entre les clips.';
}
function updateBatchEstimate(){const n=$('scenePrompts').value.split('\n').filter(x=>x.trim()).length;const f=+$('frames').value,rate=+$('fps').value;const overlap=$('chainClips').checked?Math.max(0,n-1+(!!$('continueFrom').value?1:0))/rate:0;$('batchEstimate').textContent=`${n} plan(s) · environ ${seconds(Math.max(0,n*f/rate-overlap))} au total · ${f} images par plan. Les images de raccord communes sont retirées au montage.`}
function stopPreview(){playingTimeline=false;previewSerial++;$('filmPreview').pause();$('previewLabel').textContent='Aperçu arrêté';document.querySelectorAll('.timeline-card').forEach(c=>c.classList.remove('playing'))}
async function playSequence(start=0){
 const p=project();if(!p?.items.length)throw Error('Ajoute au moins un plan à la timeline.');
 if(projectDirty)throw Error('Enregistre les modifications avant la prévisualisation.');
 previewItems=JSON.parse(JSON.stringify(p.items));previewIndex=start;playingTimeline=true;previewRevision=null;
 $('filmPreview').muted=$('exportMute').checked;const w=+$('exportWidth').value,h=+$('exportHeight').value;if(w>0&&h>0)$('filmPreview').parentElement.style.aspectRatio=w+'/'+h;
 $('exportFilm').disabled=true;$('exportHint').textContent='L’ordre prévisualisé sera utilisé pour cet export. Vous pouvez encore modifier le montage.';
 await playCurrent();
}
async function playCurrent(){
 if(!playingTimeline)return;
 if(previewIndex>=previewItems.length){playingTimeline=false;$('previewLabel').textContent='Prévisualisation terminée';return}
 const item=previewItems[previewIndex],c=clipById(item.clip_id),video=$('filmPreview'),serial=++previewSerial;
 if(!c){stopPreview();return}
 document.querySelectorAll('.timeline-card').forEach((el,i)=>el.classList.toggle('playing',i===previewIndex));
 document.querySelector(`.timeline-card[data-position="${previewIndex}"]`)?.scrollIntoView({block:'nearest',inline:'nearest',behavior:'smooth'});
 $('previewLabel').textContent=`Plan ${previewIndex+1} / ${previewItems.length}`;video.src=c.url;
 video.onloadedmetadata=()=>{if(serial!==previewSerial)return;video.currentTime=item.start;video.play().catch(e=>{playingTimeline=false;notice('Clique sur Lecture dans le lecteur pour autoriser l’aperçu.',true)})};
 video.onplay=()=>{if(serial===previewSerial){playingTimeline=true;previewRevision=project()?.revision;$('exportFilm').disabled=!workshop.ffmpeg}};
 video.onerror=()=>{previewRevision=null;$('exportFilm').disabled=true;stopPreview();notice('Ce clip ne se lit pas. Vérifie son import avant d’exporter.',true)};
 let advancing=false;const next=()=>{if(advancing||serial!==previewSerial||!playingTimeline)return;advancing=true;previewIndex++;playCurrent()};
 video.ontimeupdate=()=>{if(video.currentTime>=item.end-.015)next()};video.onended=next;video.load();
}
async function refreshModels(){await refreshHealth();const d=await api('/api/image-models');window.studioModelFamilies=Object.fromEntries((d.models||[]).map(x=>[x.name,x.family]));const found=(health.checkpoints||[]).length;$('modelHint').textContent=found?`${found} checkpoint(s) image validé(s). Les modes image sont déverrouillés.`:'Aucun checkpoint image installé : génération d’image bloquée. Recherchez les modèles existants ou installez SDXL officiel (6,94 Go).';}
async function refreshPrompts(){const r=await api('/api/prompts');promptRecords=r.prompts||[];renderPrompts()}
function renderPrompts(){
 const q=$('promptSearch').value.toLowerCase();$('promptCards').innerHTML=promptRecords.filter(p=>JSON.stringify(p).toLowerCase().includes(q)).map(p=>{const j=jobs.find(j=>j.id===p.job_id),o=p.output||j?.outputs?.[0];return `<article class="prompt-card">${p.clip_id?`<img src="/api/clips/${esc(p.clip_id)}/thumb.jpg" alt="Séquence associée au prompt" loading="lazy">`:o?o.media==='image'?`<img src="${esc(o.url)}" alt="Création associée au prompt" loading="lazy">`:`<video src="${esc(o.url)}" muted preload="metadata" playsinline></video>`:p.asset_id?`<img src="/api/assets/${esc(p.asset_id)}" alt="Référence du prompt" loading="lazy">`:''}<div><strong>${esc(p.title)}</strong><small>${esc(labels[p.mode]||p.mode)}</small><p>${esc(p.prompt)}</p><details><summary>Exclusions et source</summary><p>${esc(p.negative||'Exclusions globales')}</p>${/^https?:\/\//.test(p.source)?`<a href="${esc(p.source)}" target="_blank" rel="noreferrer">Ouvrir la source</a>`:''}</details><button class="secondary" data-library-prompt="${p.id}">Reprendre le prompt et les réglages</button><button class="secondary danger-button" data-delete-prompt="${p.id}">Supprimer ce prompt</button></div></article>`}).join('')||'<p class="hint">Enregistrez un prompt depuis Créer, générez un résultat ou importez vos premières idées.</p>';
}
async function deletePrompt(id){if(!id)return;if(!window.confirm('Supprimer ce prompt enregistré ?'))return;try{await api('/api/prompts/'+encodeURIComponent(id)+'/delete',{});await refreshPrompts();notice('Prompt supprimé de la bibliothèque.')}catch(e){notice(e.message,true)}}
function applyPrompt(p){
 const values=p.params||{};for(const k of ['width','height','frames','fps','steps','seed','engine','denoise'])if(values[k]!=null)$(k).value=values[k];
 stylePresets=Array.isArray(values.style_presets)&&values.style_presets.length?values.style_presets:[String(values.style_preset||'realistic').split('+')[0]];
 $('artistic').checked=!!values.artistic;$('tiled').checked=values.tiled!==false;updateMode(['t2i','i2i','t2v','i2v','v2v'].includes(p.mode)?p.mode:'t2v');if(values.checkpoint)$('checkpoint').value=values.checkpoint;$('prompt').value=p.prompt;$('denoiseValue').textContent=Math.round(+$('denoise').value*100)+' %';$('negative').value=p.negative||$('globalNegative').value;
 asset=p.asset_id?{id:p.asset_id}:null;showAsset(asset);changeView('create');updateSpecs();syncStylePrompt(false);saveDraft();notice('Prompt et référence repris. Vérifie les réglages avant de générer.')
}
function renderOperations(){
 const ops=workshop.operations||[],active=ops.filter(o=>['queued','running'].includes(o.status)),last=ops.filter(o=>!['queued','running'].includes(o.status)).slice(-1);const shown=active.concat(last);
 $('operationsPanel').classList.toggle('hidden',!shown.length);$('operations').innerHTML=shown.map(o=>`<div class="operation"><strong>${esc(o.stage)}</strong>${['queued','running'].includes(o.status)?`<progress max="1" value="${o.progress||0}"></progress><button class="text-button" data-stop-operation="${o.id}">Arrêter</button>`:o.result?.message?`<p>${esc(o.result.message)}</p>`:''}${o.result?.reports?`<details><summary>Résultats des sources</summary>${o.result.reports.map(r=>`<p>${esc(r.source)} : ${esc(r.message)}</p>`).join('')}</details>`:''}</div>`).join('');
 for(const o of ops){if(operationSeen.has(o.id)||['running','queued'].includes(o.status))continue;operationSeen.add(o.id);if(o.status==='error')notice(o.stage,true);if(o.status==='done'){if(['model_install','model_scan'].includes(o.kind))refreshModels().catch(e=>notice(e.message,true));if(o.kind==='prompt_import')refreshPrompts().catch(e=>notice(e.message,true));}}
}
async function refreshAtelier(){if(!token||pollingAtelier)return;pollingAtelier=true;try{const data=await api('/api/workshop');const old=project()?.revision;workshop=data;if(project()?.revision!==old&&previewRevision!==project()?.revision){previewRevision=null;stopPreview()}renderMontage();renderOperations()}catch(e){if(view==='montage')notice(e.message,true)}finally{pollingAtelier=false}}
async function initAtelier(){if(atelierReady||!token)return;atelierReady=true;try{const prefs=await api('/api/preferences');$('globalNegative').value=prefs.negative||'';$('promptSources').value=prefs.sources||'';$('promptKeyword').value=prefs.keyword||'';if(!$('negative').value)$('negative').value=prefs.negative||'';await refreshAtelier();await refreshModels();await refreshPrompts()}catch(e){atelierReady=false;notice(e.message,true)}}
document.addEventListener('studio-ready',initAtelier);if(token)initAtelier();
$('newProject').onclick=()=>act($('newProject'),async()=>{if(projectDirty)await saveProject();putProject(await api('/api/projects',{name:'Nouveau film'}));$('projectName').focus()});
$('projectSelect').onchange=()=>act(null,async()=>{const next=$('projectSelect').value;if(projectDirty)await saveProject();stopPreview();projectId=next;projectDirty=false;previewRevision=null;renderMontage(true)});
$('saveProject').onclick=()=>act($('saveProject'),saveProject);
for(const id of ['projectName','sceneContext'])$(id).oninput=()=>{projectDirty=true;$('projectStatus').textContent='Modifications à enregistrer';previewRevision=null;$('exportFilm').disabled=true};
$('continueFrom').onchange=()=>{renderTails();updateBatchEstimate()};
$('scenePrompts').oninput=updateBatchEstimate;$('chainClips').onchange=updateBatchEstimate;
$('prepareBatch').onclick=()=>act($('prepareBatch'),async()=>{const target=+$('targetSeconds').value,f=+$('frames').value,rate=+$('fps').value,base=$('prompt').value.trim();if(!base)throw Error('Écris d’abord le prompt du film dans Créer.');const n=Math.ceil((target*rate-1)/Math.max(4,f-1));if(n>60)throw Error('60 plans maximum par lot.');$('scenePrompts').value=Array(n).fill(base).join('\n');updateBatchEstimate();notice('Plans préparés. Modifie chaque ligne pour décrire la progression de la scène.')});
$('startBatch').onclick=()=>act($('startBatch'),async()=>{if(!workshop.ffmpeg)throw Error('Installe le montage vidéo pour extraire les images de fin.');const p=await saveProject();const from=$('continueFrom').value;let a=null;if(from)a=(await api('/api/clips/'+from+'/reference',{frame:selectedTail,end:continuationEnd})).asset;const raw=payload();if(isImage()){raw.mode=raw.asset_id?'i2v':'t2v';raw.engine='wan';raw.frames=+$('clipDuration').value;raw.width=832;raw.height=480;raw.steps=24;}const prompts=$('scenePrompts').value.split('\n').map(s=>s.trim()).filter(Boolean);activeBatchRequest=activeBatchRequest||requestKey();await api('/api/projects/'+p.id+'/batch',{params:raw,prompts,chain:$('chainClips').checked,initial_clip:from||null,initial_asset:a?.id||null},{headers:{'X-Studio-Token':token,'Content-Type':'application/json','Idempotency-Key':activeBatchRequest}});activeBatchRequest=null;await refreshAtelier()});
$('continueInComposer').onclick=()=>act($('continueInComposer'),async()=>{const id=$('continueFrom').value;if(!id)throw Error('Choisis un clip à prolonger.');const r=await api('/api/clips/'+id+'/reference',{frame:selectedTail,end:continuationEnd});const c=r.clip;for(const k of ['width','height','frames','steps','fps'])if(c.params[k]!=null)$(k).value=c.params[k];updateMode('i2v');asset=r.asset;showAsset(asset);$('prompt').value=[$('sceneContext').value,c.prompt,'Continuous shot. Preserve the same person, clothing, setting and lighting.'].filter(Boolean).join('\n').slice(0,6000);changeView('create');saveDraft();notice('Image de fin et contexte repris. Décris maintenant la suite du mouvement.')});
$('playTimeline').onclick=()=>act($('playTimeline'),()=>playSequence(0));$('stopTimeline').onclick=stopPreview;
$('splitTimeline').onclick=()=>act($('splitTimeline'),async()=>{const p=await saveProject();putProject(await api('/api/projects/'+p.id+'/split',{seconds:+$('splitSeconds').value,revision:p.revision}))});
$('exportFilm').onclick=()=>act($('exportFilm'),async()=>{const p=project();if(!p||previewRevision!==p.revision)throw Error('Prévisualise le montage avant l’export.');await api('/api/projects/'+p.id+'/export',{revision:p.revision,width:+$('exportWidth').value,height:+$('exportHeight').value,fps:+$('exportFps').value,mute:$('exportMute').checked});await refreshAtelier()});
$('importClips').onclick=()=>$('clipFiles').click();$('clipFiles').onchange=()=>act($('importClips'),async()=>{const p=await ensureProject();for(const f of $('clipFiles').files){if(f.size>1024**3)throw Error('1 Go maximum par fichier.');notice('Import : '+f.name);const r=await fetch('/api/clips/upload?project='+p.id,{method:'POST',headers:{'X-Studio-Token':token,'X-Clip-Name':encodeURIComponent(f.name)},body:f});const d=await r.json();if(!r.ok)throw Error(d.error||'Import interrompu.');await refreshAtelier()}$('clipFiles').value='';});
$('scanModels').onclick=()=>act($('scanModels'),async()=>{await api('/api/image-models/scan',{});await refreshAtelier()});
$('installSDXL').onclick=()=>act($('installSDXL'),async()=>{await api('/api/image-models/install',{});notice('Téléchargement de SDXL lancé. La progression est affichée en bas de la page.');await refreshAtelier()});
$('refreshModels').onclick=()=>act($('refreshModels'),refreshModels);$('installMontage').onclick=()=>act($('installMontage'),async()=>{await api('/api/montage/install',{});await refreshAtelier()});
$('savePrompt').onclick=()=>act($('savePrompt'),async()=>{const p=payload();await api('/api/prompts',{...p,params:p});await refreshPrompts();notice('Prompt, exclusions, réglages et référence enregistrés.')});
$('rememberNegative').onclick=()=>act($('rememberNegative'),async()=>{$('globalNegative').value=$('negative').value;await api('/api/preferences',{negative:$('globalNegative').value});notice('Exclusions mémorisées pour les prochaines créations et les lots.')});
$('savePreferences').onclick=()=>act($('savePreferences'),async()=>{await api('/api/preferences',{negative:$('globalNegative').value});notice('Exclusions globales enregistrées.')});
$('harvestPrompts').onclick=()=>act($('harvestPrompts'),async()=>{const p={sources:$('promptSources').value,keyword:$('promptKeyword').value};await api('/api/preferences',p);await api('/api/prompts/harvest',p);await refreshAtelier()});
$('promptSearch').oninput=renderPrompts;$('importPromptFile').onclick=()=>$('promptFile').click();$('promptFile').onchange=()=>act($('importPromptFile'),async()=>{const f=$('promptFile').files[0];if(!f)return;if(f.size>10*1024*1024)throw Error('Fichier trop volumineux.');await api('/api/prompts/import',JSON.parse(await f.text()));await refreshPrompts();$('promptFile').value='';notice('Bibliothèque importée.')});
$('clipDuration').onchange=()=>{$('frames').value=$('clipDuration').value;updateSpecs();updateBatchEstimate();saveDraft()};$('denoise').oninput=()=>{$('denoiseValue').textContent=Math.round(+$('denoise').value*100)+' %';saveDraft()};
$('exportMute').onchange=()=>{$('filmPreview').muted=$('exportMute').checked};
document.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;
 if(b.dataset.view==='montage')refreshAtelier();if(b.dataset.view==='prompts')refreshPrompts().catch(e=>notice(e.message,true));
 if(b.dataset.addJob)act(b,async()=>{const p=await ensureProject();await api('/api/clips/from-job',{job_id:b.dataset.addJob,index:+(b.dataset.outputIndex||0),project_id:p.id});changeView('montage');await refreshAtelier()});
 if(b.dataset.imageJob)act(b,async()=>{const r=await api('/api/image-reference',{job_id:b.dataset.imageJob,index:+(b.dataset.outputIndex||0)});updateMode(b.dataset.imageMode);asset=r.asset;showAsset(asset);$('prompt').value=r.prompt||'';applyPreset('balanced');changeView('create');saveDraft()});
 if(b.dataset.addClip)act(b,()=>modifyTimeline(items=>{const c=clipById(b.dataset.addClip);items.push({id:requestKey(),clip_id:c.id,start:0,end:c.duration})}));
 if(b.dataset.deleteEntry)act(b,()=>modifyTimeline(items=>{const i=items.findIndex(x=>x.id===b.dataset.deleteEntry);if(i>=0)items.splice(i,1)}));
 if(b.dataset.move)act(b,()=>modifyTimeline(items=>{const i=items.findIndex(x=>x.id===b.dataset.entry),j=i+Number(b.dataset.move);if(i>=0&&j>=0&&j<items.length)[items[i],items[j]]=[items[j],items[i]]}));
 if(b.dataset.previewIndex!==undefined)act(b,()=>playSequence(+b.dataset.previewIndex));
 if(b.dataset.continueClip)act(b,async()=>{$('continueFrom').value=b.dataset.continueClip;renderTails();const c=clipById(b.dataset.continueClip);if(b.dataset.continueEnd&&Number(b.dataset.continueEnd)<c.duration-.04){continuationEnd=Number(b.dataset.continueEnd);const r=await api('/api/clips/'+c.id+'/reference',{end:continuationEnd});referenceAsset=r.asset;$('tailFrames').innerHTML=`<button class="tail-choice selected"><img src="${esc(r.asset.url)}" alt="Image au point de coupe"><small>Coupe à ${seconds(continuationEnd)}</small></button>`;$('tailNote').textContent='La suite partira de la dernière image conservée par cette coupe.'}if(!$('sceneContext').value&&c?.prompt){$('sceneContext').value=c.prompt.slice(0,4000);projectDirty=true}$('scenePrompts').focus();notice('Plan sélectionné. Décris les prochains mouvements dans les lignes du lot.')});
 if(b.dataset.tail){selectedTail=b.dataset.tail;referenceAsset=null;document.querySelectorAll('[data-tail]').forEach(x=>x.classList.toggle('selected',x===b))}
 if(b.dataset.batchAction)act(b,async()=>{await api('/api/batches/'+b.dataset.batchId+'/'+b.dataset.batchAction,{});await refreshAtelier()});
 if(b.dataset.stopOperation)act(b,async()=>{await api('/api/operations/'+b.dataset.stopOperation+'/cancel',{});await refreshAtelier()});
 if(b.dataset.libraryPrompt){const p=promptRecords.find(x=>x.id===b.dataset.libraryPrompt);if(p)applyPrompt(p)}
 if(b.dataset.deletePrompt)act(b,()=>deletePrompt(b.dataset.deletePrompt));
 if(b.dataset.useClipPrompt){const c=clipById(b.dataset.useClipPrompt);if(c)applyPrompt({prompt:c.prompt,params:c.params,mode:c.params.mode||'t2v',negative:c.params.negative||'',asset_id:c.params.asset_id})}
 if(b.dataset.saveClipPrompt)act(b,async()=>{const id=b.dataset.saveClipPrompt,el=document.querySelector(`textarea[data-clip-prompt="${id}"]`);await api('/api/clips/'+id,{prompt:el.value});await refreshAtelier();await refreshPrompts();notice('Prompt associé au clip enregistré.')});
});
$('timeline').addEventListener('change',e=>{if(e.target.dataset.trim)act(null,()=>modifyTimeline(items=>{const i=items.find(x=>x.id===e.target.dataset.entry);if(i)i[e.target.dataset.trim]=Number(e.target.value)}))});
let dragEntry=null;$('timeline').addEventListener('dragstart',e=>{const el=e.target.closest('[data-entry]');if(el){dragEntry=el.dataset.entry;e.dataTransfer.setData('text/plain',dragEntry)}});$('timeline').addEventListener('dragover',e=>e.preventDefault());$('timeline').addEventListener('drop',e=>{e.preventDefault();const target=e.target.closest('.timeline-card')?.dataset.entry;if(!target||!dragEntry||target===dragEntry)return;const dragged=dragEntry;act(null,()=>modifyTimeline(items=>{const a=items.findIndex(x=>x.id===dragged),b=items.findIndex(x=>x.id===target);if(a>=0&&b>=0)items.splice(b,0,items.splice(a,1)[0])}));dragEntry=null});
setInterval(()=>{if(!atelierReady)initAtelier();if(!document.hidden)refreshAtelier()},3000);
