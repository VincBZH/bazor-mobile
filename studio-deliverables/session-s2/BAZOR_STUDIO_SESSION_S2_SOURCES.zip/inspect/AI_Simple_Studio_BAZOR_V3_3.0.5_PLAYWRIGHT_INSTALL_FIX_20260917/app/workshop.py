"""Persistent timelines, sequential generations and local video exports."""
import asyncio, contextlib, hashlib, json, math, re, shutil, time, uuid
from pathlib import Path
from urllib.parse import urlencode, unquote
from aiohttp import web, ClientTimeout
from media_tools import MediaTools, available
from workflows import parameters


def uid():return uuid.uuid4().hex

def number(v,low,high):
    try:n=float(v)
    except (ValueError,TypeError):raise ValueError('Nombre invalide.')
    if not math.isfinite(n) or not low<=n<=high:raise ValueError(f'Valeur attendue entre {low} et {high}.')
    return n


class Workshop:
    def __init__(self,studio):
        self.s=studio;self.store=studio.store;self.root=studio.data/'montage';self.root.mkdir(exist_ok=True)
        self.media=MediaTools();self.tasks={};self.batch_lock=asyncio.Lock();self.import_lock=asyncio.Lock()
        for op in self.store.all('operation'):
            if op['status'] in ('queued','running'):
                op.update(status='error',stage='Traitement interrompu par la fermeture. Relance cette opération.');self.store.put('operation',op['id'],op)
        for batch in self.store.all('batch'):
            if batch['status']=='running':batch['status']='paused';batch['stage']='Session rouverte : reprendre le lot.';self.store.put('batch',batch['id'],batch)

    def get(self,kind,key):
        item=self.store.get(kind,key)
        if not item:raise ValueError('Élément introuvable : '+kind)
        return item

    def launch(self,kind,fn,key=None):
        key=key or uid()
        previous=self.store.get('operation',key)
        if previous:return previous
        op=dict(id=key,kind=kind,status='queued',stage='En attente',created=time.time(),progress=0)
        self.store.put('operation',key,op)
        def progress(stage,value=0):
            op.update(stage=stage,progress=value);self.store.put('operation',key,op)
        async def run():
            try:
                op['status']='running';progress('Préparation')
                result=await fn(progress)
                op.update(status='done',result=result,stage='Terminé',progress=1)
            except asyncio.CancelledError:op.update(status='cancelled',stage='Arrêté');raise
            except Exception as e:op.update(status='error',stage=str(e),error=str(e));self.s.log('Montage : '+str(e))
            finally:self.store.put('operation',key,op);self.tasks.pop(key,None)
        self.tasks[key]=asyncio.create_task(run());return op

    def new_project(self,name='Mon film'):
        p=dict(id=uid(),name=str(name)[:120] or 'Mon film',context='',items=[],revision=0,created=time.time())
        self.store.put('project',p['id'],p);return p

    def save_project(self,key,raw):
        old=self.get('project',key)
        if int(raw.get('revision',-1))!=old['revision']:raise ValueError('Le montage a changé. Actualise avant de modifier la timeline.')
        p={**old,'name':str(raw.get('name',old['name']))[:120],'context':str(raw.get('context',old['context']))[:4000]}
        items=raw.get('items',old['items'])
        if not isinstance(items,list) or len(items)>120:raise ValueError('120 séquences maximum par montage.')
        clean=[];total=0
        for x in items:
            clip=self.get('clip',x['clip_id']);a=number(x.get('start',0),0,clip['duration']);b=number(x.get('end',clip['duration']),0,clip['duration']+.04)
            b=min(b,clip['duration'])
            if b-a<.04:raise ValueError('Une séquence doit durer au moins 0,04 seconde.')
            total+=b-a;clean.append(dict(id=str(x.get('id') or uid())[:80],clip_id=clip['id'],start=a,end=b))
        if total>1800:raise ValueError('30 minutes maximum par montage.')
        p.update(items=clean,revision=old['revision']+1);self.store.put('project',key,p);return p

    def append(self,project_id,clip,start=0,end=None,entry_id=None):
        p=self.get('project',project_id);entry_id=entry_id or uid()
        if any(x['id']==entry_id for x in p['items']):return p
        return self.save_project(project_id,{**p,'items':p['items']+[dict(id=entry_id,clip_id=clip['id'],start=start,end=end or clip['duration'])]})

    async def register(self,source,title='',prompt='',params=None,source_job=None):
        key=uid();folder=self.root/key;folder.mkdir()
        try:
            async with self.media.lock:
                meta=await self.media.probe(source)
                meta=await self.media.normalize(source,folder/'video.mp4',meta)
                tail=await self.media.pictures(folder/'video.mp4',folder,meta)
            clip=dict(id=key,title=str(title)[:120] or 'Séquence',prompt=prompt,params=params or {},source_job=source_job,
                created=time.time(),**meta,tail=tail,url=f'/api/clips/{key}/video.mp4',thumbnail=f'/api/clips/{key}/thumb.jpg')
            self.store.put('clip',key,clip);return clip
        except BaseException:
            shutil.rmtree(folder,ignore_errors=True);raise

    async def from_job(self,job_id,index=0):
        async with self.import_lock:return await self._from_job(job_id,index)

    async def _from_job(self,job_id,index=0):
        j=self.get('job',job_id)
        index=int(index)
        if index<0:raise ValueError('Sortie invalide.')
        try:o=j['outputs'][index]
        except (KeyError,IndexError):raise ValueError('Sortie vidéo indisponible.')
        if o.get('media')!='video':raise ValueError('Choisis une sortie vidéo.')
        identity=job_id+':'+str(index)
        previous=next((c for c in self.store.all('clip') if c.get('source_job')==identity),None)
        if previous:return previous
        source=self.root/(uid()+'.source')
        try:
            query={k:o.get(k,'') for k in ('filename','subfolder','type')}
            async with self.s.session.get(self.s.comfy+'/view?'+urlencode(query),allow_redirects=False,timeout=ClientTimeout(total=600)) as r:
                if r.status!=200:raise ValueError('Vidéo absente de ComfyUI. Le moteur doit rester ouvert pendant cet import.')
                total=0
                with source.open('wb') as f:
                    async for part in r.content.iter_chunked(1024*1024):
                        total+=len(part)
                        if total>1024**3:raise ValueError('Vidéo trop volumineuse : 1 Go maximum.')
                        f.write(part)
            return await self.register(source,j['params'].get('prompt','Séquence')[:80],j['params'].get('prompt',''),j['params'],identity)
        finally:source.unlink(missing_ok=True)

    async def reference(self,clip_id,frame='last.png',end=None):
        clip=self.get('clip',clip_id)
        if frame not in clip['tail']:raise ValueError('Image de contexte invalide.')
        cut=number(end,.04,clip['duration']) if end is not None else None
        key=hashlib.sha256((clip_id+'/'+frame+(':'+str(cut) if cut is not None else '')).encode()).hexdigest()[:32]
        if self.store.get('asset',key):return self.store.get('asset',key)
        from PIL import Image
        source=self.root/clip_id/frame
        if cut is not None:
            source=self.s.assets/(key+'.png')
            async with self.media.lock:await self.media.cut_frame(self.root/clip_id/'video.mp4',source,cut)
        def copy():
            with Image.open(source) as im:
                im=im.convert('RGB');im.save(self.s.assets/(key+'.png'));return im.size
        w,h=await asyncio.to_thread(copy)
        asset=dict(id=key,width=w,height=h,created=time.time(),url='/api/assets/'+key,source_clip=clip_id)
        self.store.put('asset',key,asset);return asset

    def batch(self,project_id,raw,key):
        if not re.fullmatch('[a-f0-9]{32}',key):raise ValueError('Identifiant du lot invalide.')
        previous=self.store.get('batch',key)
        if previous:return previous
        if any(b['status']=='running' for b in self.store.all('batch')):raise ValueError('Un lot tourne déjà. Mets-le en pause avant d’en lancer un autre.')
        project=self.get('project',project_id)
        p=parameters(raw['params'],False)
        if p['mode'] not in ('t2v','i2v') or p['engine']!='wan':raise ValueError('Les lots séquentiels utilisent le moteur vidéo Wan.')
        prompts=raw.get('prompts',[])
        if not isinstance(prompts,list) or not 1<=len(prompts)<=60:raise ValueError('Indique de 1 à 60 plans, un par ligne.')
        prompts=[str(x).strip() for x in prompts]
        if any(not x or len(x)>3500 for x in prompts):raise ValueError('Chaque plan doit contenir entre 1 et 3500 caractères.')
        initial=raw.get('initial_clip')
        if initial:self.get('clip',initial)
        if raw.get('initial_asset'):self.get('asset',raw['initial_asset'])
        if p['mode']=='i2v' and not initial and not p.get('asset_id'):raise ValueError('Ajoute une image de départ ou choisis un clip à prolonger.')
        b=dict(id=key,project_id=project_id,params=p,prompts=prompts,context=project['context'],chain=raw.get('chain',True) is True,
            initial_clip=initial,initial_asset=raw.get('initial_asset'),status='running',stage='Démarrage du lot',index=0,
            job_ids=[uid() for _ in prompts],clips=[],created=time.time())
        self.store.put('batch',key,b);return b

    async def tick(self):
        if self.batch_lock.locked():return
        async with self.batch_lock:
            for b in self.store.all('batch'):
                if b['status']!='running':continue
                try:
                    i=b['index']
                    if i>=len(b['prompts']):b.update(status='done',stage='Tous les plans sont prêts. Prévisualise puis exporte.');continue
                    job_id=b['job_ids'][i];j=self.store.get('job',job_id)
                    if j is None:
                        active=[x for x in self.s.jobs() if x['status'] not in ('done','error','cancelled','lost')]
                        if active:b['stage']='Attente de la génération déjà en cours';continue
                        p=dict(b['params']);p['prompt']='\n'.join(x for x in (b['context'],b['prompts'][i]) if x)
                        previous=b['clips'][-1] if i and b['chain'] else b.get('initial_clip')
                        if previous:
                            a=await self.reference(previous)
                            if i==0 and b.get('initial_asset'):
                                a=self.s.store.get('asset',b['initial_asset']) or a
                            p.update(mode='i2v',asset_id=a['id'])
                            p['prompt']+='\nContinuous shot from the reference image. Preserve the same person, face, clothing, setting and lighting.'
                        # Deterministic but distinct seeds; restarting this batch will never replay a submitted job.
                        p['seed']=(b['params']['seed']+i)%(2**53)
                        j=await self.s.submit(p,job_id)
                    b['stage']=f'Plan {i+1}/{len(b["prompts"])} · '+j.get('stage',j['status'])
                    if j['status']=='done':
                        clip=await self.from_job(job_id)
                        current=self.get('batch',b['id'])
                        if current['status']!='running':continue
                        overlap=1/clip['fps'] if b['chain'] and (i>0 or b.get('initial_clip')) else 0
                        self.append(b['project_id'],clip,start=overlap,entry_id=job_id)
                        b['clips'].append(clip['id']);b['index']+=1
                        if b['index']==len(b['prompts']):b.update(status='done',stage='Tous les plans sont prêts. Prévisualise puis exporte.')
                    elif j['status'] in ('error','cancelled','lost'):
                        b.update(status='paused',stage='Lot en pause : '+j.get('error',j.get('stage','Plan interrompu')))
                except Exception as e:b.update(status='paused',stage=str(e))
                finally:
                    current=self.store.get('batch',b['id'])
                    if current and current['status']!='running':b.update(status=current['status'],stage=current['stage'])
                    self.store.put('batch',b['id'],b)

    async def monitor(self):
        while True:
            await self.tick();await asyncio.sleep(2)

    async def export(self,project_id,raw,progress):
        p=self.get('project',project_id)
        if p['revision']!=int(raw.get('revision',-1)):raise ValueError('La timeline a changé. Prévisualise de nouveau avant d’exporter.')
        if not p['items']:raise ValueError('Ajoute des clips à la timeline.')
        w=int(number(raw.get('width',1280),256,1920));h=int(number(raw.get('height',704),256,1920));fps=int(number(raw.get('fps',24),8,60))
        if w%2 or h%2:raise ValueError('Dimensions d’export paires attendues.')
        work=self.root/('export-'+uid());work.mkdir();parts=[];dest=work/'film.mp4'
        try:
            async with self.media.lock:
                for i,item in enumerate(p['items']):
                    clip=self.get('clip',item['clip_id']);progress(f'Assemblage : préparation {i+1}/{len(p["items"])}',i/len(p['items']))
                    part=work/f'part-{i:04d}.mp4'
                    await self.media.normalize(self.root/clip['id']/'video.mp4',part,clip,item['start'],item['end'],w,h,fps,raw.get('mute',False))
                    parts.append(part)
                progress('Écriture du fichier MP4 final',.95);await self.media.concat(parts,dest,work)
                meta=await self.media.probe(dest)
            result=dict(id=work.name,project_id=project_id,project=p,created=time.time(),url=f'/api/exports/{work.name}',**meta)
            self.store.put('export',work.name,result)
            return result
        finally:
            for part in parts:part.unlink(missing_ok=True)
            (work/'concat.txt').unlink(missing_ok=True)
            if not self.store.get('export',work.name):shutil.rmtree(work,ignore_errors=True)

    async def close(self):
        for task in tuple(self.tasks.values()):task.cancel()
        await asyncio.gather(*tuple(self.tasks.values()),return_exceptions=True)
        await self.media.close()

    def routes(self):
        r=web.RouteTableDef()
        @r.get('/api/workshop')
        async def state(req):
            return web.json_response(dict(projects=self.store.all('project'),clips=self.store.all('clip'),batches=self.store.all('batch'),
                operations=sorted(self.store.all('operation'),key=lambda x:x['created'])[-40:],exports=self.store.all('export'),ffmpeg=available()))
        @r.post('/api/projects')
        async def new(req):return web.json_response(self.new_project((await req.json()).get('name')))
        @r.post('/api/projects/{key}')
        async def save(req):return web.json_response(self.save_project(req.match_info['key'],await req.json()))
        @r.post('/api/projects/{key}/batch')
        async def batch(req):return web.json_response(self.batch(req.match_info['key'],await req.json(),req.headers.get('Idempotency-Key','')))
        @r.post('/api/batches/{key}/{action}')
        async def control(req):
            b=self.get('batch',req.match_info['key']);action=req.match_info['action']
            if action not in ('pause','resume','cancel'):raise ValueError('Action inconnue.')
            if b['status'] in ('done','cancelled'):return web.json_response(b)
            if action=='resume' and any(x['id']!=b['id'] and x['status']=='running' for x in self.store.all('batch')):raise ValueError('Un autre lot est actif.')
            b['status']={'pause':'paused','resume':'running','cancel':'cancelled'}[action]
            b['stage']={'pause':'Pause après le plan en cours.','resume':'Reprise du lot','cancel':'Lot arrêté. Les clips terminés sont conservés.'}[action]
            if action=='resume':
                j=self.store.get('job',b['job_ids'][b['index']])
                if j and j['status'] in ('error','cancelled','lost'):
                    raise ValueError('Ce plan a échoué. Conserve les clips acquis et lance un nouveau lot pour la suite.')
            self.store.put('batch',b['id'],b)
            if action=='cancel':
                j=self.store.get('job',b['job_ids'][b['index']])
                if j and j['status'] not in ('done','error','cancelled','lost'):
                    try:await self.s.cancel(j['id'])
                    except Exception as e:b['stage']+=' '+str(e);self.store.put('batch',b['id'],b)
            return web.json_response(b)
        @r.post('/api/clips/from-job')
        async def from_job(req):
            data=await req.json()
            async def work(progress):
                progress('Import de la vidéo et des images de fin');c=await self.from_job(data['job_id'],data.get('index',0))
                if data.get('project_id'):self.append(data['project_id'],c)
                return c
            return web.json_response(self.launch('import',work))
        @r.post('/api/clips/upload')
        async def upload(req):
            if not available():raise ValueError('Installe d’abord le module vidéo dans Montage.')
            if shutil.disk_usage(self.root).free<3*1024**3:raise ValueError('Garde au moins 3 Go libres pour importer et monter les vidéos.')
            source=self.root/(uid()+'.source');total=0
            try:
                with source.open('wb') as f:
                    async for part in req.content.iter_chunked(1024*1024):
                        total+=len(part)
                        if total>1024**3:raise ValueError('1 Go maximum par vidéo.')
                        f.write(part)
            except BaseException:source.unlink(missing_ok=True);raise
            title=unquote(req.headers.get('X-Clip-Name','Vidéo importée'))[:120];project_id=req.query.get('project')
            async def work(progress):
                try:
                    progress('Préparation de la vidéo et des miniatures');c=await self.register(source,title)
                    if project_id:self.append(project_id,c)
                    return c
                finally:source.unlink(missing_ok=True)
            return web.json_response(self.launch('import',work))
        @r.post('/api/clips/{key}')
        async def metadata(req):
            clip=self.get('clip',req.match_info['key']);d=await req.json()
            if 'prompt' in d:clip['prompt']=str(d['prompt'])[:6000]
            if 'title' in d:clip['title']=str(d['title'])[:120]
            self.store.put('clip',clip['id'],clip)
            if clip['prompt']:self.s.prompt_library.save(dict(prompt=clip['prompt'],mode=clip['params'].get('mode','i2v'),params=clip['params'],negative=clip['params'].get('negative',''),clip_id=clip['id']))
            return web.json_response(clip)
        @r.post('/api/clips/{key}/reference')
        async def reference(req):
            c=self.get('clip',req.match_info['key']);data=await req.json()
            return web.json_response(dict(asset=await self.reference(c['id'],data.get('frame','last.png'),data.get('end')),clip=c))
        @r.post('/api/projects/{key}/split')
        async def split(req):
            data=await req.json();p=self.get('project',req.match_info['key']);seconds=number(data.get('seconds',4),.25,60);items=[]
            if int(data.get('revision',-1))!=p['revision']:raise ValueError('La timeline a changé. Actualise.')
            for item in p['items']:
                at=item['start']
                while at<item['end']-.001:
                    end=min(item['end'],at+seconds)
                    if end-at<.04 and items:items[-1]['end']=end;break
                    items.append(dict(id=uid(),clip_id=item['clip_id'],start=at,end=end));at=end
                    if len(items)>120:raise ValueError('Trop de coupes : choisis une durée plus longue.')
            return web.json_response(self.save_project(p['id'],{**p,'items':items}))
        @r.post('/api/projects/{key}/export')
        async def export(req):
            key=req.match_info['key'];data=await req.json()
            return web.json_response(self.launch('export',lambda progress:self.export(key,data,progress)))
        @r.post('/api/operations/{key}/cancel')
        async def stop(req):
            t=self.tasks.get(req.match_info['key'])
            if t:t.cancel()
            return web.json_response({'ok':True})
        @r.get('/api/clips/{key}/{name}')
        async def file(req):
            c=self.get('clip',req.match_info['key']);name=req.match_info['name']
            if name not in ('video.mp4','thumb.jpg',*c['tail']):raise web.HTTPNotFound()
            return web.FileResponse(self.root/c['id']/name)
        @r.get('/api/exports/{key}')
        async def exported(req):
            e=self.get('export',req.match_info['key'])
            headers={'Content-Disposition':'attachment; filename="'+re.sub(r'[^a-zA-Z0-9_-]','_',e['project']['name'])+'.mp4"'} if 'download' in req.query else {}
            return web.FileResponse(self.root/e['id']/'film.mp4',headers=headers)
        return r
