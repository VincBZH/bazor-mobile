"""Bounded local FFmpeg operations. No shell, remote inputs or model loading."""
import asyncio, contextlib, functools, math, os, re, shutil, subprocess
from pathlib import Path


@functools.lru_cache(maxsize=1)
def ffmpeg_path():
    candidate=shutil.which('ffmpeg')
    if candidate:return candidate
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        raise ValueError('Le module de montage manque. Clique sur « Installer le montage » dans Montage.')


def available():
    try:return bool(ffmpeg_path())
    except ValueError:return False


class MediaTools:
    def __init__(self):self.processes=set();self.lock=asyncio.Lock()

    async def run(self,args,timeout=600,check=True):
        flags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0
        proc=await asyncio.create_subprocess_exec(ffmpeg_path(),'-hide_banner','-nostdin','-y','-threads','2',
            *map(str,args),stdout=asyncio.subprocess.DEVNULL,stderr=asyncio.subprocess.PIPE,creationflags=flags)
        self.processes.add(proc)
        async def collect():
            tail=bytearray()
            while True:
                part=await proc.stderr.read(8192)
                if not part:break
                tail.extend(part)
                if len(tail)>96000:del tail[:-96000]
            await proc.wait()
            return tail.decode('utf-8','replace')
        try:
            log=await asyncio.wait_for(collect(),timeout)
            if check and proc.returncode:raise ValueError('Traitement vidéo interrompu : '+log[-2200:])
            return log
        finally:
            if proc.returncode is None:
                with contextlib.suppress(ProcessLookupError):proc.kill()
                await proc.wait()
            self.processes.discard(proc)

    def input(self,path):
        return ['-protocol_whitelist','file,pipe','-format_whitelist','mov,matroska,webm,avi,mpeg,mpegts,image2,png_pipe', '-i',str(path)]

    async def probe(self,path):
        log=await self.run([*self.input(path),'-map','0:v:0','-frames:v','1','-f','null','-'],timeout=45)
        duration=re.search(r'Duration: (\d+):(\d+):(\d+(?:\.\d+)?)',log)
        line=next((l for l in log.splitlines() if 'Video:' in l and 'Stream #' in l),'')
        size=re.search(r'\b(\d{2,5})x(\d{2,5})\b',line)
        fps=re.search(r'([\d.]+) fps',line)
        if not duration or not size:raise ValueError('Durée ou dimensions vidéo illisibles. Utilise un fichier MP4, MOV ou WebM.')
        seconds=int(duration[1])*3600+int(duration[2])*60+float(duration[3])
        if not .03<=seconds<=1800:raise ValueError('Import : vidéo entre 0,03 seconde et 30 minutes.')
        w,h=map(int,size.groups())
        if w*h>33_200_000:raise ValueError('Vidéo trop grande pour cet atelier.')
        # FFmpeg applies the display rotation on decode; report the displayed orientation.
        rotation=re.search(r'rotation of (-?[\d.]+) degrees',log)
        if rotation and round(float(rotation[1]))%180:w,h=h,w
        return dict(width=w,height=h,duration=seconds,fps=float(fps[1]) if fps else 24,audio='Audio:' in log)

    async def normalize(self,source,dest,meta,start=0,end=None,width=None,height=None,fps=None,mute=False):
        end=meta['duration'] if end is None else end
        if not 0<=start<end<=meta['duration']+.06:raise ValueError('Points de coupe invalides.')
        w=width or meta['width'];h=height or meta['height']
        ratio=min(1,1920/max(w,h));w=max(2,int(w*ratio)//2*2);h=max(2,int(h*ratio)//2*2)
        rate=fps or min(60,max(8,round(meta['fps'])))
        args=['-ss',f'{start:.6f}',*self.input(source)]
        has_audio=meta['audio'] and not mute
        if not has_audio:args+=['-f','lavfi','-i','anullsrc=r=48000:cl=stereo']
        args+=['-map','0:v:0','-map','0:a:0' if has_audio else '1:a:0',
            '-vf',f'scale={w}:{h}:force_original_aspect_ratio=decrease,pad={w}:{h}:(ow-iw)/2:(oh-ih)/2,setsar=1,fps={rate}',
            '-af','aresample=48000:async=1:first_pts=0,apad','-t',f'{end-start:.6f}',
            '-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p','-threads','2',
            '-c:a','aac','-b:a','192k','-ar','48000','-ac','2','-movflags','+faststart',str(dest)]
        await self.run(args,timeout=max(300,(end-start)*25))
        return await self.probe(dest)

    async def pictures(self,source,folder,meta):
        folder.mkdir(exist_ok=True,parents=True)
        await self.run([*self.input(source),'-frames:v','1','-vf','scale=320:-2',str(folder/'thumb.jpg')],45)
        # Decode the final second and keep the actual last decoded frame, not a guessed timestamp.
        await self.run(['-sseof','-1',*self.input(source),'-an','-update','1',str(folder/'last.png')],60)
        if not (folder/'last.png').exists():
            await self.run([*self.input(source),'-an','-update','1',str(folder/'last.png')],120)
        for i,offset in enumerate((.75,.5,.25)):
            at=max(0,meta['duration']-offset)
            await self.run(['-ss',str(at),*self.input(source),'-frames:v','1','-vf','scale=480:-2',str(folder/f'tail{i}.jpg')],45)
        return ['tail0.jpg','tail1.jpg','tail2.jpg','last.png']

    async def concat(self,paths,dest,work):
        # Internal generated names only; paths never come from the HTTP request.
        listing=work/'concat.txt'
        listing.write_text(''.join("file '"+p.name+"'\n" for p in paths),encoding='utf-8')
        await self.run(['-f','concat','-safe','1','-i',str(listing),'-c','copy','-movflags','+faststart',str(dest)],timeout=300)

    async def cut_frame(self,source,dest,end):
        start=max(0,end-1)
        await self.run(['-ss',str(start),*self.input(source),'-t',str(end-start),'-an','-update','1',str(dest)],120)
        if not dest.is_file():raise ValueError('Impossible de lire une image à ce point de coupe.')

    async def close(self):
        for p in tuple(self.processes):
            with contextlib.suppress(ProcessLookupError):p.kill()
