﻿param(
  [string]$AIRoot='C:\AI',
  [switch]$Elevated
)
$ErrorActionPreference='Stop'
$source=$PSScriptRoot

function Test-Administrator {
  $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
  $principal=New-Object Security.Principal.WindowsPrincipal($identity)
  return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Quote-Argument([string]$Value) {
  return '"'+$Value+'"'
}

try {
  if(-not (Test-Administrator)) {
    Write-Host 'Droits administrateur requis pour fermer une ancienne instance du Studio.' -ForegroundColor Yellow
    Write-Host 'Une confirmation Windows va apparaitre. Aucune commande manuelle n''est necessaire.' -ForegroundColor Cyan
    $powershell=(Get-Command powershell.exe -ErrorAction Stop).Source
    $args='-NoLogo -NoProfile -ExecutionPolicy Bypass -File '+(Quote-Argument $PSCommandPath)+' -AIRoot '+(Quote-Argument $AIRoot)+' -Elevated'
    $child=Start-Process -FilePath $powershell -ArgumentList $args -Verb RunAs -Wait -PassThru
    if($child.ExitCode -ne 0){Read-Host 'La reparation a echoue. Appuyez sur Entree pour fermer cette fenetre'}
    exit $child.ExitCode
  }

  . (Join-Path $source 'StartupTools.ps1')
  $release=Read-StudioRelease $source
  $verified=Assert-StudioFiles $source $release
  $target=Join-Path $AIRoot 'SimpleStudioV2'
  Write-Host ''
  Write-Host '=== OUTIL DE REPARATION BAZOR AI STUDIO V3 (3.0.5) ===' -ForegroundColor Cyan
  Write-Host ('Source verifiee : '+$source)
  Write-Host ('Destination conservee : '+$target)
  Write-Host ('Version '+$release.version+' - '+$verified+' fichiers conformes.') -ForegroundColor Green
  Write-Host 'ComfyUI, Wan, Forge, Ollama et les donnees utilisateur ne sont pas arretes.' -ForegroundColor Green
  $global:LASTEXITCODE=0
  & (Join-Path $source 'Installer.ps1') -AIRoot $AIRoot
  $installCode=if($LASTEXITCODE -is [int]){[int]$LASTEXITCODE}else{0}
  if($installCode -ne 0){throw ('L''installation ou le lancement a retourne le code '+$installCode+'.')}
} catch {
  Write-Host ''
  Write-Host ('REPARATION INTERROMPUE : '+$_.Exception.Message) -ForegroundColor Red
  Write-Host 'Relance ce fichier par clic droit > Executer avec PowerShell, puis accepte la demande Windows.' -ForegroundColor Yellow
  Read-Host 'Appuyez sur Entree pour fermer cette fenetre'
  exit 1
}
