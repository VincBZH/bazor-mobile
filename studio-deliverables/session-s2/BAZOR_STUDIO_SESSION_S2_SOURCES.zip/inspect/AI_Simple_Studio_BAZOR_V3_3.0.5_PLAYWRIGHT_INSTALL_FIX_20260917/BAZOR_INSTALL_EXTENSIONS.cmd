@echo off
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Installer_Extensions_BAZOR.ps1" %*
if errorlevel 1 (
  echo.
  echo Installation interrompue. Le message ci-dessus indique la cause.
  pause
  exit /b 1
)
echo.
echo Pour les extensions facultatives : BAZOR_INSTALL_EXTENSIONS.cmd -InstallOptional
echo Pour mettre a jour un depot deja present : ajouter -UpdateExisting
pause
