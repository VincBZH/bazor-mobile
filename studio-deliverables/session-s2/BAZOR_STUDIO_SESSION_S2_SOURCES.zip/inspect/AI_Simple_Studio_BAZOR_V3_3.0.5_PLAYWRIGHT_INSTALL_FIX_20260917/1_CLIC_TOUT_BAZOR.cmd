@echo off
setlocal EnableExtensions
chcp 65001 >nul
title BAZOR AI Studio V3 - 1 clic
echo.
echo ============================================================
echo   BAZOR AI STUDIO V3 - DEMARRAGE AUTOMATIQUE
echo ============================================================
echo.
set "ROOT=%~dp0"
if exist "%ROOT%DEMARRER.cmd" goto root_found
set "FALLBACK="
for /r "%~dp0" %%F in (DEMARRER.cmd) do (
  if not defined FALLBACK set "FALLBACK=%%~dpF"
  echo %%~dpF| findstr /I "BAZOR V3" >nul && (
    set "ROOT=%%~dpF"
    goto root_found
  )
)
if defined FALLBACK set "ROOT=%FALLBACK%"
if not exist "%ROOT%DEMARRER.cmd" (
  echo Dossier incomplet : DEMARRER.cmd est absent.
  echo Place ce fichier dans le dossier extrait complet, puis relance-le.
  pause
  exit /b 1
)
:root_found
cd /d "%ROOT%"
echo Dossier trouve : %ROOT%
if exist "%ROOT%Installer_Extensions_BAZOR.ps1" (
  echo [1/2] Verification des extensions qualite ComfyUI...
  powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%ROOT%Installer_Extensions_BAZOR.ps1" -AIRoot "C:\AI"
  if errorlevel 1 echo Extensions laissees intactes ou reportees : le Studio continue.
) else (
  echo [1/2] Installateur d'extensions absent : etape ignoree.
)
echo.
echo [2/2] Lancement verifie du Studio et ouverture du navigateur...
call "%ROOT%DEMARRER.cmd"
set CODE=%errorlevel%
if not "%CODE%"=="0" (
  echo.
  echo Le demarrage demande une verification. Le journal est dans C:\AI\SimpleStudioV2\logs.
) else (
  echo.
  echo Demarrage termine. Cette fenetre reste ouverte pour consulter le journal.
)
echo.
echo Appuyez sur une touche pour fermer cette fenetre.
pause
exit /b %CODE%
