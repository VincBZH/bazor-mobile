# Recherche BAZOR — qualité vidéo et concours IA

Date de vérification : 15 septembre 2026.

## Ce qui mérite d’être repris dans BAZOR

- Une seule intention principale par plan, avec un mouvement de caméra modéré.
- Une référence visuelle cohérente, un sujet explicitement conservé et une composition stable.
- Une première passe courte et peu coûteuse, puis une finition séparée si l’analyse détecte un défaut.
- Pose, profondeur et contours guidés par des preprocessors ; identité/style guidés par une image de référence.
- Contrôle visuel après rendu : détecter seulement les défauts visibles, puis corriger en conservant la demande initiale.

## Concours et travaux distingués

- **Runway AI Film Festival 2025** : Grand Prix *Total Pixel Space* de Jacob Adler, puis *Jailbird* d’Andrew Salter et *One* de Ricardo Villavicencio et Edward Saatchi. La sélection montre l’intérêt d’une narration lisible, de plans courts et d’un mélange maîtrisé entre vidéo IA et autres médias.
- **Runway AI Festival 2026** : Grand Prix *A Face Only A Mother Could Love* de Robert Gaudette ; Gold *THE WELL* de Dorian & Daniel. Les descriptions officielles mettent en avant un personnage clair, une progression simple et une réalisation tenue sur la durée.
- **Gen:48 — quatrième édition** : les œuvres gagnantes comprennent *FEAST* et *Aelita* ; la page officielle regroupe aussi les reconnaissances de craft, scénario et choix du public des éditions précédentes. C’est un bon signal pour l’outil de montage : chaque plan doit avoir une fonction narrative.
- **AI-ARTS 2025 — Video Gold** : *Return to Roots: Mother of Nature* d’Oksana. Le jury souligne une idée unique, une caméra retenue, une image et un son concentrés, sans surcharge d’effets.

## Extensions retenues

1. **ControlNet Aux officiel Comfy-Org** — pose, profondeur, contours et autres preprocessors. Installation par défaut.
2. **IPAdapter Plus de cubiq** — conservation du sujet et du style à partir d’une référence. Installation par défaut ; les poids IP-Adapter restent séparés.
3. **VideoHelperSuite de Kosinkadink** — chargement, aperçu, batch et export vidéo. Installation par défaut, sans remplacer le montage BAZOR.
4. **KJNodes de kijai** — option pour workflows Wan/vidéo avancés, seulement si un graphe le demande.
5. **Impact Pack de ltdrdata** — option pour detailer/upscale ; non installé par défaut car ses dépendances augmentent la charge.

## Versions observées

- ComfyUI officiel : **v0.35.0** est la candidate à tester depuis la base actuelle v0.34.0 ; sauvegarde et essai sans écraser Wan/H3 sont requis.
- Ollama : **v0.34.0** est la stable retenue ; la préversion v0.34.1 attend une validation.
- Wan 2.2 5B : le workflow officiel ComfyUI reste le chemin léger adapté à la RTX 4060 8 Go ; le 14B est à éviter par défaut sur cette machine.

## Sources spécialisées

- https://github.com/Comfy-Org/ComfyUI/releases
- https://comfy.org/workflows/video_wan2_2_5B_ti2v-f83ee3caa04e/
- https://github.com/comfyorg/comfyui-controlnet-aux
- https://github.com/cubiq/ComfyUI_IPAdapter_plus
- https://github.com/Kosinkadink/ComfyUI-VideoHelperSuite
- https://github.com/kijai/ComfyUI-KJNodes
- https://github.com/ltdrdata/ComfyUI-Impact-Pack
- https://aif.runwayml.com/
- https://runway.com/gen48
- https://ai-arts.org/competitions/4th-ai-arts-competition-2025/winners
