# BAZOR AI Studio V3 — 3.0.3 · arrêt ciblé de l’ancienne instance

Cette livraison corrige le blocage rencontré quand une ancienne instance du
Studio, lancée précédemment avec des droits élevés, refusait le premier arrêt.

- REPARER_STUDIO.ps1 demande automatiquement les droits administrateur avant
  toute modification ;
- le processus est revalidé par PID, ligne de commande exacte et date de
  création avant l’arrêt ;
- l’arrêt utilise Stop-Process -Force, puis taskkill /PID /T /F uniquement
  comme secours sur le processus Studio déjà identifié ;
- le port ComfyUI 8188, Wan, Forge, Ollama et les données utilisateur ne sont
  jamais ciblés ;
- si l’arrêt reste impossible, la copie de la mise à jour n’est pas effectuée
  et la fenêtre conserve le PID ainsi que le détail retourné par Windows ;
- le journal C:\AI\SimpleStudioV2\logs\installation.log conserve la cause
  exacte.

Le reste des correctifs de la V3.0.2 DEBUG est conservé : analyse vidéo,
journal après clic, bouton d’export du diagnostic, masquage des sorties
auxiliaires et suppression des entrées de galerie/prompts.
