@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
title BAZOR AI Studio V3 - Reparation checkpoint
echo.
echo === REPARATION AUTOMATIQUE DU CHECKPOINT IMAGE ===
echo Recherche Forge puis installation SDXL officielle si necessaire.
echo.
if not exist "%~dp0ReparerModeles.ps1" goto incomplete
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0ReparerModeles.ps1" -AIRoot "C:\AI"
if errorlevel 1 goto failed
echo.
echo Verification des modeles terminee. Cette fenetre reste ouverte pour le diagnostic.
pause
exit /b 0
:incomplete
echo DOSSIER INCOMPLET. Extraire tout le ZIP avant de relancer cet outil.
goto failed
:failed
echo.
echo LA REPARATION DU CHECKPOINT N'A PAS ABOUTI.
echo Journal : C:\AI\SimpleStudioV2\logs\model-repair-*.log
pause
exit /b 1
