# BAZOR AI Studio V3 — 3.0.2 DEBUG

Cette livraison corrige le faux échec affiché après un démarrage réussi et ajoute un mode de diagnostic persistant.

- le lanceur considère un `LASTEXITCODE` vide comme un succès et n’affiche plus `code .` après l’ouverture de `8191` ;
- le journal local `logs/studio-debug.jsonl` conserve les clics, l’état juste après chaque clic, les appels API, les réponses HTTP et les erreurs ;
- le bouton « Envoyer le log à GPT (ZIP) » est présent dans Système ; il prépare un ZIP à joindre manuellement ;
- les sorties fixes auxiliaires d’une vidéo sont masquées dans le résultat et la galerie, y compris dans l’historique déjà enregistré ;
- une création terminée peut être retirée de la galerie sans supprimer le fichier conservé par ComfyUI ; les prompts enregistrés peuvent être supprimés séparément ;
- l’analyse vidéo extrait la première et la dernière image via FFmpeg, journalise chaque étape et réessaie Ollama sans le mode JSON si une ancienne version le refuse avec des images ;
- l’inventaire SDXL/SD 1.5 combine le registre ComfyUI et les fichiers validés sur disque : le bouton d’installation SDXL est masqué lorsqu’un checkpoint image est déjà présent ;
- les styles et cadrages sélectionnés sont réinjectés côté serveur dans le graphe, avec cadrages stricts « debout » et « corps entier » ;
- les garde-fous restent actifs : le mode photo vise un rendu adulte réaliste et éditorial non explicite, sans génération pornographique explicite.

Les fichiers de données, les modèles, ComfyUI, Wan, Forge et Ollama ne sont pas supprimés ni redémarrés par l’installation.
