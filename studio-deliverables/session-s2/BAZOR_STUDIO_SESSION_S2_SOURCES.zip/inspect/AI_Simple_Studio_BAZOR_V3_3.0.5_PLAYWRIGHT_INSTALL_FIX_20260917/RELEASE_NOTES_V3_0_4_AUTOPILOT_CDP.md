# BAZOR AI Studio V3 — 3.0.4 · Autopilot Chrome/CDP

Cette version ajoute un pont local entre le Studio, Chrome normal et Playwright
pour diagnostiquer le clic du menu de profil ChatGPT.

- **Système → Autopilot Chrome / CDP** permet d’attacher Playwright à Chrome
  via `127.0.0.1:9223` et de tester le menu de profil.
- La classe `StudioAutomation` tente d’abord
  `locator.click(force=True)` sur `[data-testid="accounts-profile-button"]`.
- En cas d’échec, elle utilise `page.evaluate` pour désactiver
  temporairement `pointer-events` sur le parent `overflow-x-clip`, déclenche le
  clic, puis restaure la valeur et la priorité inline dans `finally`.
- Le profil persistant `C:\BAZOR_EXPORT_AUTOPILOT\chrome_profile` est conservé.
  Le Studio n’arrête pas Chrome personnel et le CDP reste limité à la boucle
  locale.
- `Installer.ps1` installe Playwright dans le Python portable de ComfyUI quand
  celui-ci est détecté. La génération Studio reste utilisable si l’installation
  réseau de Playwright échoue ; le panneau affiche alors le diagnostic.

Lancer `DEMARRER.cmd`, puis ouvrir **Système**. Le bouton **Attacher à Chrome
normal** prépare la connexion ; **Tester le menu Profil** exécute le clic et
affiche la méthode utilisée ainsi que les erreurs éventuelles.
