# BAZOR AI Studio V3 — 3.0.5 · Installation Playwright robuste

La 3.0.4 pouvait interrompre `Installer.ps1` lorsque le test
`import playwright` renvoyait un traceback Python. PowerShell recevait alors la
sortie stderr comme une erreur terminante avant de lancer le Studio.

Correctif :

- le test d’import et l’installation pip sont exécutés par une fonction isolée
  qui capture stdout/stderr et contrôle explicitement le code retour ;
- un échec réseau ou Python affiche un avertissement sans bloquer l’installation
  du Studio ;
- le Studio reste utilisable sans Playwright, avec le diagnostic
  `PLAYWRIGHT_MISSING` dans le panneau **Système** ;
- ComfyUI 8188, ses extensions, ses modèles et les données du Studio ne sont
  ni arrêtés ni écrasés par ce correctif.

Lancer `DEMARRER.cmd` depuis le nouveau ZIP. L’installation cible reste
`C:\AI\SimpleStudioV2`.
