'use strict';
const browserEvents=[];
const browserDebugEvents=[];let debugFlushTimer=null,debugSending=false;
const debugText=value=>String(value??'').slice(0,1600);
function debugSnapshot(){
 const values={};
 for(const id of ['mode','prompt','negative','stylePreset','width','height','frames','fps','steps','seed','engine','checkpoint','ollamaModel','analysisStatus','formError']){
  const el=$(id);if(el)values[id]=debugText(el.value??el.textContent??'');
 }
 values.view=typeof view==='string'?view:'';values.jobs=typeof jobs!=='undefined'?jobs.slice(0,8).map(j=>({id:j.id,status:j.status,stage:j.stage})):[];
 return values;
}
function debugEvent(event,values={}){
 const row={event:String(event).slice(0,100),time:new Date().toISOString(),...values};browserDebugEvents.push(row);browserDebugEvents.splice(0,browserDebugEvents.length-500);
 clearTimeout(debugFlushTimer);debugFlushTimer=setTimeout(flushDebugEvents,120);
}
async function flushDebugEvents(){
 if(debugSending||!window.__bazorToken||!browserDebugEvents.length)return;
 debugSending=true;const batch=browserDebugEvents.splice(0,60);
 try{const r=await fetch('/api/debug/event',{method:'POST',headers:{'X-Studio-Token':window.__bazorToken,'Content-Type':'application/json'},body:JSON.stringify({events:batch})});if(!r.ok)browserDebugEvents.unshift(...batch)}catch{browserDebugEvents.unshift(...batch)}finally{debugSending=false;if(browserDebugEvents.length)debugFlushTimer=setTimeout(flushDebugEvents,300)}
}
const isHarmlessResizeObserverError=message=>{
 const text=String(message??'');
 return text.includes('ResizeObserver loop completed with undelivered notifications')||text.includes('ResizeObserver loop limit exceeded');
};
window.addEventListener('error',event=>{
 browserEvents.push({type:'error',message:String(event?.message||'Erreur JavaScript'),source:event?.filename||'',line:event?.lineno||0,time:new Date().toISOString()});browserEvents.splice(0,browserEvents.length-100);
 debugEvent('browser.error',{message:debugText(event?.message),source:debugText(event?.filename),line:event?.lineno||0});
 if(isHarmlessResizeObserverError(event?.message)){event.preventDefault?.();event.stopImmediatePropagation?.();}
},true);
window.addEventListener('unhandledrejection',event=>{
 const reason=event?.reason;
 const message=reason?.message??reason;
 browserEvents.push({type:'unhandledrejection',message:String(message||'Promesse rejetée'),time:new Date().toISOString()});browserEvents.splice(0,browserEvents.length-100);
 debugEvent('browser.unhandledrejection',{message:debugText(message)});
 if(isHarmlessResizeObserverError(message)){event.preventDefault?.();event.stopImmediatePropagation?.();}
},true);
const $=id=>document.getElementById(id);
if($('frames'))$('frames').max='241';
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
document.addEventListener('click',event=>{
 const el=event.target?.closest?.('button,a,label,summary,input[type="submit"]');if(!el)return;
 const clicked={tag:el.tagName,id:el.id||'',text:debugText(el.innerText||el.textContent||''),
   data:{...el.dataset},disabled:!!el.disabled,view:typeof view==='string'?view:'',mode:typeof mode==='string'?mode:''};
 debugEvent('click',clicked);
 const later=window.queueMicrotask||((fn)=>setTimeout(fn,0));later(()=>debugEvent('after_click',{clicked,state:debugSnapshot()}));
},true);
const presets={fast:[640,352,49,20],balanced:[832,480,49,24],quality:[1280,704,49,28]};
const styleRules={realistic:{label:'Photo réaliste',short:'Détails naturels et cohérents',prompt:'Photorealistic result, natural skin and fabric detail, physically plausible lighting, stable subject and consistent composition.',negative:'plastic skin, oversmoothing, artificial anatomy'},portrait:{label:'Portrait',short:'Visage et expression stables',prompt:'Portrait framing, stable facial identity, clear eyes and expression, shoulders and upper body well composed, gentle camera movement.',negative:'warped face, changing identity, cropped eyes'},fullbody:{label:'Corps entier',short:'Sujet visible de la tête aux pieds',prompt:'Full-body composition, all requested subjects visible from head to feet, balanced space around the body, stable proportions and camera distance.',negative:'cropped body, cut-off feet, distorted proportions'},standing:{label:'Debout',short:'Sujet droit, appui stable',prompt:'For subjects requested standing: upright on both feet with stable posture. Preserve other subjects in their requested poses.',negative:'impossible balance, floating feet, cut-off legs, cut-off feet'},bw:{label:'Noir et blanc',short:'Contraste photo, tons monochromes',prompt:'High-quality black-and-white photography, rich grayscale tones, controlled contrast, natural light, no color accents.',negative:'color cast, oversaturated colors, posterization'},cinematic:{label:'Cinématique',short:'Plan composé et caméra douce',prompt:'Cinematic shot, deliberate composition, soft controlled camera movement, coherent lighting and realistic depth.',negative:'random camera movement, abrupt cuts, inconsistent lighting'},natural:{label:'Naturel',short:'Mouvement discret et lisible',prompt:'Natural everyday motion, restrained gestures, stable framing, preserve each requested action and subject, no unrequested subjects or objects.',negative:'excessive motion, extra subjects, impossible action'},adultEditorial:{label:'Éditorial adulte',short:'Mode sophistiquée, rendu sobre',prompt:'Tasteful adult fashion editorial, sophisticated styling, poised adult subject, non-explicit composition.',negative:'explicit nudity, graphic sexual content, fetish focus'},confidentPose:{label:'Pose assurée',short:'Attitude élégante et affirmée',prompt:'Confident adult body language, elegant suggestive pose, tasteful framing, no graphic detail.',negative:'graphic sexual action, explicit exposure, vulgar pose'},lingerieFashion:{label:'Mode lingerie',short:'Style studio haut de gamme',prompt:'High-end lingerie fashion editorial, refined styling, opaque coverage, studio-quality lighting, non-explicit.',negative:'transparent fabric, explicit exposure, graphic detail'},silhouette:{label:'Silhouette mise en valeur',short:'Cadrage mode et proportions stables',prompt:'Tasteful silhouette emphasis through fashion posing and balanced composition, adult subject, non-explicit.',negative:'distorted anatomy, explicit exposure'},cameraGaze:{label:'Regard caméra',short:'Présence directe et identité stable',prompt:'Direct confident gaze toward the camera, poised adult expression, stable identity.',negative:'changing gaze, warped eyes, unstable identity'},boudoirLight:{label:'Lumière boudoir',short:'Ambiance intime, traitement éditorial',prompt:'Elegant boudoir-inspired lighting, refined interior editorial mood, adult fashion context, non-explicit.',negative:'dark artifacts, explicit scene, voyeuristic framing'}};
const isImage=()=>mode==='t2i'||mode==='i2i';
const labels={i2i:'Image + texte → Image',t2v:'Texte → Vidéo',i2v:'Image → Vidéo',t2i:'Texte → Image',v2v:'Vidéo → Vidéo · bêta'};
const notes={i2i:'Retouchez une image avec votre texte. Le curseur Transformation règle la liberté donnée au modèle.',t2v:'Créez une courte vidéo depuis le texte seul. Pour une photo de départ, choisissez Image → Vidéo.',i2v:'Une seule photo de départ. Le cadrage est adapté au format choisi.',t2i:'Un checkpoint SD 1.5 / SDXL validé est obligatoire pour obtenir une image cohérente. Wan reste réservé à la vidéo.',v2v:'BÊTA : la première image de votre vidéo est réanimée. Le mouvement et le son d’origine ne sont pas transférés.'};
const sessionStartedS2=Date.now()/1000,sessionJobsS2=new Set();
let token='',mode='t2v',stylePresets=['realistic'],styleBasePrompt='',applyingStyle=false,asset=null,jobs=[],health={},view='create',filter='all',uploading=false,submitting=false,optimizing=false,originalPrompt='',selectedResult='',resultSignature='',gallerySignature='',pendingRequest=null,uploadSeq=0,previewUrl=null,formRestored=false,correctionBusy=false,correctionStop=false,correctionAttempts=0,autoAnalyzedJobs=new Set(),lastAnalysis=null;
const terminal=j=>['done','error','cancelled','lost'].includes(j.status);
const fmt=s=>s==null?'À calibrer':`${Math.floor(Math.max(0,s)/60)} min ${String(Math.round(Math.max(0,s)%60)).padStart(2,'0')} s`;
const short=s=>s==null?'—':fmt(s);
const api=async(path,data,opts={})=>{
 const method=data===undefined?'GET':'POST';debugEvent('api.request',{method,path,body:data===undefined?null:debugText(JSON.stringify(data))});
 const headers={'X-Studio-Token':token,...opts.headers};if(data!==undefined)headers['Content-Type']='application/json';
 try{
  const r=await fetch(path,{method,headers,body:data===undefined?undefined:JSON.stringify(data),...opts});
  const text=await r.text();let out;try{out=JSON.parse(text)}catch{debugEvent('api.parse_error',{method,path,status:r.status,response:debugText(text)});throw Error('Le studio ne répond pas correctement. Rechargez la page.')}
  if(!r.ok){debugEvent('api.error',{method,path,status:r.status,error:debugText(out.error)});throw Error(out.error||`Réponse HTTP ${r.status}`)}
  debugEvent('api.response',{method,path,status:r.status,keys:Object.keys(out||{})});return out;
 }catch(e){debugEvent('api.exception',{method,path,error:debugText(e?.message||e)});throw e}
};
function error(message){$('formError').textContent=message;$('formError').classList.toggle('hidden',!message)}
function payload(){const frames=isImage()?1:+$('frames').value;return{...preparedPayloadS23(),mode,prompt:$('prompt').value,negative:$('negative').value,style_preset:stylePresets.join('+'),style_presets:[...stylePresets],artistic:$('artistic').checked,tiled:$('tiled').checked,width:+$('width').value,height:+$('height').value,denoise:+$('denoise').value,frames,fps:+$('fps').value,duration_seconds:isImage()?null:frames/+$('fps').value,steps:+$('steps').value,seed:$('seed').value,asset_id:['i2i','i2v','v2v'].includes(mode)?(asset?.id||null):null,engine:isImage()?'sd':'wan',checkpoint:$('checkpoint').value||null,ollama_model:$('ollamaModel').value}}
function saveDraft(){try{localStorage.removeItem('studio2-draft')}catch{}}
function changeView(v){view=v;document.querySelectorAll('.view').forEach(el=>el.classList.toggle('hidden',el.id!=='view-'+v));document.querySelectorAll('.nav').forEach(b=>{b.classList.toggle('active',b.dataset.view===v);if(b.dataset.view===v)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current')});if(v==='gallery')renderGallery();if(v==='diagnostic'){renderDiagnostic();loadLogs()}window.scrollTo({top:0,behavior:'instant'})}
function updateMode(m){if(['t2i','t2v'].includes(m))clearSourceS2();mode=m;document.querySelectorAll('.mode').forEach(b=>{b.classList.toggle('active',b.dataset.mode===m);b.setAttribute('aria-pressed',String(b.dataset.mode===m))});$('modeNote').textContent=notes[m];$('engineArea').classList.toggle('hidden',!(m==='t2i'||m==='i2i'));if(isImage())$('engine').value='sd';$('file').accept=m==='v2v'?'video/*':'image/png,image/jpeg,image/webp';$('uploadLabel').innerHTML=m==='v2v'?'Vidéo de départ':`Photo de départ ${(m==='i2v'||m==='i2i')?'':'<span>facultative</span>'}`;$('chooseFile').textContent=m==='v2v'?'Sélectionner une vidéo':'Sélectionner une photo';$('dropHelp').textContent=m==='v2v'?'Glissez une vidéo ici · première image extraite sur votre PC':'Glissez une image ici ou collez-la avec Ctrl + V';$('generate').firstElementChild.textContent=(m==='t2i'||m==='i2i')?'Générer l’image':'Générer la vidéo';$('frames').disabled=(m==='t2i'||m==='i2i');$('frames').min=(m==='t2i'||m==='i2i')?'1':'5';if(!(m==='t2i'||m==='i2i')&&+$('frames').value<5)$('frames').value=49;$('fps').disabled=(m==='t2i'||m==='i2i');engineChanged();updateSpecs();buttons();saveDraft()}
function engineChanged(){
 if(isImage())$('engine').value='sd';
 const sd=isImage()&&$('engine').value==='sd';
 $('checkpoint').classList.toggle('hidden',!sd);$('checkpointLabel').classList.toggle('hidden',!sd);
 $('uploadArea').classList.toggle('hidden',mode==='t2i'||mode==='t2v');$('denoiseArea').classList.toggle('hidden',mode!=='i2i');$('clipDurationArea').classList.toggle('hidden',isImage());
 if(mode==='t2i'&&asset){asset=null;showAsset(null)}
 saveDraft();scheduleEstimate()
}
function updateSpecs(){$('specs').textContent=`${$('width').value} × ${$('height').value} · ${isImage()?'Image fixe':(+$('frames').value/+$('fps').value).toLocaleString('fr-FR',{maximumFractionDigits:1})+' s'} · ${$('steps').value} étapes`;$('rotate').textContent=+$('width').value>+$('height').value?'↔ Passer en portrait':'↔ Passer en paysage';scheduleEstimate()}
function syncStylePrompt(write=true){const selected=stylePresets.length?stylePresets:['realistic'];stylePresets=selected;const rules=selected.map(k=>styleRules[k]||styleRules.realistic);if(write){styleBasePrompt=styleBasePrompt||$('prompt').value.split('\n\n[Style visuel]')[0].trim();const extras=rules.map(r=>r.prompt).join(' ');applyingStyle=true;$('prompt').value=styleBasePrompt?`${styleBasePrompt}\n\n[Style visuel] ${extras}`:extras;applyingStyle=false}document.querySelectorAll('input[data-style-check]').forEach(i=>{const active=selected.includes(i.dataset.styleCheck);i.checked=active;i.closest('.style-check')?.classList.toggle('active',active)});updateSpecs();saveDraft()}
function applyStylePreset(key){styleBasePrompt=$('prompt').value.split('\n\n[Style visuel]')[0].trim();stylePresets=[key];syncStylePrompt()}
function toggleStylePreset(key){if(stylePresets.includes(key))stylePresets=stylePresets.filter(x=>x!==key);else stylePresets.push(key);if(!stylePresets.length)stylePresets=['realistic'];syncStylePrompt()}
function suggestSettings(){
 const text=$('prompt').value.toLowerCase();let key='realistic';
 if(/noir et blanc|noir-blanc|monochrome|black and white/.test(text))key='bw';
 else if(/corps entier|plein pied|tête aux pieds|full body|whole body/.test(text))key='fullbody';
 else if(/portrait|visage|tête|regard|yeux/.test(text))key='portrait';
 else if(/cinéma|cinematic|film|travelling|travelling/.test(text))key='cinematic';
 else if(/marche|danse|bouge|mouvement|geste/.test(text))key='natural';
 applyStylePreset(key);applyPreset('balanced');
 const family=health.profile?.family==='h3'?'MiniMax H3':isImage()?'SDXL/SD':'Wan 2.2';
 $('suggestionState').textContent=`Suggestion : ${styleRules[key].label} · ${family} · réglage Équilibré adapté à votre RTX 4060 8 Go.`;
}
function applyPreset(key){
 let v=[...presets[key]];
 if(isImage()){
  const family=(window.studioModelFamilies||{})[$('checkpoint').value]||'sdxl';
  const size=family==='sd15'?{fast:[512,512,1,20],balanced:[512,768,1,24],quality:[640,768,1,28]}:{fast:[768,768,1,20],balanced:[1024,1024,1,28],quality:[1152,896,1,32]};v=[...size[key]];
 }
 if(+$('height').value>+$('width').value&&v[0]>v[1])[v[0],v[1]]=[v[1],v[0]];
 ['width','height','steps'].forEach((k,i)=>$(k).value=v[[0,1,3][i]]);
 document.querySelectorAll('.preset').forEach(b=>{b.classList.toggle('active',b.dataset.preset===key);b.setAttribute('aria-pressed',String(b.dataset.preset===key))});updateSpecs();saveDraft()
}
let estimateTimer,estimateSeq=0;
function scheduleEstimate(){clearTimeout(estimateTimer);if(token)estimateTimer=setTimeout(loadEstimate,350)}
async function loadEstimate(){const seq=++estimateSeq;try{const e=await api('/api/estimate',payload());if(seq!==estimateSeq)return;$('estimateValue').textContent=e.seconds==null?'Temps à calibrer sur votre PC':`Environ ${fmt(e.seconds)}`;$('estimateDetail').textContent=e.seconds==null?'La première génération servira de référence.':`${fmt(e.low)} à ${fmt(e.high)} · confiance ${e.confidence.toLowerCase()} · ${e.samples} référence(s)`}catch{$('estimateValue').textContent='Vérifiez les réglages';$('estimateDetail').textContent='Dimensions multiples de 32, et 4n+1 images pour la vidéo.'}}
function buttons(){const busy=uploading||submitting||optimizing;$('generate').disabled=busy||!token;$('optimize').disabled=busy||!health.ollama||!$('ollamaModel').value||jobs.some(j=>!terminal(j));$('chooseFile').disabled=uploading;$('removeAsset').disabled=uploading;const done=jobs.some(j=>j.id===selectedResult&&j.status==='done'&&j.outputs?.length);$('analyzeResult').disabled=correctionBusy||!health.ollama||!done;$('stopCorrections').disabled=!correctionBusy}
function showAsset(a,url){$('assetPreview').classList.toggle('hidden',!a);$('dropIntro').classList.toggle('hidden',!!a);$('removeAsset').classList.toggle('hidden',!a);if(a){const src=url||a.url||'/api/assets/'+a.id;$('assetPreview').src=src;$('referenceMirror').classList.remove('hidden');$('referenceMirrorImage').src=src;$('referenceMirrorState').textContent='Photo de départ prête'}else{$('assetPreview').removeAttribute('src');$('assetState').textContent='';$('referenceMirror').classList.add('hidden');$('referenceMirrorImage').removeAttribute('src')}$('assetState').classList.remove('failed')}
async function firstFrame(file){if(file.size>250*1024*1024)throw Error('Vidéo trop volumineuse : 250 Mo maximum.');const video=document.createElement('video');video.muted=true;video.playsInline=true;const url=URL.createObjectURL(file);video.src=url;try{await new Promise((resolve,reject)=>{const timeout=setTimeout(()=>reject(Error('Cette vidéo ne peut pas être lue dans le navigateur. Essayez un MP4 H.264.')),20000);video.onloadeddata=()=>{clearTimeout(timeout);resolve()};video.onerror=()=>{clearTimeout(timeout);reject(Error('Format vidéo illisible. Essayez un MP4 H.264.'))};video.load()});const c=document.createElement('canvas');const ratio=Math.min(1,2048/Math.max(video.videoWidth,video.videoHeight));c.width=Math.round(video.videoWidth*ratio);c.height=Math.round(video.videoHeight*ratio);c.getContext('2d').drawImage(video,0,0,c.width,c.height);return await new Promise((resolve,reject)=>c.toBlob(b=>b?resolve(b):reject(Error('Extraction de la première image impossible.')),'image/png'))}finally{video.removeAttribute('src');video.load();URL.revokeObjectURL(url)}}
async function upload(file){if(!file||uploading)return;if(['t2i','t2v'].includes(mode)){error('Choisis un mode avec image pour importer une référence.');return}const seq=++uploadSeq;uploading=true;asset=null;error('');debugEvent('upload.start',{name:debugText(file.name),type:file.type,size:file.size,mode});buttons();$('assetState').classList.remove('failed');$('assetState').textContent='Préparation de votre fichier…';try{let blob=file;const isVideo=file.type.startsWith('video/');if(mode==='v2v'&&!isVideo)throw Error('Choisissez une vidéo pour ce mode, ou passez en Image → Vidéo.');if(isVideo){if(mode!=='v2v')throw Error('Passez en Vidéo → Vidéo pour importer ce fichier.');blob=await firstFrame(file)}else if(!file.type.startsWith('image/'))throw Error('Choisissez une image PNG, JPG ou WebP.');if(blob.size>20*1024*1024)throw Error('Image trop lourde : 20 Mo maximum.');if(previewUrl)URL.revokeObjectURL(previewUrl);previewUrl=URL.createObjectURL(blob);showAsset({id:'preview'},previewUrl);$('assetState').textContent='Aperçu local · vérification en cours…';const r=await fetch('/api/upload',{method:'POST',headers:{'X-Studio-Token':token,'Content-Type':'application/octet-stream'},body:blob});const a=await r.json();debugEvent('upload.response',{status:r.status,ok:r.ok,asset_id:a?.id||''});if(!r.ok)throw Error(a.error||'Import non terminé.');if(seq!==uploadSeq)return;asset=a;showAsset(a);$('assetState').textContent=isVideo?'Première image extraite et prête à être réanimée.':`Photo prête · ${a.width} × ${a.height}`;saveDraft()}catch(e){debugEvent('upload.error',{error:debugText(e?.message||e)});asset=null;showAsset(null);$('assetState').textContent=e.message;$('assetState').classList.add('failed')}finally{uploading=false;$('file').value='';buttons()}}
async function refreshHealth(){try{
 health=await api('/api/health');$('connection').classList.toggle('ready',health.ready);$('connection').classList.toggle('offline',!health.ready);
 const family=health.profile?.family==='h3'?'MiniMax H3':health.profile?.family==='wan'?'Wan 2.2':'';
 $('connectionText').textContent=health.ready?`ComfyUI connecté · ${family||'moteur compatible'} · moteur joignable · workflow vérifié à l’envoi`:health.comfy?`ComfyUI connecté · ${family||'installation'} à vérifier dans Diagnostic`:'ComfyUI hors ligne · lancez le raccourci NVIDIA puis cliquez sur Vérifier';
 const old=$('ollamaModel').value,models=health.models||[];$('ollamaModel').innerHTML=models.length?models.map(m=>`<option value="${esc(m)}">${esc(m)}</option>`).join(''):'<option value="">Ollama indisponible</option>';if(models.includes(old))$('ollamaModel').value=old;else if(models.includes('gemma3:4b'))$('ollamaModel').value='gemma3:4b';
 const ck=$('checkpoint').value,checkpoints=health.checkpoints||[];$('checkpoint').innerHTML=checkpoints.length?checkpoints.map(m=>`<option value="${esc(m)}">${esc(m)}</option>`).join(''):'<option value="">Aucun checkpoint installé</option>';if(checkpoints.includes(ck))$('checkpoint').value=ck;else{const choice=generalCheckpointS2(checkpoints);if(choice)$('checkpoint').value=choice;else{const option=document.createElement('option');option.value='';option.textContent='Choisir un modèle image installé';$('checkpoint').prepend(option);$('checkpoint').value=''}}
 const imageReady=!!(health.image_checkpoint_present||checkpoints.length);$('installSDXL').classList.toggle('hidden',imageReady);$('installSDXL').disabled=imageReady;
 if($('modelHint'))$('modelHint').textContent=imageReady?`${checkpoints.length||1} checkpoint(s) image détecté(s) sur le disque. Le bouton d’installation SDXL est masqué pour éviter un doublon.`:'Aucun checkpoint image installé : génération d’image bloquée. Recherchez les modèles existants ou lancez REPARER_MODELES.cmd.';
 renderAutopilot(health.autopilot||{});if(view==='diagnostic')renderDiagnostic();buttons();debugEvent('health.render',{ready:health.ready,checkpoints,sdxl_present:!!health.sdxl_present,autopilot:health.autopilot?.code||''});
 }catch(e){$('connection').className='connection offline';$('connectionText').textContent='Connexion au studio interrompue · reconnexion automatique…';debugEvent('health.error',{error:debugText(e?.message||e)})}}

async function verifyJob(id,automatic=false){if(submitting||!id)return;submitting=true;if(!automatic)error('');buttons();try{const j=await api('/api/jobs/'+encodeURIComponent(id)+'/verify',{});selectedResult=j.id;resultSignature='';if(['submitting','uncertain'].includes(j.status)){pendingRequest=j.id;error('Demande conservée : le moteur n’a pas encore confirmé cette génération. Vérifie à nouveau dans quelques secondes.')}else{pendingRequest=null;if(j.status==='error')error(j.error||j.stage)}await refreshJobs()}catch(e){if(!automatic)error('Vérification impossible pour le moment : '+e.message)}finally{submitting=false;buttons();saveDraft()}}
async function generate(e){e?.preventDefault();if(submitting||uploading||optimizing)return;const pending=pendingRequest&&jobs.find(j=>j.id===pendingRequest);if(pending&&['submitting','uncertain'].includes(pending.status)){await verifyJob(pending.id);return}if(!$('form').reportValidity())return;const p=payload();if(isImage()&&(!(health.checkpoints||[]).length||!p.checkpoint)){error('Aucun checkpoint image SD 1.5 / SDXL validé. Installe-le puis clique sur Actualiser les modèles.');return}if((mode==='i2v'||mode==='v2v'||mode==='i2i')&&!asset){error('Ajoutez votre image ou votre vidéo de départ.');return}if(jobs.some(j=>['submitting','uncertain'].includes(j.status))){error('Une demande attend sa confirmation. Utilise « Vérifier la demande » dans le suivi avant d’en relancer une autre.');return}submitting=true;error('');buttons();pendingRequest=pendingRequest||crypto.randomUUID();try{const j=await api('/api/jobs',p,{headers:{'X-Studio-Token':token,'Content-Type':'application/json','Idempotency-Key':pendingRequest}});if(!['submitting','uncertain'].includes(j.status))pendingRequest=null;sessionJobsS2.add(j.id);selectedResult=j.id;clearAnalysisS2();resultSignature='';await refreshJobs();if(j.status==='error')error(j.error||j.stage);else if(['submitting','uncertain'].includes(j.status)){error('Demande conservée : la réponse du moteur est à confirmer. Le prochain clic sur Générer vérifiera cette même demande sans doublon.');setTimeout(()=>{if(pendingRequest===j.id)verifyJob(j.id,true)},2500)}}catch(e){error(e.message+' La demande reste conservée : le prochain clic vérifiera la même demande sans doublon.');if(pendingRequest)setTimeout(()=>{if(pendingRequest)verifyJob(pendingRequest,true)},2500)}finally{submitting=false;buttons();saveDraft()}}
async function refreshJobs(){try{const r=await api('/api/jobs');acceptJobs(r.jobs)}catch{}}
function acceptJobs(next){jobs=next||[];$('count').textContent=jobs.filter(j=>j.status==='done'&&j.outputs?.length).length;renderActivity();renderResult();if(view==='gallery')renderGallery();buttons();}
function selectedDone(){return jobs.find(j=>j.id===selectedResult&&j.status==='done'&&j.outputs?.length)}
function showAnalysis(a){const detected=Array.isArray(a.detected)?a.detected:[];const preserved=Array.isArray(a.preserved)?a.preserved:[];$('analysisReport').classList.remove('hidden');$('analysisReport').innerHTML=`<div class="analysis-score ${Number(a.score)>=80?'good':'bad'}"><b>${esc(a.score??'—')}/100</b><small>${a.needs_correction?'Correction conseillée':'Résultat jugé cohérent'}</small></div><div><b>Ce qui est détecté</b><p>${detected.length?detected.map(esc).join(' · '):'Aucun défaut visible signalé.'}</p><b>Correction proposée</b><p>${esc(a.correction||'Aucune correction nécessaire.')}</p>${preserved.length?`<small class="hint">Intentions conservées : ${preserved.map(esc).join(' · ')}</small>`:''}${a.needs_correction?'<button type="button" class="primary" data-apply-analysis="1">Appliquer la correction et régénérer</button>':''}</div>`}

async function exportSupportBundle(){const status=$('exportSupportStatus');status.textContent='Préparation du ZIP…';debugEvent('support.export.start',{browser_events:browserDebugEvents.length});try{await flushDebugEvents();const r=await fetch('/api/support-bundle',{method:'POST',headers:{'X-Studio-Token':token,'Content-Type':'application/json'},body:JSON.stringify({remarks:$('diagnosticRemarks').value,browser_events:[...browserEvents,...browserDebugEvents].slice(-250)})});if(!r.ok){let e={};try{e=await r.json()}catch{}throw Error(e.error||`Réponse HTTP ${r.status}`)}const blob=await r.blob();const url=URL.createObjectURL(blob);const link=document.createElement('a');link.href=url;link.download=`BAZOR_V3_diagnostic_${new Date().toISOString().replace(/[:.]/g,'-')}.zip`;link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);status.textContent='ZIP prêt · joins-le à ton message GPT.';debugEvent('support.export.done',{bytes:blob.size})}catch(e){status.textContent=e.message;debugEvent('support.export.error',{error:debugText(e?.message||e)})}}
async function waitForJob(id){for(let i=0;i<600;i++){if(correctionStop)throw Error('Corrections automatiques arrêtées.');await new Promise(r=>setTimeout(r,3000));await refreshJobs();const j=jobs.find(x=>x.id===id);if(j&&terminal(j))return j}throw Error('Délai dépassé pendant la correction automatique.')}


function renderActivity(){const visibleJobs=jobs.filter(j=>j.created>=sessionStartedS2||!terminal(j));const active=visibleJobs.filter(j=>!terminal(j));const j=active.find(j=>j.status==='running')||active[0]||visibleJobs[0];$('trackingBadge').textContent=active.length?`${active.length} tâche(s)`:'En attente';if(!j){$('activity').innerHTML='<p class="muted">L’atelier est prêt à accueillir votre première création.</p>';$('jobList').innerHTML='';return}const elapsed=j.started?(j.finished||Date.now()/1000)-j.started:null;const meter=j.sample_max&&j.status==='running'?`<div class="bar"><progress max="${j.sample_max}" value="${j.sample_value||0}" aria-label="Étapes du calcul"></progress></div>`:'';const verify=j.status==='submitting'||j.status==='uncertain'?`<div class="toolbar"><button type="button" class="secondary" data-verify="${esc(j.id)}">Vérifier la demande</button></div>`:'';$('activity').innerHTML=`<div class="stage">${esc(j.stage)}</div>${meter}<div class="metrics"><div><b>${short(elapsed)}</b><small>Temps écoulé</small></div><div><b>${j.status==='done'?'Terminé':short(j.remaining)}</b><small>${esc(j.remaining_kind||'Temps restant à mesurer')}</small></div></div>${j.error?`<div class="error">${esc(j.error)}</div>`:''}${verify}<p class="hint">${j.status==='queued'?'Le calcul commencera après les tâches déjà présentes.':j.status==='running'?'Vous pouvez continuer à utiliser l’interface ou fermer cette fenêtre. Le calcul reste dans ComfyUI.':j.status==='done'?'Votre création est disponible dans la collection.':j.status==='submitting'||j.status==='uncertain'?'La demande est conservée. Vérifie-la pour retrouver une tâche acceptée, sans la soumettre deux fois.':'Les demandes sont conservées ; aucune génération n’est relancée automatiquement.'}</p>`;$('jobList').innerHTML=visibleJobs.slice(0,5).map(j=>`<div class="job-row"><span title="${esc(j.params.prompt)}">${esc(j.params.prompt||'Création importée')}</span><b>${esc({done:'Terminée',running:'En cours',queued:'En attente',error:'À vérifier',cancelled:'Arrêtée',uncertain:'À vérifier',lost:'Introuvable',submitting:'Envoi'}[j.status]||j.status)}</b>${j.status==='done'?`<button class="text-button" data-result="${esc(j.id)}">Voir</button>`:j.status==='submitting'||j.status==='uncertain'?`<button class="text-button" data-verify="${esc(j.id)}">Vérifier</button>`:!terminal(j)?`<button class="text-button" data-cancel="${esc(j.id)}">Arrêter</button>`:''}</div>`).join('')}

function renderGallery(){const search=$('search').value.toLowerCase();const items=jobs.filter(j=>j.status==='done').flatMap(j=>(j.outputs||[]).map(o=>({j,o}))).filter(({j,o})=>(filter==='all'||o.media===filter)&&j.params.prompt?.toLowerCase().includes(search));const signature=JSON.stringify([filter,search,items]);if(signature===gallerySignature)return;gallerySignature=signature;$('galleryGrid').innerHTML=items.length?items.map(({j,o})=>{const outputIndex=o._source_index??j.outputs.indexOf(o);return `<article class="gallery-card">${o.media==='video'?`<video controls preload="metadata" playsinline src="${esc(o.url)}"></video>`:`<img loading="lazy" src="${esc(o.url)}" alt="Création générée">`}<p>${esc(j.params.prompt)}</p><small>${esc(labels[j.params.mode])} · ${j.params.width} × ${j.params.height} · ${new Date(j.created*1000).toLocaleDateString('fr-FR')}</small><div class="card-actions"><a class="secondary" href="${esc(o.url)}?download=1" download>Télécharger</a><button class="secondary" data-reuse="${esc(j.id)}">Reprendre</button><button class="text-button" data-variant="${esc(j.id)}">Nouvelle variante</button>${o.media==='video'?`<button class="secondary" data-add-job="${esc(j.id)}" data-output-index="${outputIndex}">Ajouter au montage</button>`:`<button class="secondary" data-image-job="${esc(j.id)}" data-output-index="${outputIndex}" data-image-mode="i2v">Animer</button><button class="secondary" data-image-job="${esc(j.id)}" data-output-index="${outputIndex}" data-image-mode="i2i">Retoucher</button>`}<button class="secondary danger-button" data-delete-job="${esc(j.id)}">Supprimer de la galerie</button></div></article>`}).join(''):'<div class="collection-empty"><h3>La collection commence avec vous.</h3><p>Vos créations terminées apparaîtront ici.</p><button class="secondary" data-view="create">Créer quelque chose</button></div>'}
async function reuse(id,variant=false){const j=jobs.find(j=>j.id===id);if(!j)return;const p=j.params;for(const k of ['prompt','negative','width','height','frames','steps','fps','engine','denoise'])if(p[k]!=null)$(k).value=p[k];$('artistic').checked=!!p.artistic;$('tiled').checked=p.tiled!==false;$('seed').value=variant?'-1':String(p.seed??j.seed??-1);stylePresets=Array.isArray(p.style_presets)&&p.style_presets.length?p.style_presets:[String(p.style_preset||'realistic').split('+')[0]];styleBasePrompt=$('prompt').value.split('\n\n[Style visuel]')[0].trim();updateMode(p.mode||'t2v');if(p.checkpoint)$('checkpoint').value=p.checkpoint;asset=['i2i','i2v','v2v'].includes(mode)&&p.asset_id?{id:p.asset_id,url:'/api/assets/'+p.asset_id}:null;showAsset(asset);if(asset)$('assetState').textContent='Photo de départ retrouvée dans l’historique.';syncStylePrompt();document.querySelectorAll('.preset').forEach(b=>b.classList.remove('active'));changeView('create');error('');updateSpecs();restorePreparedS23(p);saveDraft();$('prompt').focus()}
async function cancel(id){try{await api('/api/jobs/'+id+'/cancel',{});await refreshJobs()}catch(e){error(e.message);changeView('create');$('formError').scrollIntoView({block:'center'})}}
async function deleteJob(id){if(!id)return;if(!window.confirm('Retirer cette création de la galerie ? Le fichier ComfyUI sera conservé.'))return;try{await api('/api/jobs/'+encodeURIComponent(id)+'/delete',{});if(selectedResult===id){selectedResult='';resultSignature=''}await refreshJobs();if(typeof notice==='function')notice('Création retirée de la galerie.')}catch(e){error(e.message);debugEvent('gallery.delete.error',{id,error:debugText(e?.message||e)})}}
function ensureDiagnosticTools(){if($('diagnosticTools'))return;const box=document.createElement('section');box.id='diagnosticTools';box.className='panel support-panel';box.innerHTML='<div class="panel-title"><div><h2>Envoyer le log à GPT</h2><p class="hint">Le ZIP rassemble les clics, l’état après clic, les moteurs, les tâches et les erreurs.</p></div><span class="chip">Débogage local</span></div><div class="panel-body"><label for="diagnosticRemarks">Remarques pour GPT</label><textarea id="diagnosticRemarks" rows="5" maxlength="12000" placeholder="Décris le clic qui pose problème, le résultat attendu et l’heure du test…"></textarea><div class="toolbar"><button type="button" id="exportSupport" class="primary">Envoyer le log à GPT (ZIP)</button><span id="exportSupportStatus" class="hint" role="status"></span></div></div>';$('view-diagnostic').insertBefore(box,$('diagnosticCards'))}
function ensureMultiStyleControls(){const box=document.querySelector('.style-presets');if(!box||box.dataset.multiReady)return;box.dataset.multiReady='1';box.setAttribute('aria-label','Style et cadrage · plusieurs choix possibles');box.innerHTML=Object.entries(styleRules).map(([key,r])=>`<label class="style-check"><input type="checkbox" data-style-check="${esc(key)}"><span><b>${esc(r.label)}</b><small>${esc(r.short||'Option combinable')}</small></span></label>`).join('');syncStylePrompt(false)}
function renderAutopilot(s=health.autopilot||{}){const badge=$('autopilotBadge'),status=$('autopilotStatus'),report=$('autopilotReport');if(!badge||!status||!report)return;const ok=!!s.ok;const attached=!!s.playwright_attached;badge.textContent=s.last_action==='profile_menu'?(ok?'Profil ouvert':'À vérifier'):(attached?'Playwright attaché':(s.cdp?'CDP disponible':'Non disponible'));badge.className='chip '+(ok?'good':(s.cdp?'':'bad'));status.textContent=s.message||(s.cdp?`Chrome CDP actif · port ${s.port||9223} · ${s.pages?.length||0} page(s)`:`CDP local non disponible · port ${s.port||9223}`);report.classList.toggle('hidden',!s.last_action&&!s.code);report.textContent=JSON.stringify(s,null,2)}
async function autopilotAction(path,payload={}){const buttons=[$('autopilotAttach'),$('autopilotProfile'),$('autopilotDisconnect')].filter(Boolean);buttons.forEach(b=>b.disabled=true);try{const result=await api(path,payload);health.autopilot=result;renderAutopilot(result);return result}catch(e){const result={ok:false,code:'UI_ERROR',message:e.message};health.autopilot=result;renderAutopilot(result);throw e}finally{buttons.forEach(b=>b.disabled=false)}}
function renderDiagnostic(){renderAutopilot(health.autopilot||{});const device=health.devices?.[0];const family=health.profile?.label||'Moteur non identifié';const routes=Object.entries(health.workflows||{}).filter(([,v])=>v).map(([k])=>k.toUpperCase()).join(' · ')||'native';$('diagnosticCards').innerHTML=`<div class="panel diagnostic-card"><small>MOTEUR COMFYUI</small><b class="${health.comfy?'good':'bad'}">${health.comfy?'Connecté':'À lancer'}</b><p>127.0.0.1:8188 · ${health.websocket?'suivi en direct actif':'suivi périodique disponible'}</p><p>${esc((health.errors||[]).join(' '))}</p></div><div class="panel diagnostic-card"><small>MODÈLES ET MATÉRIEL</small><b>${health.ready?esc(family+' prêt'):'Vérification requise'}</b><p>${esc(device?.name||'GPU non détecté')} ${device?.vram_total?'· '+(device.vram_total/1024**3).toFixed(1)+' Go':''}</p><p>Routes détectées : ${esc(routes)}${health.missing?.length?' · Manquants : '+esc(health.missing.join(', ')):''}</p></div><div class="panel diagnostic-card"><small>OPTIMISATION OLLAMA</small><b class="${health.ollama?'good':''}">${health.ollama?'Disponible':'Facultative'}</b><p>${esc((health.models||[]).join(' · ')||'La génération fonctionne sans Ollama.')}</p></div>`}
async function loadLogs(){try{const r=await api('/api/log');$('logs').textContent=[...(r.lines||[]),'--- DEBUG CLICS / API ---',...(r.debug||[])].join('\n')||'Aucun événement pour le moment.'}catch(e){$('logs').textContent=e.message}}
document.addEventListener('submit',e=>{if(e.target.id==='form'&&!e.target.checkValidity()){e.preventDefault();const invalid=e.target.querySelector(':invalid');error('Vérifie le champ en rouge avant de lancer la génération.');invalid?.focus?.()}},true);document.addEventListener('change',e=>{const i=e.target.closest('input[data-style-check]');if(i)toggleStylePreset(i.dataset.styleCheck)});document.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;if(b.dataset.applyAnalysis)applyAnalysisCorrection();if(b.id==='exportSupport')exportSupportBundle()});setTimeout(()=>{ensureDiagnosticTools();ensureMultiStyleControls()},0);
let wsTimer;
function connect(){const ws=new WebSocket(`ws://${location.host}/ws`);ws.onmessage=e=>{try{acceptJobs(JSON.parse(e.data).jobs)}catch{}};ws.onopen=()=>refreshHealth();ws.onclose=()=>{clearTimeout(wsTimer);wsTimer=setTimeout(connect,2500)};ws.onerror=()=>ws.close()}
document.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;if(b.dataset.view)changeView(b.dataset.view);if(b.dataset.mode){if(uploading)return;if(mode==='v2v'||b.dataset.mode==='v2v'){asset=null;showAsset(null)}updateMode(b.dataset.mode);applyPreset('balanced')}if(b.dataset.preset)applyPreset(b.dataset.preset);if(b.dataset.style)toggleStylePreset(b.dataset.style);if(b.dataset.filter){filter=b.dataset.filter;document.querySelectorAll('.filter').forEach(x=>x.classList.toggle('active',x===b));renderGallery()}if(b.dataset.reuse)reuse(b.dataset.reuse);if(b.dataset.variant)reuse(b.dataset.variant,true);if(b.dataset.cancel)cancel(b.dataset.cancel);if(b.dataset.verify)verifyJob(b.dataset.verify);if(b.dataset.deleteJob)deleteJob(b.dataset.deleteJob);if(b.dataset.result){selectedResult=b.dataset.result;resultSignature='';renderResult()}if(b.dataset.analyze){selectedResult=b.dataset.analyze;resultSignature='';renderResult();const outputIndex=Number(b.dataset.outputIndex||0);$('analysisAuto').checked?runCorrections(outputIndex):analyzeResult(false,outputIndex)} });
document.addEventListener('studio-ready',()=>{let draft;try{draft=JSON.parse(localStorage.getItem('studio2-draft'))}catch{}if(draft){stylePresets=Array.isArray(draft.style_presets)&&draft.style_presets.length?draft.style_presets:[String(draft.style_preset||'realistic').split('+')[0]]}styleBasePrompt=$('prompt').value.split('\n\n[Style visuel]')[0].trim();ensureMultiStyleControls();syncStylePrompt(false)});
$('chooseFile').onclick=()=>$('file').click();$('file').onchange=()=>upload($('file').files[0]);$('removeAsset').onclick=()=>{asset=null;showAsset(null);saveDraft()};$('drop').ondragover=e=>{e.preventDefault();$('drop').classList.add('drag')};$('drop').ondragleave=()=>$('drop').classList.remove('drag');$('drop').ondrop=e=>{e.preventDefault();$('drop').classList.remove('drag');upload(e.dataTransfer.files[0])};document.addEventListener('paste',e=>{if(view!=='create'||mode==='v2v'||mode==='t2i')return;const item=[...e.clipboardData.items].find(i=>i.type.startsWith('image/'));if(item){e.preventDefault();upload(item.getAsFile())}});
$('form').onsubmit=generate;$('optimize').onclick=optimize;$('undoPrompt').onclick=()=>{$('prompt').value=originalPrompt;$('undoPrompt').classList.add('hidden');saveDraft()};$('check').onclick=refreshHealth;$('rotate').onclick=()=>{const w=$('width').value;$('width').value=$('height').value;$('height').value=w;updateSpecs();saveDraft()};$('engine').onchange=()=>{engineChanged();applyPreset('balanced')};$('checkpoint').onchange=()=>applyPreset('balanced');$('search').oninput=renderGallery;$('goLogs').onclick=()=>changeView('diagnostic');$('refreshLogs').onclick=loadLogs;
 $('suggestSettings').onclick=suggestSettings;$('autopilotAttach').onclick=()=>autopilotAction('/api/autopilot/attach',{start_if_missing:true});$('autopilotProfile').onclick=()=>autopilotAction('/api/autopilot/profile-menu',{start_if_missing:true});$('autopilotDisconnect').onclick=()=>autopilotAction('/api/autopilot/disconnect',{});$('clipDuration').onchange=()=>{$('frames').value=+$('clipDuration').value;updateSpecs();saveDraft()};$('analyzeResult').onclick=()=>analyzeResult(false);$('stopCorrections').onclick=()=>{correctionStop=true;$('analysisStatus').textContent='Arrêt demandé…'};$('analysisAuto').onchange=()=>{if($('analysisAuto').checked)buttons()};$('form').addEventListener('input',()=>{if(!applyingStyle)styleBasePrompt=$('prompt').value.split('\n\n[Style visuel]')[0].trim();updateSpecs();saveDraft()});document.addEventListener('keydown',e=>{if(e.ctrlKey&&e.key==='Enter'&&view==='create'){e.preventDefault();generate()}});
async function init(){try{const config=await api('/api/config');if(config.version!=='3.0.5')throw Error('Version Studio incompatible avec le correctif S2.');token=config.token;window.__bazorToken=token;await flushDebugEvents();await refreshHealth();if(!formRestored){saveDraft();formRestored=true;newCreationS2('t2i');mountSessionS2();mountSceneS23()}updateSpecs();connect();await refreshJobs();buttons()}catch(e){$('connectionText').textContent=e.message;debugEvent('init.error',{error:debugText(e?.message||e)});setTimeout(init,3000)}}
init().then(()=>document.dispatchEvent(new Event('studio-ready')));setInterval(()=>{if(document.hidden)return;refreshJobs();if(view==='diagnostic')loadLogs()},10000);setInterval(()=>{if(!document.hidden)refreshHealth()},30000);

// V3.0.5: keep auxiliary stills out of the video result and do not auto-correct an unstructured report.
function showAnalysis(a){const valid=a?.analysis_valid!==false&&!a?.analysis_error;const detected=Array.isArray(a.detected)?a.detected:[];const preserved=Array.isArray(a.preserved)?a.preserved:[];const tone=valid?(Number(a.score)>=80?'good':'bad'):'neutral';const score=valid&&a.score!=null?esc(a.score):'—';const label=valid?(a.needs_correction?'Correction conseillée':'Résultat jugé cohérent'):'Rapport à vérifier';const details=valid?`<b>Ce qui est détecté</b><p>${detected.length?detected.map(esc).join(' · '):'Aucun défaut visible signalé.'}</p><b>Correction proposée</b><p>${esc(a.correction||'Aucune correction nécessaire.')}</p>${preserved.length?`<small class="hint">Intentions conservées : ${preserved.map(esc).join(' · ')}</small>`:''}${a.needs_correction?'<button type="button" class="primary" data-apply-analysis="1">Appliquer la correction et régénérer</button>':''}`:`<b>Analyse reçue</b><p>${esc(a.analysis_error||'Le rapport visuel n’est pas structuré.')}</p><p class="hint">Aucune correction automatique n’a été lancée.</p>`;$('analysisReport').classList.remove('hidden');$('analysisReport').innerHTML=`<div class="analysis-score ${tone}"><b>${score}/100</b><small>${label}</small></div><div>${details}</div>`}
function renderResult(){const j=jobs.find(j=>j.id===selectedResult);if(!j){clearAnalysisS2();$('result').className='result empty';$('result').innerHTML='<div class="empty-art"><span class="frame back"></span><span class="frame front">✧</span></div><h3>Votre idée prend forme.</h3><p>Votre image ou votre vidéo apparaîtra ici.</p>';$('resultActions').classList.add('hidden');$('resultBadge').textContent='Votre prochaine idée';$('referenceMirror').classList.add('hidden');resultSignature='';return}const signature=JSON.stringify([j.id,j.status,j.outputs,j.analysis]);if(signature===resultSignature)return;resultSignature=signature;clearAnalysisS2();const o=j.outputs?.[0];if(o){const outputIndex=o._source_index??0;if(o.media==='video')$('referenceMirror').classList.add('hidden');else if(asset)$('referenceMirror').classList.remove('hidden');$('result').className='result has-media';$('result').innerHTML=o.media==='video'?`<video controls playsinline preload="metadata" src="${esc(o.url)}"></video>`:`<img src="${esc(o.url)}" alt="Création générée">`;$('resultActions').classList.remove('hidden');$('resultActions').innerHTML=`<a class="secondary" href="${esc(o.url)}?download=1" download>Télécharger</a><button class="secondary" data-reuse="${esc(j.id)}">Réutiliser les réglages</button><button class="secondary" data-analyze="${esc(j.id)}" data-output-index="${outputIndex}">Analyser</button>${o.media==='video'?`<button class="secondary" data-add-job="${esc(j.id)}" data-output-index="${outputIndex}">Ajouter au montage</button>`:`<button class="secondary" data-image-job="${esc(j.id)}" data-output-index="${outputIndex}" data-image-mode="i2v">Animer</button><button class="secondary" data-image-job="${esc(j.id)}" data-output-index="${outputIndex}" data-image-mode="i2i">Retoucher</button>`}<button class="secondary danger-button" data-delete-job="${esc(j.id)}">Supprimer de la galerie</button>${j.legacy?'':`<a class="text-button" href="/api/workflow/${esc(j.id)}" download>Workflow</a>`}`;$('resultBadge').textContent=labels[j.params.mode]||'Création';if(j.analysis)showAnalysis(j.analysis);if(j.status==='done'&&!j.analysis&&$('analysisAuto').checked&&!autoAnalyzedJobs.has(j.id)&&sessionJobsS2.has(j.id)){autoAnalyzedJobs.add(j.id);setTimeout(()=>{if(selectedResult===j.id)runCorrections(outputIndex)},0)}}else{$('result').className='result empty';$('result').innerHTML=`<div class="empty-art"><span class="frame back"></span><span class="frame front">✧</span></div><h3>${terminal(j)?'Création à vérifier':'Votre idée prend forme.'}</h3><p>${esc(j.stage)}</p>`;$('resultActions').classList.add('hidden');$('resultBadge').textContent=terminal(j)?'À vérifier':'Génération en cours'}}



// BAZOR_SESSION_S2 — active creation is never inferred from history.
function generalCheckpointS2(names){
  // Preference only, never a content-safety certification.
  const rank=name=>{const n=name.toLowerCase();if(/noob|pony|hentai|nsfw|illustrious|animagine/.test(n))return -1;const known=['sd_xl_base','sdxl_base','realvis','juggernaut','dreamshaper'];const i=known.findIndex(k=>n.includes(k));return i<0?-1:known.length-i};
  return names.map(name=>({name,rank:rank(name)})).filter(x=>x.rank>=0).sort((a,b)=>b.rank-a.rank||a.name.localeCompare(b.name))[0]?.name||null;
}
function clearSourceS2(){
  uploadSeq++;
  asset=null;
  if(previewUrl){URL.revokeObjectURL(previewUrl);previewUrl=null}
  showAsset(null);
}
function clearAnalysisS2(){
  lastAnalysis=null;
  $('analysisReport').classList.add('hidden');
  $('analysisReport').replaceChildren();
  $('analysisStatus').textContent='';
}
function newCreationS2(nextMode='t2i'){
  if(submitting||uploading||optimizing||correctionBusy){error('Attends la fin de l’opération en cours, ou arrête les corrections.');return false}
  resetPreparedS23();clearSourceS2(); selectedResult='';resultSignature='';pendingRequest=null;
  clearAnalysisS2();originalPrompt='';styleBasePrompt='';stylePresets=['realistic'];
  $('prompt').value='';$('negative').value='';$('seed').value='-1';
  $('artistic').checked=false;$('analysisAuto').checked=false;
  $('undoPrompt').classList.add('hidden');
  updateMode(nextMode);applyPreset('balanced');syncStylePrompt(false);
  renderResult();changeView('create');error('');return true;
}
function mountSessionS2(){
  if($('sessionS2'))return;
  const box=document.createElement('section');box.id='sessionS2';box.className='panel session-s2';
  box.innerHTML=`<div class="panel-body"><div class="toolbar"><button type="button" id="newCreationS2" class="primary">Nouvelle création</button><button type="button" id="discoverS2" class="secondary">Découverte</button><span class="chip">Session vierge · S2</span></div><p class="hint">Une ancienne création ne devient une référence que si vous la choisissez.</p><div id="discoverCardsS2" class="hidden"><div class="s2-cards"><button type="button" class="secondary" data-example-s2="bear">Ourson devant la télé</button><button type="button" class="secondary" data-example-s2="landscape">Paysage imaginaire</button><button type="button" class="secondary" data-example-s2="animation">Animer une photo</button></div><p class="hint">Ces exemples remplissent le formulaire. Ils ne lancent aucun calcul.</p></div></div>`;
  $('view-create').insertBefore(box,$('view-create').querySelector('.workspace'));
  $('newCreationS2').onclick=()=>newCreationS2();
  $('discoverS2').onclick=()=>$('discoverCardsS2').classList.toggle('hidden');
  const workflowButton=document.createElement('button');workflowButton.type='button';workflowButton.className='secondary';workflowButton.id='workflowS2';workflowButton.textContent='Voir le workflow sélectionné';box.querySelector('.toolbar').append(workflowButton);
  workflowButton.onclick=showWorkflowS2;
  box.addEventListener('click',e=>{
    const kind=e.target.closest('[data-example-s2]')?.dataset.exampleS2;if(!kind)return;
    if(!newCreationS2(kind==='animation'?'i2v':'t2i'))return;
    const examples={bear:'Un ourson brun assis sur un canapé regarde une télévision allumée. Une couverture enveloppe son corps. Il tient un verre de cola et boit avec une paille bien visible. Le verre, la paille, la couverture et la télévision sont tous visibles dans le cadre.',landscape:'Un village au bord d’un lac, des petites maisons en pierre, une forêt et des montagnes au loin. Lumière du matin, composition calme.',animation:'La caméra avance lentement vers le sujet. Préserver son identité, ses vêtements et le décor de la photo.'};
    $('prompt').value=examples[kind];styleBasePrompt=examples[kind];syncStylePrompt(false);updateSpecs();
  });
}

async function showWorkflowS2(){
  const selected=jobs.find(j=>j.id===selectedResult);
  if(!selected){error('Choisissez une création pour afficher le workflow réellement envoyé à ComfyUI.');return}
  try{
    const graph=await api('/api/workflow/'+encodeURIComponent(selected.id));
    const nodes=Object.entries(graph).filter(([,n])=>n&&typeof n.class_type==='string');
    if(!nodes.length)throw Error('Ce workflow ne contient aucun nœud affichable.');
    $('workflowDialogS2')?.remove();
    const dialog=document.createElement('dialog');dialog.id='workflowDialogS2';dialog.className='workflow-dialog-s2';
    const title=document.createElement('h2');title.textContent='Workflow de la création sélectionnée';dialog.append(title);
    const subtitle=document.createElement('p');subtitle.className='hint';subtitle.textContent=`${selected.params.mode.toUpperCase()} · ${nodes.length} nœuds · ${selected.id}`;dialog.append(subtitle);
    const close=document.createElement('button');close.className='secondary';close.textContent='Fermer';close.onclick=()=>dialog.close();dialog.append(close);
    const scroll=document.createElement('div');scroll.className='workflow-scroll-s2';
    const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');
    const ids=new Set(nodes.map(([id])=>id)),levels=new Map(),visiting=new Set();
    const parents=n=>Object.entries(n.inputs||{}).filter(([,v])=>Array.isArray(v)&&v.length===2&&ids.has(String(v[0]))&&Number.isInteger(v[1]));
    function level(id){if(levels.has(id))return levels.get(id);if(visiting.has(id))return 0;visiting.add(id);const n=graph[id];const v=Math.min(nodes.length,Math.max(0,...parents(n).map(([,p])=>1+level(String(p[0])))));visiting.delete(id);levels.set(id,v);return v}
    nodes.forEach(([id])=>level(id));
    const counts=new Map(),pos=new Map();let width=700,height=0;
    for(const [id] of nodes){const l=levels.get(id);const col=counts.get(l)||0;counts.set(l,col+1);const x=30+col*300,y=30+l*110;pos.set(id,{x,y});width=Math.max(width,x+290);height=Math.max(height,y+100)}
    svg.setAttribute('viewBox',`0 0 ${width} ${height}`);svg.setAttribute('width',String(width));svg.setAttribute('height',String(height));svg.setAttribute('role','img');svg.setAttribute('aria-label','Nœuds et connexions du workflow exécuté');
    function el(tag,attrs={},text){const n=document.createElementNS(svg.namespaceURI,tag);for(const [k,v]of Object.entries(attrs))n.setAttribute(k,String(v));if(text!=null)n.textContent=text;return n}
    for(const [id,n]of nodes){for(const [input,p]of parents(n)){const a=pos.get(String(p[0])),b=pos.get(id);svg.append(el('path',{d:`M ${a.x+130} ${a.y+65} C ${a.x+130} ${a.y+95}, ${b.x+130} ${b.y-25}, ${b.x+130} ${b.y}`,class:'workflow-edge-s2'}));svg.append(el('text',{x:b.x+134,y:b.y-6,class:'workflow-port-s2'},input))}}
    for(const[id,n]of nodes){const{x,y}=pos.get(id),g=el('g');g.append(el('rect',{x,y,width:260,height:65,rx:12,class:'workflow-node-s2'}));g.append(el('text',{x:x+12,y:y+24,class:'workflow-label-s2'},n.class_type.length>30?n.class_type.slice(0,29)+'…':n.class_type));g.append(el('text',{x:x+12,y:y+48,class:'workflow-port-s2'},'Nœud '+id));g.append(el('title',{},JSON.stringify(n.inputs,null,2)));svg.append(g)}
    scroll.append(svg);dialog.append(scroll);
    const download=document.createElement('a');download.className='secondary';download.href='/api/workflow/'+encodeURIComponent(selected.id);download.download='workflow_api.json';download.textContent='Télécharger le workflow API';dialog.append(download);
    const note=document.createElement('p');note.className='hint';note.textContent='Vue des connexions réellement enregistrées. Pour modifier le graphe, ouvrez ComfyUI. Les modèles restent chargés par la seule branche exécutée.';dialog.append(note);
    document.body.append(dialog);dialog.showModal();
  }catch(e){error('Workflow indisponible : '+e.message)}
}

async function analyzeResult(auto=false,index=null,expectedId=null){
  const j=selectedDone();
  if(!j||expectedId&&j.id!==expectedId){$('analysisStatus').textContent='Choisissez le rendu terminé à analyser.';return null}
  const outputIndex=index==null?(j.outputs[0]._source_index??0):Number(index);
  if(!Number.isInteger(outputIndex)||outputIndex<0)return null;
  try{
    $('analysisStatus').textContent='Analyse du rendu sélectionné…';
    const a=await api('/api/jobs/'+j.id+'/analyze',{model:$('ollamaModel').value,index:outputIndex});
    if(selectedResult!==j.id||a.job_id!==j.id||a.output_index!==outputIndex)return null;
    lastAnalysis=a;showAnalysis(a);
    $('analysisStatus').textContent=a.analysis_valid===false?'Rapport non exploitable · aucune correction lancée':`Analyse terminée · ${a.model||'vision locale'}`;
    return a;
  }catch(e){if(selectedResult===j.id)$('analysisStatus').textContent='Analyse impossible : '+e.message;return null}
}
async function runCorrections(outputIndex=null){
  if(correctionBusy)return;
  const initial=selectedDone();if(!initial)return;
  correctionBusy=true;correctionStop=false;correctionAttempts=0;buttons();
  const base={...initial.params};let current=initial;
  try{
    let a=await analyzeResult(false,outputIndex,current.id);
    const limit=Math.min(10,Math.max(1,+$('analysisLimit').value||3));
    while(a?.analysis_valid===true&&a.needs_correction&&correctionAttempts<limit&&!correctionStop){
      if(selectedResult!==current.id||a.job_id!==current.id)break;
      const fix=String(a.correction||'').trim();if(!fix)break;
      correctionAttempts++;
      const p={...base,prompt:base.prompt+'\n\n[Correction visuelle BAZOR] '+fix,seed:'-1'};
      const next=await api('/api/jobs',p,{headers:{'Idempotency-Key':crypto.randomUUID()}});
      selectedResult=next.id;resultSignature='';autoAnalyzedJobs.add(next.id);clearAnalysisS2();
      await refreshJobs();current=await waitForJob(next.id);
      if(current.status!=='done'||correctionStop)break;
      a=await analyzeResult(true,null,current.id);
    }
    $('analysisStatus').textContent=correctionStop?'Corrections arrêtées.':a?.analysis_valid!==true?'Analyse indisponible · aucune validation du rendu.':a.needs_correction?`Corrections terminées (${correctionAttempts}/${limit}) · résultat encore à vérifier.`:`Rendu jugé cohérent par le modèle · ${correctionAttempts} correction(s).`;
  }catch(e){$('analysisStatus').textContent=e.message}
  finally{correctionBusy=false;buttons()}
}
async function applyAnalysisCorrection(){
  const j=selectedDone();
  const a=lastAnalysis?.job_id===j?.id?lastAnalysis:j?.analysis;
  if(!j||!a||a.job_id!==j.id||a.analysis_valid!==true||!a.correction||correctionBusy)return;
  correctionBusy=true;buttons();
  try{
    const next=await api('/api/jobs',{...j.params,prompt:j.params.prompt+'\n\n[Correction visuelle BAZOR] '+a.correction,seed:'-1'},{headers:{'Idempotency-Key':crypto.randomUUID()}});
    selectedResult=next.id;resultSignature='';clearAnalysisS2();await refreshJobs();
  }catch(e){$('analysisStatus').textContent=e.message}
  finally{correctionBusy=false;buttons()}
}

document.addEventListener('click',e=>{if(correctionBusy&&e.target.closest('[data-result],[data-analyze],[data-reuse],[data-variant],[data-image-job],[data-mode]')){e.preventDefault();e.stopImmediatePropagation();$('analysisStatus').textContent='Arrête les corrections avant de changer de création.'}},true);

// BAZOR_SCENE_S23: recipe belongs to the job, never to the mutable form.
let preparedS23=null;
function resetPreparedS23(){preparedS23=null;if($('preparedPromptS23'))$('preparedPromptS23').value='';if($('autoStyleS23'))$('autoStyleS23').checked=false}
function restorePreparedS23(p){resetPreparedS23();if(p.prepared_prompt){preparedS23={source:$('prompt').value.trim(),mode};$('preparedPromptS23').value=p.prepared_prompt;$('preparedPanelS23').open=true}$('autoStyleS23').checked=p.auto_style===true}
function preparedPayloadS23(){const same=preparedS23&&preparedS23.source===$('prompt').value.trim()&&preparedS23.mode===mode;return {prepared_prompt:same?($('preparedPromptS23')?.value||''):'',prepared_source:same?preparedS23.source:'',prepared_mode:same?mode:'',auto_style:$('autoStyleS23')?.checked===true}}
function mountSceneS23(){
 if($('preparedPanelS23'))return;
 const p=document.createElement('details');p.id='preparedPanelS23';p.className='advanced';
 p.innerHTML='<summary>Prompt envoyé et réglages par mots-clés</summary><p class="hint">Préparer avec Ollama conserve votre demande et propose une version anglaise modifiable. Si la demande ou le mode change, préparez-la de nouveau.</p><label for="preparedPromptS23">Version préparée pour le modèle</label><textarea id="preparedPromptS23" rows="5" placeholder="Cliquez sur Préparer pour le modèle"></textarea><label><input type="checkbox" id="autoStyleS23"> Déduire le cadrage et le style : corps entier, debout, portrait, noir et blanc, cinématique</label><p class="hint">Le mode Image/Vidéo et la référence restent ceux que vous choisissez. Aucun mot-clé ne déclenche un service en ligne.</p>';
 $('optimizeState').after(p);$('optimize').textContent='✧ Préparer pour le modèle';
 const b=document.createElement('button');b.type='button';b.className='secondary';b.id='recipeS23';b.textContent='Prompt et paramètres du résultat';b.onclick=showRecipeS23;$('sessionS2').querySelector('.toolbar').append(b);
}
async function optimize(){
 if(optimizing||submitting||correctionBusy)return;
 const request=payload(),source=$('prompt').value.trim(),selectedMode=mode;
 optimizing=true;buttons();$('optimizeState').textContent='Préparation locale : personnages, actions et objets doivent rester dans la description…';
 try{const r=await api('/api/optimize',request);if($('prompt').value.trim()!==source||mode!==selectedMode){$('optimizeState').textContent='Demande modifiée pendant la préparation : proposition écartée.';return}preparedS23={source,mode:selectedMode};$('preparedPromptS23').value=r.prompt;$('preparedPanelS23').open=true;$('optimizeState').textContent='Version préparée utilisée au prochain envoi. Vérifiez que chaque personnage et objet y figure. Votre demande initiale est conservée.'}catch(e){$('optimizeState').textContent=e.message}finally{optimizing=false;buttons()}
}
async function showRecipeS23(){
 const selected=jobs.find(j=>j.id===selectedResult);if(!selected){error('Choisissez un résultat pour consulter sa fiche.');return}
 try{
  const r=await api('/api/recipe/'+encodeURIComponent(selected.id));
  $('recipeDialogS23')?.remove();const d=document.createElement('dialog');d.id='recipeDialogS23';d.className='workflow-dialog-s2';
  const h=document.createElement('h2');h.textContent='Prompt et paramètres de cette création';d.append(h);
  const note=document.createElement('p');note.textContent=selected.id+' · '+String(r.mode).toUpperCase()+' · graine '+r.seed;d.append(note);
  for(const [label,value] of [['Votre demande',r.request],['Textes réellement envoyés',r.effective_texts?.map(x=>x.node+' · '+x.input+'\n'+x.text).join('\n\n')],['Modèles, réglages et route',JSON.stringify({models:r.models,settings:r.settings,route:r.route,graph_sha256:r.graph_sha256},null,2)]]){const title=document.createElement('h3');title.textContent=label;const pre=document.createElement('pre');pre.style.cssText='white-space:pre-wrap;overflow-wrap:anywhere;font-size:13px';pre.textContent=value||'Non enregistré';d.append(title,pre)}
  const a=document.createElement('a');a.href='/api/recipe/'+encodeURIComponent(selected.id);a.download='creation-'+selected.id+'.json';a.className='secondary';a.textContent='Télécharger cette fiche';const b=document.createElement('button');b.className='secondary';b.textContent='Fermer';b.onclick=()=>d.close();d.append(a,b);document.body.append(d);d.showModal();
 }catch(e){error(e.message)}
}
