"""BAZOR AI Studio V3 — local async UI; never starts or stops ComfyUI."""
from __future__ import annotations
import asyncio, base64, contextlib, io, json, logging, logging.handlers, os, re, secrets, sqlite3, statistics, sys, tempfile, time, uuid, zipfile
from pathlib import Path
from urllib.parse import urlencode, urlparse, parse_qs
import aiohttp
from aiohttp import web
from PIL import Image, ImageOps
# Embedded Python may omit the script directory from sys.path. Add only this app directory.
APP_CODE_DIR = str(Path(__file__).resolve().parent)
if APP_CODE_DIR not in sys.path:
    sys.path.insert(0, APP_CODE_DIR)
from workflows import parameters, build, choices, select_models, detect_profile, patch_h3_graph
from workshop import Workshop
from model_setup import ModelSetup
from prompt_library import PromptLibrary, merge_negative
from runtime_identity import identity
from browser_autopilot import BrowserAutopilot

# BAZOR_SESSION_S2
from studio_session_guard import normalize_analysis_image, select_vision_model, read_media_limited, engine_error_summary
from studio_h3_inventory import resolve_h3_inventory
VERSION='3.0.5'
APP_ID='ai-simple-studio-v2'
TERMINAL={'done','error','cancelled','lost'}
Image.MAX_IMAGE_PIXELS=25_000_000
IMAGE_EXTENSIONS=frozenset(('.png','.jpg','.jpeg','.webp','.gif'))
VIDEO_EXTENSIONS=frozenset(('.mp4','.webm','.mkv','.mov'))
MEDIA_EXTENSIONS=IMAGE_EXTENSIONS|VIDEO_EXTENSIONS
VIDEO_MODES=frozenset(('t2v','i2v','v2v'))
IMAGE_MODES=frozenset(('t2i','i2i'))


def _analysis_bool(value):
    if isinstance(value,bool):return value
    if isinstance(value,str):return value.strip().lower() in ('1','true','yes','y','oui','vrai')
    return bool(value)


def _analysis_list(value):
    if isinstance(value,list):return [str(x).strip() for x in value if str(x).strip()]
    if isinstance(value,str) and value.strip():return [value.strip()]
    return []


def parse_visual_report(answer):
    """Accept strict JSON plus the fenced/object-wrapped variants vision models emit."""
    text=str(answer or '').strip()
    clean=text
    if clean.startswith('```'):
        clean=clean[3:]
        if clean.lower().startswith('json'):clean=clean[4:]
        clean=clean.strip()
    if clean.endswith('```'):clean=clean[:-3].strip()
    candidates=[clean]
    start,end=clean.find('{'),clean.rfind('}')
    if start>=0 and end>start and clean[start:end+1] not in candidates:candidates.append(clean[start:end+1])
    for candidate in candidates:
        try:payload=json.loads(candidate)
        except (TypeError,ValueError):continue
        if not isinstance(payload,dict):continue
        if isinstance(payload.get('report'),dict):payload=payload['report']
        try:score=max(0,min(100,int(round(float(payload.get('score'))))))
        except (TypeError,ValueError,OverflowError):score=None
        return {**payload,'score':score,'needs_correction':_analysis_bool(payload.get('needs_correction',False)),
                'detected':_analysis_list(payload.get('detected')),
                'correction':str(payload.get('correction') or '').strip(),
                'preserved':_analysis_list(payload.get('preserved')),
                'analysis_valid':True}
    return {'score':None,'needs_correction':False,'detected':[],'correction':'','preserved':[],
            'analysis_valid':False,'analysis_error':'Ollama a répondu, mais le rapport n’est pas un JSON exploitable.',
            'analysis_raw':clean[:2000]}


def local_url(value):
    u=urlparse(value)
    if u.scheme!='http' or u.hostname not in ('127.0.0.1','localhost') or u.username or u.password or u.path not in ('','/'):
        raise ValueError('Les moteurs doivent utiliser une adresse HTTP locale 127.0.0.1.')
    return value.rstrip('/')


class EngineError(Exception):
    def __init__(self, message, status=502):
        super().__init__(message); self.status=status


class Store:
    def __init__(self, root):
        self.root=Path(root); self.root.mkdir(parents=True,exist_ok=True)
        self.db=sqlite3.connect(self.root/'studio.sqlite3')
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('CREATE TABLE IF NOT EXISTS records (kind TEXT, id TEXT, value TEXT, PRIMARY KEY(kind,id))')
        self.db.commit()
    def put(self,kind,key,value):
        self.db.execute('INSERT OR REPLACE INTO records VALUES (?,?,?)',(kind,key,json.dumps(value,ensure_ascii=False)))
        self.db.commit()
    def get(self,kind,key,default=None):
        r=self.db.execute('SELECT value FROM records WHERE kind=? AND id=?',(kind,key)).fetchone()
        return json.loads(r[0]) if r else default
    def all(self,kind):
        return [json.loads(r[0]) for r in self.db.execute('SELECT value FROM records WHERE kind=?',(kind,))]
    def delete(self,kind,key):
        self.db.execute('DELETE FROM records WHERE kind=? AND id=?',(kind,key)); self.db.commit()


class Studio:
    def __init__(self, data, comfy, ollama, legacy=None):
        self.runtime_identity=identity(VERSION)
        self.store=Store(data); self.data=Path(data); self.assets=self.data/'assets'; self.assets.mkdir(exist_ok=True)
        self.logs_dir=self.data.parent/'logs'; self.logs_dir.mkdir(parents=True,exist_ok=True)
        self.debug_path=self.logs_dir/'studio-debug.jsonl'
        self.comfy=local_url(comfy); self.ollama=local_url(ollama)
        self.token=secrets.token_urlsafe(32)
        self.client_id=self.store.get('meta','client_id') or 'studio2-'+uuid.uuid4().hex
        self.store.put('meta','client_id',self.client_id)
        self.legacy=Path(legacy) if legacy else None
        self.submit_lock=asyncio.Lock(); self.gpu_lock=asyncio.Lock()
        self.session=None; self.tasks=[]; self.clients=set(); self.ws_connected=False
        self.info={}; self.info_at=0; self.health_state={}; self.optimizing=False
        self.log_lines=[]; self.connection_error=None
        self.workshop=Workshop(self); self.model_setup=ModelSetup(self); self.prompt_library=PromptLibrary(self)
        self.autopilot=BrowserAutopilot(self.log,self.debug,self.logs_dir)
    def h3_workflow_candidates(self, mode):
        """Find a locally saved H3 template without touching ComfyUI files."""
        root=Path(os.environ.get('AI_ROOT',r'C:\AI'))/'ComfyUI'
        dirs=[root/'ComfyUI_windows_portable'/'ComfyUI'/'user'/'default'/'workflows',
              root/'workflows', root]
        candidates=[]; seen=set()
        for folder in dirs:
            if not folder.is_dir():continue
            try: items=folder.rglob('*.json')
            except OSError:continue
            for path in items:
                try:
                    if path in seen or path.stat().st_size>12*1024*1024:continue
                    name=path.name.lower()
                except OSError:continue
                if 'h3' not in name and 'minimax' not in name:continue
                score=0
                if mode=='i2v':
                    if 'i2v' in name:score+=100
                    if 'fl2v' in name:score+=90
                    if 'r2v' in name or 'reference' in name:score+=70
                elif mode=='t2v':
                    if 't2v' in name:score+=100
                    if 'i2v' in name or 'fl2v' in name or 'r2v' in name:score-=100
                elif mode=='v2v':
                    if 'v2v' in name:score+=100
                    if 'r2v' in name or 'reference' in name:score+=70
                if score>0:
                    seen.add(path);candidates.append((score,path))
        return [p for _,p in sorted(candidates,key=lambda x:(-x[0],str(x[1]).lower()))]
    async def graph_for(self,p,info,image_name,prefix):
        profile=detect_profile(info)
        if profile['family']!='h3' or p['mode'] not in ('t2v','i2v','v2v'):
            return build(p,info,image_name,prefix),profile
        templates=self.h3_workflow_candidates(p['mode'])
        if not templates:
            raise ValueError('MiniMax H3 détecté, mais aucun workflow vidéo compatible n’est installé. Enregistre le workflow H3 dans ComfyUI/user/default/workflows puis actualise le Studio.')
        path=templates[0]
        try:
            raw=json.loads(path.read_text(encoding='utf-8-sig'))
        except Exception as e:
            raise ValueError('Workflow MiniMax H3 illisible : '+path.name) from e
        if isinstance(raw,dict) and isinstance(raw.get('nodes'),list):
            raw=await self.request('POST','/workflow/convert',raw,timeout=60)
        result=patch_h3_graph(raw,p,image_name,prefix,info=info)
        self.log('Route MiniMax H3 : '+p['mode']+' · '+path.name+' · chargeurs='+','.join(result['loaders']))
        resolved,changes=resolve_h3_inventory(result['graph'],info)
        if changes:self.debug('h3.inventory_resolved',changes=changes)
        return resolved,profile
    def log(self,message):
        logging.info(message)
        line=time.strftime('%H:%M:%S')+'  '+message
        self.log_lines.append(line); self.log_lines=self.log_lines[-250:]
        self.debug('studio.log',message=str(message))
    @staticmethod
    def _debug_value(value,limit=2400,depth=0):
        if depth>4:return '[profondeur limitée]'
        if isinstance(value,dict):return {str(k)[:80]:Studio._debug_value(v,limit,depth+1) for k,v in list(value.items())[:80]}
        if isinstance(value,(list,tuple)):return [Studio._debug_value(v,limit,depth+1) for v in list(value)[:80]]
        if isinstance(value,(str,int,float,bool)) or value is None:return str(value)[:limit] if isinstance(value,str) else value
        return str(value)[:limit]
    def debug(self,event,**values):
        """Persist bounded local diagnostics, including browser click events."""
        row={'time':time.strftime('%Y-%m-%dT%H:%M:%S%z'),'ts':round(time.time(),3),'event':str(event)[:120]}
        row.update({str(k)[:80]:self._debug_value(v) for k,v in values.items()})
        try:
            if self.debug_path.exists() and self.debug_path.stat().st_size>8*1024*1024:
                rotated=self.debug_path.with_name('studio-debug.1.jsonl')
                rotated.unlink(missing_ok=True)
                self.debug_path.replace(rotated)
            with self.debug_path.open('a',encoding='utf-8') as stream:
                stream.write(json.dumps(row,ensure_ascii=False,separators=(',',':'))+'\n')
        except OSError:
            pass
    def record_client_events(self,events):
        if not isinstance(events,list):raise ValueError('Le journal navigateur doit être une liste.')
        accepted=0
        for item in events[-100:]:
            if not isinstance(item,dict):continue
            name=re.sub('[^a-zA-Z0-9_.-]','_',str(item.get('event') or item.get('type') or 'event'))[:80]
            values={k:v for k,v in item.items() if k not in ('event','type')}
            self.debug('client.'+name,**values);accepted+=1
        return {'ok':True,'accepted':accepted}
    def debug_tail(self,limit=180):
        try:return self.debug_path.read_text(encoding='utf-8')[-300000:].splitlines()[-limit:]
        except OSError:return []
    def jobs(self): return sorted(self.store.all('job'),key=lambda j:j['created'],reverse=True)
    def save(self,j): self.store.put('job',j['id'],j)
    def delete_job(self,key):
        j=self.store.get('job',key)
        if not j: raise ValueError('Création introuvable.')
        if j.get('status') not in TERMINAL: raise ValueError('Une création en cours ne peut pas être retirée.')
        self.store.delete('job',key); self.store.delete('workflow',key); self.store.delete('perf',key)
        self.log('Création retirée de la galerie : '+key)
        return {'ok':True,'id':key}
    async def request(self,method,path,payload=None,base=None,timeout=12):
        started=time.perf_counter(); target='ollama' if (base or self.comfy)==self.ollama else 'comfy'
        self.debug('engine.request',method=method,path=path,target=target,timeout=timeout,
                   payload_keys=list(payload) if isinstance(payload,dict) else [])
        try:
            async with self.session.request(method,(base or self.comfy)+path,json=payload,
                    timeout=aiohttp.ClientTimeout(total=timeout),allow_redirects=False) as r:
                raw=await r.text()
                try: body=json.loads(raw) if raw else {}
                except ValueError: raise EngineError(f'Réponse non JSON du moteur (HTTP {r.status}).')
                self.debug('engine.response',method=method,path=path,target=target,status=r.status,
                           duration_ms=round((time.perf_counter()-started)*1000),
                           response_keys=list(body) if isinstance(body,dict) else [])
                if r.status>=300:
                    self.debug('engine.rejection_detail',path=path,target=target,body=body)
                    raise EngineError(engine_error_summary(body),r.status)
                return body
        except Exception as e:
            self.debug('engine.error',method=method,path=path,target=target,
                       duration_ms=round((time.perf_counter()-started)*1000),error=str(e)[:3500])
            raise
    async def object_info(self,force=False):
        if force or not self.info or time.time()-self.info_at>60:
            self.info=await self.request('GET','/object_info',timeout=30); self.info_at=time.time()
        return self.info
    def estimate(self,p):
        def units(x): return x['width']*x['height']*((x['frames']-1)//4+1)*x['steps']
        samples=[]
        for r in self.store.all('perf'):
            q=r.get('params',{})
            if q.get('engine','wan')!=p['engine'] or q.get('mode')!=p['mode'] or bool(q.get('tiled',True))!=p['tiled']: continue
            try:
                ratio=units(p)/units(q)
                if .4<=ratio<=2.5: samples.append(float(r['seconds'])*ratio)
            except (KeyError,ValueError,ZeroDivisionError): pass
        samples=samples[-30:]
        if not samples: return {'seconds':None,'low':None,'high':None,'confidence':'À calibrer','samples':0}
        median=statistics.median(samples); spread=.45 if len(samples)<4 else .3
        return {'seconds':round(median),'low':round(min(samples)*(1-spread)),
                'high':round(max(samples)*(1+spread)), 'confidence':'Faible' if len(samples)<4 else 'Moyenne', 'samples':len(samples)}
    def checkpoint_inventory(self,info=None):
        """Merge ComfyUI's registry with valid files visible on disk.

        ComfyUI can keep its checkpoint list cached until a restart.  The
        Studio must still show the real local state after an install/scan and
        can pass a valid file name to the standard loader without pretending
        that Wan is an image checkpoint.
        """
        try:details=self.model_setup.details()
        except Exception as e:
            self.debug('checkpoint.scan_error',error=str(e)[:1200]);details={}
        disk=list(details.get('models',[])) if isinstance(details,dict) else []
        registered=choices(info or {},'CheckpointLoaderSimple','ckpt_name') if info else []
        names=[];seen=set()
        for name in registered+[x.get('name') for x in disk if isinstance(x,dict)]:
            name=str(name or '')
            if name and name not in seen:seen.add(name);names.append(name)
        return names,registered,disk
    def extend_checkpoint_choices(self,info,disk):
        node=info.setdefault('CheckpointLoaderSimple',{})
        inputs=node.setdefault('input',{}).setdefault('required',{})
        spec=inputs.setdefault('ckpt_name',[[]])
        if not isinstance(spec,list) or not spec:spec=[[]];inputs['ckpt_name']=spec
        if not isinstance(spec[0],list):spec[0]=[]
        known=[str(x) for x in spec[0]]
        for model in disk:
            name=str(model.get('name','')) if isinstance(model,dict) else ''
            if name and name not in known:known.append(name)
        spec[0]=known
    async def health(self):
        async def safe(base,path):
            try:return await self.request('GET',path,base=base,timeout=5)
            except Exception:return None
        stats,tags,queue=await asyncio.gather(safe(self.comfy,'/system_stats'),safe(self.ollama,'/api/tags'),safe(self.comfy,'/queue'))
        missing=[]; checkpoints=[]; registered_checkpoints=[]; checkpoint_details=[]; errors=[]; ready=False
        disk_models=[]
        try:
            disk_models=await asyncio.to_thread(self.model_setup.details)
            checkpoint_details=list(disk_models.get('models',[]))
            checkpoints=[str(x.get('name')) for x in checkpoint_details if isinstance(x,dict) and x.get('name')]
        except Exception as e:
            self.debug('checkpoint.scan_error',error=str(e)[:1200])
        profile={'family':'unknown','label':'Inconnu','nodes':[]}; workflows={}
        if stats:
            try:
                info=await self.object_info()
                _,_,disk_models=self.checkpoint_inventory(info)
                self.extend_checkpoint_choices(info,disk_models)
                profile=detect_profile(info)
                _,missing=select_models(info) if profile['family']!='h3' else ([],[])
                checkpoints,registered_checkpoints,disk= self.checkpoint_inventory(info)
                checkpoint_details=list(disk)
                self.extend_checkpoint_choices(info,checkpoint_details)
                if profile['family']=='h3':
                    workflows={m:bool(self.h3_workflow_candidates(m)) for m in ('t2v','i2v','v2v')}
                    ready=workflows['i2v']
                    if not ready:errors.append('MiniMax H3 est détecté, mais son workflow I2V/FL2V est introuvable dans ComfyUI/user/default/workflows.')
                else:
                    demo=parameters({'prompt':'diagnostic'})
                    build(demo,info);ready=True
            except Exception as e: errors.append(str(e))
        else: errors.append('ComfyUI ne répond pas sur 127.0.0.1:8188. Lance son raccourci NVIDIA puis clique sur Vérifier.')
        h={'app':APP_ID,'version':VERSION,'comfy':bool(stats),'ready':ready,'ollama':tags is not None,
           'models': [x['name'] for x in (tags or {}).get('models',[]) if x.get('name')],
           'checkpoints':checkpoints,'registered_checkpoints':registered_checkpoints,
           'checkpoint_details':checkpoint_details,
           'image_checkpoint_present':bool(checkpoint_details or checkpoints),
           'sdxl_present':any(x.get('family')=='sdxl' for x in checkpoint_details if isinstance(x,dict)),
           'missing':missing,'errors':errors,'devices':(stats or {}).get('devices',[]),
           'profile':profile,'workflows':workflows,
           'queue':{'running':len((queue or {}).get('queue_running',[])),'pending':len((queue or {}).get('queue_pending',[]))},
           'websocket':self.ws_connected,'optimizing':self.optimizing,'attach':True,
           'autopilot':await self.autopilot.status()}
        self.health_state=h
        return h
    async def upload(self,request):
        return await self.image_bytes(await request.read())
    async def image_bytes(self,raw):
        if len(raw)>20*1024*1024: raise ValueError('Image trop lourde : 20 Mo maximum.')
        def normalize():
            try:
                with Image.open(io.BytesIO(raw)) as im:
                    im=ImageOps.exif_transpose(im); im.thumbnail((2048,2048)); im=im.convert('RGB')
                    out=io.BytesIO(); im.save(out,'PNG'); return out.getvalue(),im.size
            except Exception: raise ValueError('Image illisible. Utilise une image PNG, JPG ou WebP de moins de 25 millions de pixels.')
        png,size=await asyncio.to_thread(normalize)
        key=uuid.uuid4().hex; path=self.assets/(key+'.png')
        await asyncio.to_thread(path.write_bytes,png)
        asset={'id':key,'width':size[0],'height':size[1],'created':time.time(),'url':'/api/assets/'+key}
        self.store.put('asset',key,asset); self.log('Image importée et vérifiée : '+str(size[0])+' × '+str(size[1]))
        return asset
    async def to_comfy(self,key):
        if not re.fullmatch('[a-f0-9]{32}',str(key)) or not self.store.get('asset',key): raise ValueError('Image introuvable. Réimporte la photo.')
        path=self.assets/(key+'.png')
        form=aiohttp.FormData()
        with path.open('rb') as f:
            form.add_field('image',f,filename='studio2_'+key+'.png',content_type='image/png')
            form.add_field('type','input'); form.add_field('overwrite','false')
            async with self.session.post(self.comfy+'/upload/image',data=form,timeout=aiohttp.ClientTimeout(total=60),allow_redirects=False) as r:
                if r.status!=200: raise EngineError('ComfyUI a refusé l’image : '+(await r.text())[:1000])
                v=await r.json()
        name=v.get('name'); sub=v.get('subfolder','')
        if not name: raise EngineError('ComfyUI n’a pas confirmé le nom de l’image.')
        return '/'.join(x for x in (sub,name) if x)
    async def submit(self,raw,request_id):
        if not re.fullmatch('[a-zA-Z0-9_-]{12,80}',request_id): raise ValueError('Identifiant de requête manquant.')
        async with self.submit_lock:
            previous=self.store.get('job',request_id)
            if previous:return previous
            unresolved=[j for j in self.jobs() if j['status'] in ('submitting','uncertain')]
            if unresolved: raise ValueError('Une demande attend encore sa confirmation. Consulte son état avant d’en envoyer une autre.')
            if self.gpu_lock.locked(): raise ValueError('L’optimisation du prompt est en cours. Attends sa fin.')
            async with self.gpu_lock:
                raw={**raw,'negative':merge_negative(self.prompt_library.preferences()['negative'],raw.get('negative',''))}
                p=parameters(raw)
                self.debug('generation.parameters',request_id=request_id,params=p)
                info=await self.object_info()
                _,_,disk_models=self.checkpoint_inventory(info)
                self.extend_checkpoint_choices(info,disk_models)
                profile=detect_profile(info)
                if profile['family']=='h3' and p['engine']=='wan':
                    p['engine']='h3'
                image_name=await self.to_comfy(p['asset_id']) if p['asset_id'] else None
                queue=await self.request('GET','/queue')
                if len(queue.get('queue_pending',[]))>=2:
                    raise ValueError('La file locale contient déjà deux tâches en attente. Attends ou arrête une tâche avant d’en ajouter une autre.')
                graph,_=await self.graph_for(p,info,image_name,prefix='AI_Simple_Studio_2/'+request_id)
                self.debug('generation.graph_ready',request_id=request_id,profile=profile,
                           graph_nodes={k:v.get('class_type') for k,v in graph.items() if isinstance(v,dict)})
                j={'id':request_id,'params':p,'prompt_id':None,'created':time.time(),'started':None,
                   'status':'submitting','stage':'Envoi au moteur','outputs':[],'estimate':self.estimate(p),'client_id':self.client_id}
                self.save(j); self.prompt_library.remember_job(j) # Persist BEFORE submitting; never replay an ambiguous POST.
                self.store.put('workflow',j['id'],graph)
                try:
                    r=await self.request('POST','/prompt',{'prompt':graph,'client_id':self.client_id,
                           'extra_data':{'studio_job_id':j['id']}},timeout=45)
                    if not r.get('prompt_id'): raise EngineError('Le moteur n’a pas renvoyé de numéro de tâche.')
                    j.update(prompt_id=r['prompt_id'],status='queued',stage='Dans la file d’attente')
                    self.log('Demande acceptée par ComfyUI : '+j['id'])
                except EngineError as e:
                    if 400<=e.status<500:
                        j.update(status='error',stage='Demande refusée',error=str(e))
                    else:j.update(status='uncertain',stage='Confirmation à retrouver',error=str(e))
                except Exception as e:
                    j.update(status='uncertain',stage='Connexion interrompue : vérification de la demande',error=str(e))
                self.save(j); await self.broadcast(); return j
    def outputs(self,h,job=None):
        result=[]; seen=set()
        for node in h.get('outputs',{}).values():
            for kind in ('images','gifs','videos'):
                for item in node.get(kind,[]):
                    if not isinstance(item,dict) or not item.get('filename'):continue
                    out={k:item.get(k,'') for k in ('filename','subfolder','type')};out['type']=out['type'] or 'output'
                    ext=Path(out['filename']).suffix.lower()
                    if ext not in MEDIA_EXTENSIONS: continue
                    out_id=json.dumps(out,sort_keys=True)
                    if out_id in seen:continue
                    seen.add(out_id); out['media']='video' if kind=='videos' or ext in VIDEO_EXTENSIONS else 'image';result.append(out)
        mode=(job or {}).get('params',{}).get('mode')
        if mode in VIDEO_MODES:
            visible=[o for o in result if o['media']=='video']
            hidden=len(result)-len(visible)
        elif mode in IMAGE_MODES:
            visible=[o for o in result if o['media']=='image']
            hidden=len(result)-len(visible)
        else:
            visible=result;hidden=0
        if hidden and job:
            expected='vidéo' if mode in VIDEO_MODES else 'image'
            self.log(f'{hidden} sortie(s) auxiliaire(s) masquée(s) de la galerie · résultat {expected} · {job.get("id","")}')
        return visible
    async def reconcile(self):
        active=[j for j in self.jobs() if j['status'] not in TERMINAL]
        if not active:return
        queue=await self.request('GET','/queue')
        entries=queue.get('queue_running',[])+queue.get('queue_pending',[])
        by_id={x[1]:x for x in entries if len(x)>1}
        running={x[1] for x in queue.get('queue_running',[]) if len(x)>1}
        all_history=None
        for j in active:
            if not j.get('prompt_id'):
                if all_history is None: all_history=await self.request('GET','/history?max_items=200')
                candidates=entries+[h.get('prompt',[]) for h in all_history.values()]
                for row in candidates:
                    if len(row)>3 and isinstance(row[3],dict) and row[3].get('studio_job_id')==j['id']:
                        j['prompt_id']=row[1];j.pop('error',None);break
                if not j.get('prompt_id'):
                    j.update(status='uncertain',stage='Confirmation introuvable : aucune relance automatique');self.save(j);continue
            pid=j['prompt_id']
            h=(await self.request('GET','/history/'+pid)).get(pid)
            if h and h.get('status',{}).get('completed'):
                j.update(status='done',stage='Création terminée',outputs=self.outputs(h,j),finished=time.time());j.pop('error',None)
                if j.get('started') and not j.get('legacy'):
                    seconds=j['finished']-j['started']; j['duration']=seconds
                    # Cache hits are not useful references for full future generations.
                    if j.get('sample_max',0)>0 and seconds>2:
                        self.store.put('perf',j['id'],{'params':j['params'],'seconds':seconds})
                if not j['outputs']:
                    expected='vidéo' if j.get('params',{}).get('mode') in VIDEO_MODES else 'image'
                    j['stage']=f'Terminée, mais aucun fichier {expected} n’a été retourné'
                self.log('Création terminée : '+j['id'])
            elif h and h.get('status',{}).get('status_str')=='error':
                messages=h.get('status',{}).get('messages',[])
                interrupted=any(x[0]=='execution_interrupted' for x in messages)
                err='; '.join(str(x[1].get('exception_message',x[0])) for x in messages if len(x)>1 and isinstance(x[1],dict))
                j.update(status='cancelled' if interrupted else 'error',stage='Arrêtée' if interrupted else 'Génération interrompue',error=err[-3000:])
            elif pid in by_id:
                j.pop('missing_since',None);j.pop('error',None)
                if pid in running:
                    if not j.get('started'):j['started']=time.time();j['recovered_start']=True
                    j.update(status='running')
                    if j.get('stage') in ('Dans la file d’attente','Envoi au moteur') or not j.get('stage'):j['stage']='Chargement / calcul'
                else:j.update(status='queued',stage='Dans la file d’attente')
            else:
                j.setdefault('missing_since',time.time())
                if time.time()-j['missing_since']>30:
                    j.update(status='lost',stage='Tâche absente du moteur et de son historique',error='Le moteur a pu redémarrer ou effacer son historique. Vérifie les sorties avant de relancer.')
            self.save(j)
    async def verify_job(self,key):
        """Reconcile one persisted submission without ever posting it again."""
        if not re.fullmatch('[a-zA-Z0-9_-]{12,80}',str(key)):
            raise ValueError('Identifiant de demande invalide.')
        job=self.store.get('job',str(key))
        if not job: raise ValueError('Demande introuvable dans l’historique local.')
        if job.get('status') in TERMINAL: return job
        await self.reconcile()
        return self.store.get('job',str(key),job)
    async def on_event(self,event):
        kind=event.get('type'); d=event.get('data',{}); pid=d.get('prompt_id')
        if not pid:return # Never attribute another client's unscoped progress.
        j=next((j for j in self.jobs() if j.get('prompt_id')==pid and j['status'] not in TERMINAL),None)
        if not j:return
        if kind=='execution_start':j.update(started=time.time(),status='running',stage='Chargement des modèles')
        elif kind=='executing':
            node=str(d.get('node')); stages={'3':'Calcul de la création','6':'Lecture du prompt','7':'Lecture des exclusions','8':'Décodage des images','58':'Enregistrement du fichier','55':'Préparation de l’image de départ'}
            j.update(stage=stages.get(node,'Préparation des modèles') if d.get('node') else 'Finalisation')
            if j.get('node')!=node:self.log(j['stage']+' · '+j['id'])
            j['node']=node
        elif kind=='progress' and str(d.get('node',j.get('node')))=='3':
            value=int(d.get('value',0)); maximum=int(d.get('max',0))
            if not j.get('sample_first_at') or value<j.get('sample_value',0):j.update(sample_first_at=time.time(),sample_first_value=value)
            j.update(sample_value=value,sample_max=maximum,sample_at=time.time(),stage=f'Calcul : étape {value} / {maximum}',status='running')
        elif kind in ('execution_error','execution_interrupted'):
            self.log('Calcul interrompu · '+j['id']+' · '+str(d.get('exception_message','Arrêt demandé'))[:1000])
            j.update(status='cancelled' if kind=='execution_interrupted' else 'error',stage='Arrêtée' if kind=='execution_interrupted' else 'Échec de génération',error=str(d.get('exception_message','Calcul interrompu'))[:3000])
        self.save(j); await self.broadcast()
    def public_job(self,j):
        j=dict(j)
        outputs=[];mode=j.get('params',{}).get('mode')
        for source_index,o in enumerate(j.get('outputs',[])):
            if not isinstance(o,dict):continue
            media=o.get('media') or ('video' if Path(str(o.get('filename',''))).suffix.lower() in VIDEO_EXTENSIONS else 'image')
            if mode in VIDEO_MODES and media!='video':continue
            if mode in IMAGE_MODES and media!='image':continue
            outputs.append(dict(o,media=media,_source_index=source_index))
        j['outputs']=[dict(o,url=f'/api/media/{j["id"]}/{o["_source_index"]}') for o in outputs]
        remaining=None
        if j['status']=='running':
            a=j.get('sample_value',0)-j.get('sample_first_value',0)
            if a>=2 and j.get('node')=='3':
                per=(j.get('sample_at',time.time())-j['sample_first_at'])/a
                remaining=max(0,(j.get('sample_max',0)-j['sample_value'])*per-(time.time()-j.get('sample_at',time.time())))
                j['remaining_kind']='Calcul restant, hors décodage'
            elif j.get('started') and j.get('estimate',{}).get('seconds'):
                remaining=j['estimate']['seconds']-(time.time()-j['started']);j['remaining_kind']='Estimation locale'
                if remaining<0:remaining=None;j['remaining_kind']='Estimation dépassée, calcul en cours'
        j['remaining']=round(remaining) if remaining is not None else None
        return j
    async def broadcast(self):
        body={'jobs':[self.public_job(j) for j in self.jobs()[:150]],'websocket':self.ws_connected}
        for ws in tuple(self.clients):
            try:await asyncio.wait_for(ws.send_json(body),2)
            except Exception:self.clients.discard(ws)
    async def monitor(self):
        while True:
            try:
                await self.reconcile();self.connection_error=None
            except asyncio.CancelledError:raise
            except Exception as e:
                if str(e)!=self.connection_error:self.log('Suivi : moteur momentanément indisponible. Les tâches sont conservées.');self.connection_error=str(e)
            await self.broadcast();await asyncio.sleep(3)
    async def websocket_engine(self):
        while True:
            try:
                async with self.session.ws_connect(self.comfy.replace('http:','ws:',1)+'/ws?clientId='+self.client_id,heartbeat=20,timeout=5) as ws:
                    self.ws_connected=True
                    async for msg in ws:
                        if msg.type==aiohttp.WSMsgType.TEXT:
                            try:await self.on_event(json.loads(msg.data))
                            except (ValueError,TypeError):pass
            except asyncio.CancelledError:raise
            except Exception:pass
            self.ws_connected=False;await asyncio.sleep(3)
    async def optimize(self,raw):
        if self.gpu_lock.locked():raise ValueError('Une optimisation est déjà en cours.')
        async with self.gpu_lock:
            queue=await self.request('GET','/queue')
            if queue.get('queue_running') or queue.get('queue_pending'):raise ValueError('Attends la fin des générations pour optimiser le prompt et préserver la mémoire.')
            p=parameters(raw);model=str(raw.get('ollama_model',''))
            tags=await self.request('GET','/api/tags',base=self.ollama)
            if model not in [m.get('name') for m in tags.get('models',[])]:raise ValueError('Choisis un modèle Ollama installé.')
            self.optimizing=True
            try:
                system=('Rewrite the user description as one concise English visual generation prompt. Preserve their intent and subjects. '
                        'Return only the prompt, no explanation. Use concrete composition, lighting, camera and coherent motion for video. '
                        f'Target: ComfyUI Wan 2.2 5B, {p["width"]}x{p["height"]}, {p["frames"]} frames; RTX 4060 8GB, 16GB RAM. '
                        'For a single image describe a still composition. Do not invent additional people. '
                        'Do not create explicit sexual content. For nudity, describe only nonsexual adult fine-art composition without graphic detail.')
                result=await self.request('POST','/api/chat',{'model':model,'stream':False,'keep_alive':0,
                    'options':{'num_ctx':2048,'num_predict':350,'temperature':.5},
                    'messages':[{'role':'system','content':system},{'role':'user','content':p['prompt']}]},base=self.ollama,timeout=240)
                answer=result.get('message',{}).get('content','').strip()
                if not answer:raise EngineError('Ollama a renvoyé une réponse vide.')
                return {'prompt':answer,'original':p['prompt']}
            finally:self.optimizing=False
    async def _analysis_samples(self,o,raw):
        if o.get('media')!='video':return [await asyncio.to_thread(normalize_analysis_image,raw)]
        suffix=Path(o.get('filename','video.mp4')).suffix.lower()
        if suffix not in VIDEO_EXTENSIONS:suffix='.mp4'
        with tempfile.TemporaryDirectory(prefix='studio-analysis-') as folder:
            source=Path(folder)/('sample'+suffix);first=Path(folder)/'frame-first.jpg';last=Path(folder)/'frame-last.jpg'
            source.write_bytes(raw)
            self.debug('analysis.extract.start',filename=o.get('filename',''),bytes=len(raw))
            try:
                meta=await self.workshop.media.probe(source)
            except Exception as e:
                self.debug('analysis.extract.probe_error',error=str(e)[:2500])
                raise ValueError('Analyse vidéo impossible : FFmpeg ne lit pas la vidéo générée. '+str(e)[:1800]) from e
            first_args=[*self.workshop.media.input(source),'-map','0:v:0','-frames:v','1','-vf','scale=768:-2',str(first)]
            try:await self.workshop.media.run(first_args,timeout=90)
            except Exception as e:
                self.debug('analysis.extract.first_error',error=str(e)[:2500])
                raise ValueError('Analyse vidéo impossible : extraction de la première image : '+str(e)[:1800]) from e
            if not first.is_file():raise ValueError('Analyse vidéo impossible : aucune image décodable dans la vidéo.')
            samples=[first.read_bytes()]
            try:
                at=max(0,float(meta.get('duration',0))-.25)
                await self.workshop.media.run(['-ss',f'{at:.3f}',*self.workshop.media.input(source),'-map','0:v:0','-frames:v','1','-vf','scale=768:-2',str(last)],timeout=90)
            except Exception as e:
                self.debug('analysis.extract.last_error',error=str(e)[:2500])
                self.log('Analyse vidéo : image finale indisponible · '+str(e)[:500])
            if last.is_file() and last.stat().st_size:samples.append(last.read_bytes())
            self.debug('analysis.extract.done',duration=meta.get('duration'),samples=len(samples),first_bytes=len(samples[0]))
            self.log('Analyse vidéo : '+str(len(samples))+' image(s) représentative(s) extraite(s).')
            return samples

    async def analyze_job(self,key,model_name='',output_index=0):
        if self.gpu_lock.locked():raise ValueError('Le moteur local est occupé. Attends sa libération.')
        async with self.gpu_lock:
            queue=await self.request('GET','/queue')
            if queue.get('queue_running') or queue.get('queue_pending'):
                raise ValueError('Attends la fin des générations avant l’analyse visuelle pour préserver la mémoire GPU.')
            return await self._analyze_job_s2(key,model_name,output_index)

    async def _analyze_job_s2(self,key,model_name='',output_index=0):
        j=self.store.get('job',key)
        if not j: raise ValueError('Création introuvable.')
        if j.get('status')!='done' or not j.get('outputs'): raise ValueError('La création doit être terminée avant son analyse.')
        try:output_index=int(output_index)
        except (TypeError,ValueError):raise ValueError('Index de média invalide.')
        if output_index<0 or output_index>=len(j['outputs']):raise ValueError('Média introuvable dans cette création.')
        o=j['outputs'][output_index]
        if not o.get('media'):
            o=dict(o,media='video' if Path(str(o.get('filename',''))).suffix.lower() in VIDEO_EXTENSIONS else 'image')
        if j.get('params',{}).get('mode') in VIDEO_MODES and o.get('media')!='video':
            video_index=next((i for i,x in enumerate(j['outputs']) if x.get('media')=='video'),None)
            if video_index is None:
                video_index=next((i for i,x in enumerate(j['outputs']) if Path(str(x.get('filename',''))).suffix.lower() in VIDEO_EXTENSIONS),None)
            if video_index is None:raise ValueError('Aucune vidéo terminée n’est disponible pour l’analyse.')
            output_index=video_index;o=j['outputs'][output_index]
            if not o.get('media'):o=dict(o,media='video')
        query={k:o.get(k,'') for k in ('filename','subfolder','type')}
        self.debug('analysis.media.request',job_id=key,output_index=output_index,query=query)
        async with self.session.get(self.comfy+'/view?'+urlencode(query),allow_redirects=False,timeout=aiohttp.ClientTimeout(total=120)) as response:
            self.debug('analysis.media.response',job_id=key,status=response.status,
                       content_type=response.headers.get('Content-Type',''),
                       content_length=response.headers.get('Content-Length',''))
            if response.status not in (200,206):
                raise ValueError(f'Le média terminé n’est plus disponible dans ComfyUI (HTTP {response.status}, fichier {o.get("filename","")}).')
            raw=await read_media_limited(response.content)
        if len(raw)>30*1024*1024:raise ValueError('Média trop volumineux pour une analyse locale.')
        samples=await self._analysis_samples(o,raw)
        tags=await self.request('GET','/api/tags',base=self.ollama,timeout=20)
        names=[m.get('name','') for m in tags.get('models',[]) if m.get('name')]
        model=await select_vision_model(self,model_name,names)
        params=j.get('params',{});duration=round(params.get('frames',1)/max(1,params.get('fps',24)),2)
        system=('You are a strict visual quality inspector for a local image/video generation studio. '
                'Compare the supplied image or representative video frames with the original request. '
                'For video, the images are supplied in chronological order (first frame, then final frame when available); '
                'do not claim to have seen motion between frames. Preserve the user intent. '
                'Detect visible abnormalities: extra limbs, malformed hands, face drift, duplicate subjects, '
                'unexpected objects or people, broken anatomy, flicker clues, wrong framing, wrong color/style, '
                'or an action that does not match the request. Return ONLY valid JSON with keys: '
                'score (0-100), needs_correction (boolean), detected (array of short French strings), '
                'correction (short French instruction for the next generation), preserved (array of important user intents).')
        user=(f'Request: {params.get("prompt","")}\nTarget mode: {params.get("mode","")}\n'
              f'Target duration: {duration} seconds\nAnalyze this generated result and do not invent defects that are not visible. '
              f'There are {len(samples)} supplied image(s), in chronological order for video.')
        chat={'model':model,'stream':False,'keep_alive':0,'format':'json',
              'options':{'num_ctx':4096,'num_predict':500,'temperature':.1},
              'messages':[{'role':'system','content':system},{'role':'user','content':user,
                          'images':[base64.b64encode(sample).decode('ascii') for sample in samples]}]}
        try:
            result=await self.request('POST','/api/chat',chat,base=self.ollama,timeout=240)
        except EngineError as e:
            # Older Ollama/VLM combinations reject JSON mode together with
            # images. Retry once without that optional response constraint.
            if e.status not in (400,404,422):
                raise ValueError('Ollama a refusé l’analyse visuelle : '+str(e)[:2400]) from e
            self.debug('analysis.chat.retry_without_json_format',status=e.status,error=str(e)[:1200])
            chat.pop('format',None)
            result=await self.request('POST','/api/chat',chat,base=self.ollama,timeout=240)
        answer=result.get('message',{}).get('content','').strip() if isinstance(result,dict) else ''
        self.debug('analysis.chat.answer',job_id=key,model=model,answer_chars=len(answer))
        analysis=parse_visual_report(answer)
        analysis['model']=model;analysis['job_id']=key;analysis['output_index']=output_index;analysis['created']=time.time();j['analysis']=analysis;self.save(j)
        self.log('Analyse locale du rendu : '+key+' · score='+str(analysis.get('score','?'))+(' · rapport à vérifier' if not analysis.get('analysis_valid',True) else ''))
        return analysis
    async def support_bundle(self,remarks='',browser_events=None):
        """Build a small, user-requested diagnostic bundle for ChatGPT support."""
        report={'schema':'bazor-studio-support-v1','version':VERSION,'exported_at':time.strftime('%Y-%m-%dT%H:%M:%S%z'),
                'remarks':str(remarks or '')[:12000],'browser_events':list(browser_events or [])[-100:],'runtime':self.runtime_identity,
                'health':await self.health(),
                'jobs':[{'id':j.get('id'),'status':j.get('status'),'stage':j.get('stage'),'error':j.get('error'),
                         'prompt_id':j.get('prompt_id'),'params':j.get('params',{}),'outputs':j.get('outputs',[])} for j in self.jobs()[:50]],
                'studio_log':self.log_lines[-500:],'debug_log':'logs/studio-debug.jsonl'}
        buf=io.BytesIO()
        with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED) as archive:
            archive.writestr('diagnostic.json',json.dumps(report,ensure_ascii=False,indent=2))
            logdir=self.data.parent/'logs'
            for name in ('studio.log','watchdog.log','lancement.log','installation.log','studio-debug.jsonl','studio-debug.1.jsonl','verification-version.json','installation-verifiee.json'):
                path=logdir/name
                try:
                    raw=path.read_bytes()
                    archive.writestr('logs/'+name,raw[-300000:])
                except OSError:
                    pass
            archive.writestr('A_LIRE_DANS_GPT.txt','Joindre ce ZIP à votre message. Commencer par les remarques de diagnostic.json, puis les journaux logs/.')
        return buf.getvalue()
    async def cancel(self,key):
        j=self.store.get('job',key)
        if not j:raise ValueError('Tâche introuvable.')
        if j['status'] in TERMINAL:return self.public_job(j)
        pid=j.get('prompt_id')
        if not pid:raise ValueError('Impossible d’annuler sans confirmation du moteur. Ouvre ComfyUI pour vérifier sa file.')
        try:
            await self.request('POST','/api/jobs/'+pid+'/cancel',{})
        except EngineError as e:
            if e.status not in (404,405):raise
            q=await self.request('GET','/queue')
            if any(x[1]==pid for x in q.get('queue_pending',[])):
                await self.request('POST','/queue',{'delete':[pid]});j.update(status='cancelled',stage='Retirée de la file')
            else:
                # Older /interrupt is global: do not risk cancelling a different job in a race.
                raise ValueError('Cette version de ComfyUI ne propose pas l’arrêt ciblé. Utilise Arrêter dans ComfyUI pour la tâche en cours.')
        j['stage']='Arrêt demandé' if j['status']!='cancelled' else j['stage'];self.save(j);return self.public_job(j)
    async def import_legacy(self):
        if not self.legacy or self.store.get('meta','legacy_imported'):return
        path=self.legacy/'data'/'jobs.json'
        if not path.exists():return
        try:
            data=json.loads(path.read_text(encoding='utf-8-sig'));items=data.values() if isinstance(data,dict) else data
            for old in items:
                if not isinstance(old,dict) or not old.get('id'):continue
                key='legacy_'+re.sub('[^a-zA-Z0-9_-]','',str(old['id']))
                p=old.get('params',{});p.setdefault('engine','wan');p['asset_id']=None
                name=p.get('image_file')
                if name:
                    root=Path(os.environ.get('AI_ROOT',r'C:\AI'))/'ComfyUI'/'ComfyUI_windows_portable'/'ComfyUI'/'input'
                    if Path(name).name==name and (root/name).is_file():
                        aid=uuid.uuid4().hex
                        with Image.open(root/name) as im:ImageOps.exif_transpose(im).convert('RGB').save(self.assets/(aid+'.png'))
                        self.store.put('asset',aid,{'id':aid,'url':'/api/assets/'+aid});p['asset_id']=aid
                outs=[]
                for o in old.get('outputs',[]):
                    if not isinstance(o,dict):continue
                    query=parse_qs(urlparse(o.get('url','')).query)
                    filename=o.get('filename') or query.get('filename',[''])[0]
                    if filename:outs.append({'filename':filename,'subfolder':o.get('subfolder',query.get('subfolder',[''])[0]),'type':o.get('type',query.get('type',['output'])[0]),'media':o.get('media','video' if Path(filename).suffix.lower() in ('.mp4','.webm','.mkv','.mov') else 'image')})
                status={'stopped':'cancelled'}.get(old.get('status'),old.get('status','lost'))
                j={'id':key,'params':p,'created':old.get('created',time.time()),'started':None,'status':status,
                   'stage':'Création importée de la version précédente','outputs':outs,'prompt_id':old.get('prompt_id'),
                   'client_id':old.get('client_id'),'legacy':True,'estimate':{'seconds':None},'seed':old.get('seed')}
                self.save(j)
            # Retain old timings separately; old durations included queue wait, so do not calibrate with them.
            perf=self.legacy/'data'/'performance_history.json'
            if perf.exists():self.store.put('meta','legacy_performance',json.loads(perf.read_text(encoding='utf-8-sig')))
            self.store.put('meta','legacy_imported',True);self.log('Ancien historique importé ; les fichiers d’origine sont conservés.')
        except Exception as e:self.log('Import ancien historique incomplet : '+str(e))
    async def start(self,app):
        self.session=aiohttp.ClientSession(trust_env=False)
        await self.import_legacy()
        self.tasks=[asyncio.create_task(self.monitor()),asyncio.create_task(self.websocket_engine()),asyncio.create_task(self.workshop.monitor())]
        self.log('Studio 2 démarré en connexion au moteur existant.')
    async def close(self,app):
        for t in self.tasks:t.cancel()
        await asyncio.gather(*self.tasks,return_exceptions=True)
        for ws in tuple(self.clients):await ws.close()
        await self.workshop.close()
        await self.autopilot.close()
        if self.session:await self.session.close()
        self.store.db.close()


def create_app(data,comfy='http://127.0.0.1:8188',ollama='http://127.0.0.1:11434',legacy=None):
    studio=Studio(data,comfy,ollama,legacy)
    @web.middleware
    async def guard(request,handler):
        started=time.perf_counter(); response=None
        host=request.host.split(':')[0]
        if host not in ('127.0.0.1','localhost'):
            studio.debug('http.rejected',method=request.method,path=request.path,reason='host')
            return web.json_response({'error':'Hôte non autorisé.'},status=403)
        origin=request.headers.get('Origin')
        if origin and origin!=f'http://{request.host}':
            studio.debug('http.rejected',method=request.method,path=request.path,reason='origin')
            return web.json_response({'error':'Origine non autorisée.'},status=403)
        if request.method not in ('GET','HEAD') and not secrets.compare_digest(request.headers.get('X-Studio-Token',''),studio.token):
            studio.debug('http.rejected',method=request.method,path=request.path,reason='token')
            return web.json_response({'error':'Recharge la page pour renouveler la connexion.'},status=403)
        try:
            response=await handler(request)
        except web.HTTPException:
            raise
        except (ValueError,TypeError) as e:
            response=web.json_response({'error':str(e)},status=400)
        except Exception as e:
            logging.exception('Request failed');studio.debug('http.exception',method=request.method,path=request.path,error=str(e)[:3500])
            response=web.json_response({'error':str(e)[:3500]},status=502)
        response.headers['X-Content-Type-Options']='nosniff'
        response.headers['Referrer-Policy']='no-referrer'
        response.headers['Cache-Control']='no-store'
        response.headers['Content-Security-Policy']="default-src 'self'; img-src 'self' blob: data:; media-src 'self' blob:; style-src 'self'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'"
        studio.debug('http.response',method=request.method,path=request.path,status=response.status,
                     duration_ms=round((time.perf_counter()-started)*1000))
        return response
    app=web.Application(middlewares=[guard],client_max_size=20*1024*1024)
    app['studio']=studio;app.on_startup.append(studio.start);app.on_cleanup.append(studio.close)
    routes=web.RouteTableDef()
    @routes.get('/api/ping')
    async def ping(r):return web.json_response(studio.runtime_identity)
    @routes.get('/api/config')
    async def config(r):return web.json_response({'token':studio.token,'version':VERSION})
    @routes.get('/api/health')
    async def health(r):return web.json_response(await studio.health())
    @routes.get('/api/autopilot/status')
    async def autopilot_status(r):return web.json_response(await studio.autopilot.status())
    @routes.post('/api/autopilot/attach')
    async def autopilot_attach(r):
        body=await r.json() if r.can_read_body else {}
        return web.json_response(await studio.autopilot.attach(bool(body.get('start_if_missing',True))))
    @routes.post('/api/autopilot/profile-menu')
    async def autopilot_profile_menu(r):
        body=await r.json() if r.can_read_body else {}
        return web.json_response(await studio.autopilot.open_profile_menu(bool(body.get('start_if_missing',True))))
    @routes.post('/api/autopilot/disconnect')
    async def autopilot_disconnect(r):
        await studio.autopilot.disconnect()
        return web.json_response(await studio.autopilot.status())
    @routes.get('/api/jobs')
    async def jobs(r):return web.json_response({'jobs':[studio.public_job(j) for j in studio.jobs()[:150]]})
    @routes.post('/api/jobs')
    async def submit(r):return web.json_response(studio.public_job(await studio.submit(await r.json(),r.headers.get('Idempotency-Key',''))))
    @routes.post('/api/jobs/{key}/verify')
    async def verify(r):return web.json_response(studio.public_job(await studio.verify_job(r.match_info['key'])))
    @routes.post('/api/jobs/{key}/cancel')
    async def cancel(r):return web.json_response(await studio.cancel(r.match_info['key']))
    @routes.post('/api/jobs/{key}/delete')
    async def delete_job(r):return web.json_response(studio.delete_job(r.match_info['key']))
    @routes.post('/api/debug/event')
    async def debug_event(r):
        body=await r.json() if r.can_read_body else {}
        return web.json_response(studio.record_client_events(body.get('events',[])))
    @routes.post('/api/jobs/{key}/analyze')
    async def analyze_job(r):
        body=await r.json() if r.can_read_body else {}
        return web.json_response(await studio.analyze_job(r.match_info['key'],str(body.get('model','')),body.get('index',0)))
    @routes.post('/api/estimate')
    async def estimate(r):return web.json_response(studio.estimate(parameters(await r.json(),False)))
    @routes.post('/api/optimize')
    async def optimize(r):return web.json_response(await studio.optimize(await r.json()))
    @routes.post('/api/upload')
    async def upload(r):return web.json_response(await studio.upload(r))
    @routes.post('/api/image-reference')
    async def image_reference(r):
        d=await r.json();j=studio.store.get('job',str(d.get('job_id','')))
        if not j:raise ValueError('Création introuvable.')
        try:
            i=int(d.get('index',0))
            if i<0:raise IndexError()
            o=j['outputs'][i]
        except (KeyError,ValueError,IndexError):raise ValueError('Image introuvable.')
        if o.get('media')!='image':raise ValueError('Choisis une image, ou utilise Prolonger pour une vidéo.')
        query={k:o.get(k,'') for k in ('filename','subfolder','type')}
        async with studio.session.get(studio.comfy+'/view?'+urlencode(query),allow_redirects=False,timeout=aiohttp.ClientTimeout(total=60)) as response:
            if response.status!=200:raise ValueError('Image absente du moteur.')
            data=bytearray()
            async for part in response.content.iter_chunked(65536):
                data.extend(part)
                if len(data)>20*1024*1024:raise ValueError('Image trop volumineuse.')
        return web.json_response({'asset':await studio.image_bytes(data),'prompt':j['params'].get('prompt','')})
    @routes.get('/api/assets/{key}')
    async def asset(r):
        key=r.match_info['key']
        if not re.fullmatch('[a-f0-9]{32}',key) or not studio.store.get('asset',key):raise web.HTTPNotFound()
        return web.FileResponse(studio.assets/(key+'.png'))
    @routes.get('/api/media/{key}/{index}')
    async def media(r):
        job=studio.store.get('job',r.match_info['key'])
        if not job:raise web.HTTPNotFound()
        try:
            index=int(r.match_info['index'])
            if index<0:raise IndexError()
            o=job['outputs'][index]
        except (KeyError,ValueError,IndexError):raise web.HTTPNotFound()
        query={k:o.get(k,'') for k in ('filename','subfolder','type')}
        headers={k:r.headers[k] for k in ('Range',) if k in r.headers}
        async with studio.session.get(studio.comfy+'/view?'+urlencode(query),headers=headers,allow_redirects=False,timeout=aiohttp.ClientTimeout(total=600)) as upstream:
            if upstream.status not in (200,206):raise web.HTTPNotFound(text='Fichier absent du moteur. Vérifie ComfyUI et son dossier output.')
            copied={k:upstream.headers[k] for k in ('Content-Type','Content-Length','Content-Range','Accept-Ranges') if k in upstream.headers}
            if 'download' in r.query:copied['Content-Disposition']='attachment; filename="'+re.sub('[^a-zA-Z0-9_.-]','_',query['filename'])+'"'
            response=web.StreamResponse(status=upstream.status,headers=copied)
            await response.prepare(r)
            async for chunk in upstream.content.iter_chunked(64*1024):await response.write(chunk)
            return response
    @routes.get('/api/workflow/{key}')
    async def workflow(r):
        graph=studio.store.get('workflow',r.match_info['key'])
        if not graph:raise web.HTTPNotFound()
        return web.json_response(graph,headers={'Content-Disposition':'attachment; filename="workflow_api.json"'})
    @routes.get('/api/log')
    async def log(r):return web.json_response({'lines':studio.log_lines,'debug':studio.debug_tail()})
    @routes.get('/api/diagnostic')
    async def diagnostic(r):
        report={'version':VERSION,'date':time.strftime('%Y-%m-%d %H:%M:%S'),'health':await studio.health(),
                'jobs':[{'id':j['id'],'status':j['status'],'prompt_id':j.get('prompt_id'),'error':j.get('error')} for j in studio.jobs()[:30]],'log':studio.log_lines}
        return web.json_response(report,headers={'Content-Disposition':'attachment; filename="diagnostic_studio.json"'})
    @routes.post('/api/support-bundle')
    async def support_bundle(r):
        body=await r.json() if r.can_read_body else {}
        data=await studio.support_bundle(body.get('remarks',''),body.get('browser_events',[]))
        stamp=time.strftime('%Y%m%d-%H%M%S')
        return web.Response(body=data,content_type='application/zip',headers={'Content-Disposition':f'attachment; filename="BAZOR_V3_diagnostic_{stamp}.zip"'})
    @routes.get('/ws')
    async def ws(r):
        socket=web.WebSocketResponse(heartbeat=20);await socket.prepare(r);studio.clients.add(socket)
        await studio.broadcast()
        try:
            async for _ in socket:pass
        finally:studio.clients.discard(socket)
        return socket
    @routes.get('/')
    async def index(r):return web.FileResponse(Path(__file__).parent/'static'/'index.html')
    app.add_routes(studio.workshop.routes());app.add_routes(studio.model_setup.routes());app.add_routes(studio.prompt_library.routes())
    app.add_routes(routes);app.router.add_static('/static/',Path(__file__).parent/'static',show_index=False)
    return app


if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=8190);p.add_argument('--data',default=str(Path(__file__).parent.parent/'data'));p.add_argument('--legacy',default=None);args=p.parse_args()
    logs=Path(args.data).parent/'logs';logs.mkdir(parents=True,exist_ok=True)
    logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s',handlers=[logging.handlers.RotatingFileHandler(logs/'studio.log',maxBytes=2_000_000,backupCount=3,encoding='utf-8')])
    web.run_app(create_app(args.data,os.environ.get('COMFY_URL','http://127.0.0.1:8188'),os.environ.get('OLLAMA_URL','http://127.0.0.1:11434'),args.legacy),host='127.0.0.1',port=args.port,print=None,access_log=None,shutdown_timeout=5)
