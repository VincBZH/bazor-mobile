"""Native ComfyUI graphs, derived from the official Wan 2.2 5B topology."""
import re
import secrets

PRESETS = {'fast': (640,352,49,20), 'balanced': (832,480,49,24), 'quality': (1280,704,49,28)}
MODELS = {'UNETLoader': ('unet_name','wan2.2_ti2v_5B_fp16.safetensors'),
          'CLIPLoader': ('clip_name','umt5_xxl_fp8_e4m3fn_scaled.safetensors'),
          'VAELoader': ('vae_name','wan2.2_vae.safetensors')}

H3_HINTS = ('modelSamplingMiniMaxH3', 'spectrumMiniMaxH3', 'projection4B',
            'minimaxH3', 'miniMaxH3')

# These rules are deliberately applied again on the server.  The browser is
# only a convenience layer; a saved prompt, batch, or direct API request must
# receive the same framing and quality constraints.
STYLE_RULES = {
    'realistic': {
        'label': 'photorealistic photography',
        'prompt': 'photorealistic result, natural skin and fabric detail, physically plausible lighting, stable anatomy and consistent composition',
        'negative': 'plastic skin, oversmoothing, artificial anatomy, illustration, cartoon, CGI',
    },
    'portrait': {
        'label': 'portrait framing',
        'prompt': 'portrait framing, stable facial identity, clear eyes and expression, shoulders and upper body well composed, camera at a natural portrait distance',
        'negative': 'warped face, changing identity, cropped eyes, cut-off head',
    },
    'fullbody': {
        'label': 'strict full-body framing',
        'prompt': 'STRICT full-body framing: show one adult subject head-to-toe, both feet fully visible, clear space above the head and below the feet, stable body proportions, camera distance adjusted to keep the entire body in frame, no crop',
        'negative': 'cropped body, cut-off head, cut-off feet, missing legs, close-up, distorted proportions, seated pose when standing is requested',
    },
    'standing': {
        'label': 'strict standing pose',
        'prompt': 'STRICT standing pose: one adult subject upright on both feet, full weight-bearing posture, legs and feet visible, natural vertical alignment, no sitting, kneeling, lying down or floating',
        'negative': 'seated, sitting, kneeling, lying down, crouching, floating, cut-off legs, cut-off feet, impossible balance',
    },
    'bw': {
        'label': 'black-and-white photography',
        'prompt': 'high-quality black-and-white photography, rich grayscale tones, controlled contrast, natural light, no color accents',
        'negative': 'color cast, oversaturated colors, posterization',
    },
    'cinematic': {
        'label': 'cinematic shot',
        'prompt': 'cinematic shot, deliberate composition, soft controlled camera movement, coherent lighting and realistic depth',
        'negative': 'random camera movement, abrupt cuts, inconsistent lighting',
    },
    'natural': {
        'label': 'natural motion',
        'prompt': 'natural everyday motion, restrained gestures, stable framing, one clear action, no added subjects or objects',
        'negative': 'excessive motion, extra subjects, impossible action',
    },
    'adultEditorial': {
        'label': 'non-explicit adult fashion editorial',
        'prompt': 'tasteful adult fashion editorial, sophisticated styling, poised adult subject, non-explicit composition, refined professional photography',
        'negative': 'explicit nudity, graphic sexual content, fetish focus, voyeuristic framing',
    },
    'confidentPose': {
        'label': 'confident adult pose',
        'prompt': 'confident adult body language, elegant fashion pose, tasteful framing, no graphic detail',
        'negative': 'graphic sexual action, explicit exposure, vulgar pose',
    },
    'lingerieFashion': {
        'label': 'non-explicit lingerie fashion',
        'prompt': 'high-end lingerie fashion editorial, refined styling, opaque coverage, studio-quality lighting, non-explicit composition',
        'negative': 'transparent fabric, explicit exposure, graphic detail',
    },
    'silhouette': {
        'label': 'tasteful silhouette emphasis',
        'prompt': 'tasteful silhouette emphasis through fashion posing and balanced composition, adult subject, non-explicit photography',
        'negative': 'distorted anatomy, explicit exposure',
    },
    'cameraGaze': {
        'label': 'direct camera gaze',
        'prompt': 'direct confident gaze toward the camera, poised adult expression, stable identity',
        'negative': 'changing gaze, warped eyes, unstable identity',
    },
    'boudoirLight': {
        'label': 'elegant boudoir-inspired light',
        'prompt': 'elegant boudoir-inspired lighting, refined interior editorial mood, adult fashion context, non-explicit composition',
        'negative': 'dark artifacts, explicit scene, voyeuristic framing',
    },
}


def style_keys(raw):
    values = raw.get('style_presets') if isinstance(raw, dict) else None
    if not isinstance(values, list):
        values = str((raw or {}).get('style_preset', 'realistic')).split('+')
    keys = []
    for value in values:
        key = str(value or '').strip()
        if key in STYLE_RULES and key not in keys:
            keys.append(key)
    return keys or ['realistic']


def _prompt_without_browser_suffix(value):
    # V3's browser writes a readable preview block into the textarea.  Do not
    # duplicate that block when the same prompt is submitted or reused.
    return re.split(r'\n\s*\[Style visuel\]\s*', str(value or ''), maxsplit=1)[0].strip()


def generation_prompt(p):
    base = _prompt_without_browser_suffix(p.get('prompt', ''))
    rules = [STYLE_RULES[key]['prompt'] for key in p.get('style_presets', ['realistic'])]
    return '\n\n'.join([base, '[Strict style and framing] ' + '; '.join(rules)]).strip()


def generation_negative(p):
    values = [p.get('negative', '')]
    values.extend(STYLE_RULES[key]['negative'] for key in p.get('style_presets', ['realistic']))
    # Studio safety remains active for native and imported workflows alike.
    values.append('explicit sexual activity, pornographic content, graphic genital detail')
    if not p.get('artistic'):
        values.append('nudity')
    seen = set(); parts = []
    for value in values:
        for part in re.split('[,\n]', str(value or '')):
            part = part.strip()
            if part and part.casefold() not in seen:
                seen.add(part.casefold()); parts.append(part)
    return ', '.join(parts)[:6000]


def detect_profile(info):
    """Identify the installed video family from ComfyUI's live node registry.

    The Studio must never send a native Wan graph to a MiniMax-H3 installation:
    both can expose similarly named video nodes, but their latent conditioning is
    not interchangeable. Detection is deliberately based on exact node keys
    returned by /object_info, not on filenames or a user preference.
    """
    keys = [str(k) for k in (info or {})]
    compact = {''.join(ch for ch in k if ch.isalnum()).lower() for k in keys}
    h3 = any(any(h.lower() in key for key in compact) for h in H3_HINTS)
    if h3:
        return {'family': 'h3', 'label': 'MiniMax H3', 'nodes': keys}
    native = 'wan22imagetovideolatent' in compact or 'wanimagetovideolatent' in compact
    return {'family': 'wan', 'label': 'Wan 2.2', 'nodes': keys, 'native': native}


def _node_class(node):
    return str((node or {}).get('class_type') or '')


def _node_title(node):
    return str(((node or {}).get('_meta') or {}).get('title') or '')


def _graph_nodes(graph, predicate):
    return [(str(k), v) for k, v in (graph or {}).items()
            if isinstance(v, dict) and predicate(v)]


def _api_graph_legacy_s22(graph):
    return unwrap_graph(graph)

# BAZOR_H3_WRAPPER_S22
def _api_graph(graph):
    try:
        return unwrap_graph(graph)
    except ValueError:
        return unwrap_graph(_api_graph_legacy_s22(graph))


TEXT_INPUTS = ('text', 'prompt', 'positive', 'negative', 'positive_prompt',
               'negative_prompt', 'caption', 'description')


def _text_fields(node):
    inputs = (node or {}).get('inputs') or {}
    return [key for key, value in inputs.items()
            if str(key).lower() in TEXT_INPUTS and isinstance(value, str)]


def _set_prompt_nodes(graph, positive, negative):
    graph = _api_graph(graph)
    # H3 workflows are not uniform: the encoder can be CLIPTextEncode,
    # TextEncodeQwen3VL, a ClipProj wrapper, or a custom node with a prompt
    # field. Detect the actual string input instead of relying on one class name.
    encoders = _graph_nodes(graph, lambda n: bool(_text_fields(n)) or (
        any(x in (_node_class(n) + ' ' + _node_title(n)).lower()
            for x in ('encode', 'prompt', 'qwen', 'minimax', 'clipproj')) and
        any(isinstance(v, str) for v in ((n.get('inputs') or {}).values()))))
    if not encoders:
        raise ValueError('Workflow MiniMax H3 incompatible : encodeur de texte introuvable.')
    pos = neg = None
    for pair in encoders:
        title = _node_title(pair[1]).lower()
        if any(x in title for x in ('negative', 'negatif', 'négatif')):
            neg = pair
        elif any(x in title for x in ('positive', 'positif')):
            pos = pair
    pos = pos or encoders[0]
    neg = neg or (encoders[1] if len(encoders) > 1 else None)
    def set_fields(pair, value, prefer_negative=False):
        inputs = pair[1].setdefault('inputs', {})
        fields = _text_fields(pair[1])
        if not fields:
            return
        preferred = [key for key in fields if ('negative' in str(key).lower()) == prefer_negative]
        inputs[(preferred[0] if preferred else fields[0])] = value
    set_fields(pos, positive, False)
    if neg:
        set_fields(neg, negative, True)
    # A few H3 nodes expose both conditioning strings on one node.
    if pos == neg or (pos and not neg):
        inputs = pos[1].setdefault('inputs', {})
        for key in _text_fields(pos[1]):
            if 'negative' in str(key).lower(): inputs[key] = negative


def _patch_common_video_controls(graph, p, prefix, info=None):
    return patch_controls(graph, p, prefix, info)


def patch_h3_graph(graph, p, image_name=None, prefix='AI_Simple_Studio_2/creation', info=None):
    """Patch a converted MiniMax H3 workflow without assuming node IDs.

    H3 community workflows change IDs and optional nodes frequently. We therefore
    patch by class/title and keep the model, projection, VAE and acceleration
    nodes supplied by the user's installed workflow untouched. For single-image
    I2V, every endpoint loader is intentionally set to the same verified image;
    this prevents stale first_frame.png/last_frame.png values from producing the
    scene tearing visible in the supplied video.
    """
    graph = _api_graph(graph)
    if p['mode']=='t2v' and isinstance(graph,dict):
        image_name=None
        if any(isinstance(n,dict) and ('loadimage' in _node_class(n).lower().replace('_','') or 'loadvideo' in _node_class(n).lower().replace('_','')) for n in graph.values()):
            raise ValueError('Workflow texte vers vidéo refusé : il contient une source image ou vidéo. Sélectionne un vrai workflow T2V.')
    if not isinstance(graph, dict) or not graph:
        raise ValueError('Workflow MiniMax H3 vide ou non converti.')
    negative = (generation_negative(p) + ', flicker, morphing, extra limbs, deformed hands, '
                'warped faces, unstable identity, jitter, duplicate subjects, '
                'text artifacts, inconsistent lighting, unrealistic motion').strip(', ')
    _set_prompt_nodes(graph, generation_prompt(p), negative)
    dimensions = _patch_common_video_controls(graph, p, prefix, info)
    loaders = _graph_nodes(
        graph,
        lambda n: (_node_class(n).lower().replace('_', '') == 'loadimage'
                   or 'load image' in _node_title(n).lower()
                   or 'first frame' in _node_title(n).lower()
                   or 'last frame' in _node_title(n).lower()))
    if p['mode'] in ('i2v', 'v2v') and not image_name:
        raise ValueError('Ajoute une image de départ pour MiniMax H3.')
    if image_name:
        if not loaders:
            raise ValueError('Workflow MiniMax H3 incompatible : nœud image de départ introuvable.')
        for _, node in loaders:
            inp = node.setdefault('inputs', {})
            if 'image' in inp:
                inp['image'] = image_name
        stale = [str((n.get('inputs') or {}).get('image')) for _, n in loaders
                 if str((n.get('inputs') or {}).get('image') or '').lower()
                 in ('first_frame.png', 'last_frame.png')]
        if stale:
            raise ValueError('Workflow H3 conserve encore un fichier first_frame/last_frame obsolète.')
    sampler_count = 0
    for _, node in _graph_nodes(graph, lambda n: True):
        inp = node.setdefault('inputs', {})
        if 'steps' in inp or 'noise_seed' in inp or 'seed' in inp:
            sampler_count += 1
    if not sampler_count:
        raise ValueError('Workflow MiniMax H3 incompatible : échantillonneur introuvable.')
    return {'graph': graph, 'family': 'h3', 'loaders': [x[0] for x in loaders],
            'dimension_nodes': [x[1] for x in dimensions]}


def parameters(raw, require_prompt=True):
    p = {k:raw.get(k) for k in ('prompt','negative','asset_id','checkpoint')}
    p['style_presets'] = style_keys(raw)
    p.update(mode=raw.get('mode','t2v'), engine=raw.get('engine','wan'),
             style_preset='+'.join(p['style_presets'])[:120],
             artistic=raw.get('artistic') is True, tiled=raw.get('tiled',True) is True)
    if p['mode'] not in ('t2v','i2v','t2i','i2i','v2v'): raise ValueError('Mode inconnu.')
    # BAZOR_SESSION_S2: text routes never inherit any image source.
    if p['mode'] in ('t2i','t2v'): p['asset_id']=None
    if p['engine'] not in ('wan','h3','sd'): raise ValueError('Moteur inconnu.')
    if p['engine']=='h3' and p['mode'] not in ('t2v','i2v','v2v'): raise ValueError('MiniMax H3 est réservé à la vidéo.')
    if p['engine']=='sd' and p['mode'] not in ('t2i','i2i'): raise ValueError('Le checkpoint image sert uniquement au mode image.')
    if p['mode'] in ('t2i','i2i') and p['engine']!='sd': raise ValueError('Un checkpoint image SD 1.5 / SDXL est obligatoire pour générer une image. Installe-le puis actualise les modèles.')
    for k in ('prompt','negative'):
        p[k]=str(p[k] or '').strip()
        if len(p[k])>6000: raise ValueError('Texte trop long (6 000 caractères maximum).')
    if require_prompt and not p['prompt']: raise ValueError('Décris ce que tu veux créer.')
    defaults=dict(width=832,height=480,frames=49,steps=24,fps=24)
    for k,(low,high) in {'width':(256,1280),'height':(256,1280),'frames':(1,241),'steps':(1,50),'fps':(8,30)}.items():
        v=raw.get(k,defaults[k])
        if isinstance(v,bool) or str(v).strip() not in (str(int(float(v))),): raise ValueError(f'{k} : nombre entier attendu.')
        p[k]=int(v)
        if not low<=p[k]<=high: raise ValueError(f'{k} : valeur attendue entre {low} et {high}.')
    if p['width']%32 or p['height']%32: raise ValueError('La largeur et la hauteur doivent être des multiples de 32.')
    if p['mode'] in ('t2i','i2i'): p['frames']=1
    duration=raw.get('duration_seconds')
    if p['mode'] not in ('t2i','i2i') and duration not in (None,''):
        try:duration=float(duration)
        except (TypeError,ValueError):raise ValueError('Durée : nombre de secondes attendu.')
        if not .5<=duration<=10:raise ValueError('Durée : valeur attendue entre 0,5 et 10 secondes.')
        target=round(duration*p['fps'])+1;p['frames']=min(241,max(5,1+4*round((target-1)/4)))
    p['duration_seconds']=round(p['frames']/p['fps'],3)
    try: p['denoise']=float(raw.get('denoise',.45))
    except (TypeError,ValueError): raise ValueError('Transformation : nombre entre 0,05 et 1 attendu.')
    if not .05<=p['denoise']<=1: raise ValueError('Transformation : nombre entre 0,05 et 1 attendu.')
    if p['mode'] not in ('t2i','i2i') and (p['frames']<5 or (p['frames']-1)%4): raise ValueError('Choisis 4n+1 images : 49, 81, 97, etc.')
    seed=str(raw.get('seed','-1')).strip()
    if not seed.lstrip('-').isdigit() or not -1<=int(seed)<=2**53-1: raise ValueError('Graine : -1 ou entier de 0 à 9007199254740991.')
    p['seed']=int(seed) if int(seed)>=0 else secrets.randbelow(2**53)
    if require_prompt and p['mode'] in ('i2v','v2v','i2i') and not p['asset_id']: raise ValueError('Ajoute une image de départ.')
    return p


def choices(info, cls, field):
    d=info.get(cls,{}).get('input',{})
    spec=d.get('required',{}).get(field) or d.get('optional',{}).get(field) or []
    return spec[0] if spec and isinstance(spec[0],list) else []


def select_models(info):
    selected={}; missing=[]
    for cls,(field,name) in MODELS.items():
        found=next((v for v in choices(info,cls,field) if str(v).replace('\\','/').split('/')[-1].lower()==name.lower()),None)
        if found: selected[field]=found
        else: missing.append(name)
    return selected,missing


def build(p, info, image_name=None, prefix='AI_Simple_Studio_2/creation'):
    if p['mode'] in ('t2i','t2v'): image_name=None
    def n(cls,**inputs): return {'class_type':cls,'inputs':inputs}
    if p.get('engine')=='h3':
        raise ValueError('Le graphe MiniMax H3 doit être construit depuis son workflow installé.')
    negative=generation_negative(p)
    positive=generation_prompt(p)
    if p['artistic']: positive+=', nonsexual fine-art figure study of adults, tasteful composition, no graphic detail'
    graph={
      '6': n('CLIPTextEncode',text=positive,clip=['38',0]),
      '7': n('CLIPTextEncode',text=negative.strip(', '),clip=['38',0]),
      '3': n('KSampler',model=['48',0],positive=['6',0],negative=['7',0],latent_image=['55',0],
             seed=p['seed'],steps=p['steps'],cfg=5.0,sampler_name='uni_pc',scheduler='simple',denoise=1.0),
    }
    if p['engine']=='wan':
        selected,missing=select_models(info)
        if missing: raise ValueError('Modèles absents de ComfyUI : '+', '.join(missing))
        graph.update({'37':n('UNETLoader',unet_name=selected['unet_name'],weight_dtype='default'),
          '38':n('CLIPLoader',clip_name=selected['clip_name'],type='wan',device='default'),
          '39':n('VAELoader',vae_name=selected['vae_name']),
          '48':n('ModelSamplingSD3',model=['37',0],shift=8.0),
          '55':n('Wan22ImageToVideoLatent',vae=['39',0],width=p['width'],height=p['height'],length=p['frames'],batch_size=1)})
        if image_name:
            graph['56']=n('LoadImage',image=image_name)
            graph['55']['inputs']['start_image']=['56',0]
        vae=['39',0]
    else:
        if p['checkpoint'] not in choices(info,'CheckpointLoaderSimple','ckpt_name'): raise ValueError('Choisis un checkpoint SD 1.5 ou SDXL déjà installé.')

        graph.update({'37':n('CheckpointLoaderSimple',ckpt_name=p['checkpoint']),
                      '55':n('EmptyLatentImage',width=p['width'],height=p['height'],batch_size=1)})
        graph['6']['inputs']['clip']=graph['7']['inputs']['clip']=['37',1]
        graph['3']['inputs'].update(model=['37',0],cfg=7.0,sampler_name='euler',scheduler='normal')
        vae=['37',2]
        graph['3']['inputs'].update(cfg=6.0,sampler_name='dpmpp_2m',scheduler='karras')
        if p['mode']=='i2i':
            if not image_name: raise ValueError('Ajoute une image de départ.')
            graph['56']=n('LoadImage',image=image_name)
            graph['54']=n('ImageScale',image=['56',0],upscale_method='lanczos',width=p['width'],height=p['height'],crop='center')
            graph['55']=n('VAEEncode',pixels=['54',0],vae=vae)
            graph['3']['inputs']['denoise']=p['denoise']
    if p['tiled'] and 'VAEDecodeTiled' in info:
        graph['8']=n('VAEDecodeTiled',samples=['3',0],vae=vae,tile_size=256,overlap=64,temporal_size=32,temporal_overlap=4)
    else: graph['8']=n('VAEDecode',samples=['3',0],vae=vae)
    if p['mode'] in ('t2i','i2i'): graph['58']=n('SaveImage',images=['8',0],filename_prefix=prefix)
    else:
        graph['57']=n('CreateVideo',images=['8',0],fps=p['fps'])
        graph['58']=n('SaveVideo',video=['57',0],filename_prefix=prefix,format='auto',codec='auto')
        spec=info.get('SaveVideo',{}).get('input',{}).get('required',{}).get('format',[])
        if spec and spec[0]=='COMFY_DYNAMICCOMBO_V3':
            graph['58']['inputs'].pop('codec')
            graph['58']['inputs']['format.codec']='auto'
    for node in graph.values():
        cls=node['class_type']
        if cls not in info: raise ValueError('Nœud ComfyUI manquant : '+cls)
        schema=info[cls].get('input',{})
        def expand(schema,prefix=''):
            required={prefix+k:v for k,v in schema.get('required',{}).items()}
            allowed={**required,**{prefix+k:v for k,v in schema.get('optional',{}).items()}}
            for key,spec in list(allowed.items()):
                if spec and spec[0]=='COMFY_DYNAMICCOMBO_V3':
                    selected=next((o for o in spec[1]['options'] if o['key']==node['inputs'].get(key)),None)
                    if selected:
                        req,extra=expand(selected['inputs'],key+'.');required.update(req);allowed.update(extra)
            return required,allowed
        required,allowed=expand(schema)
        # Some older releases do not expose optional device / temporal controls.
        for key in list(node['inputs']):
            if key not in allowed: del node['inputs'][key]
        absent=set(required)-set(node['inputs'])
        if absent: raise ValueError(f'Interface ComfyUI incompatible : {cls}, champs {sorted(absent)}. Consulter Diagnostic.')
    if p['engine']=='wan' and image_name and graph.get('55',{}).get('inputs',{}).get('start_image')!=['56',0]:
        raise ValueError('Le moteur ne propose pas la connexion de la photo de départ attendue.')
    return graph

# BAZOR_H3_CONTROLS_S21
from studio_h3_controls import unwrap_graph, patch_controls
