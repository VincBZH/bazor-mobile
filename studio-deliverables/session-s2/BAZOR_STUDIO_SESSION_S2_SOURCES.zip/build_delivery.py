from pathlib import Path
import base64,hashlib,io,json,zipfile
root=Path.cwd();fix=root/'fix';out=root/'deliverables';out.mkdir(exist_ok=True)
files=['apply_fix.py','installer.ps1','stop_studio_elevated.ps1','rollback.py','README.md','payload/studio_session_guard.py','payload/studio_h3_inventory.py','payload/studio_h3_controls.py','payload/session_ui.js','payload/studio_route_s23.py','payload/scene_ui_s23.js']
buf=io.BytesIO()
with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED) as z:
 for name in files:
  data=(fix/name).read_bytes()
  if name.endswith('.ps1'):data=b'\xef\xbb\xbf'+data
  z.writestr(name,data)
payload=buf.getvalue();digest=hashlib.sha256(payload).hexdigest()
ps="$ErrorActionPreference='Stop'; $self=$env:BAZOR_S2_SELF; $raw=[IO.File]::ReadAllText($self); $marker='::BAZOR_S2_DATA::'; $bytes=[Convert]::FromBase64String($raw.Substring($raw.LastIndexOf($marker)+$marker.Length).Trim()); $sha=[Security.Cryptography.SHA256]::Create(); $got=([BitConverter]::ToString($sha.ComputeHash($bytes))).Replace('-','').ToLower(); if($got -ne '"+digest+"'){throw 'Archive integree incomplete'}; $dest=Join-Path $env:TEMP ('BAZOR_SESSION_S2_'+[guid]::NewGuid().ToString('N')); New-Item -ItemType Directory -Path $dest | Out-Null; $zip=Join-Path $dest 'payload.zip'; [IO.File]::WriteAllBytes($zip,$bytes); Expand-Archive -LiteralPath $zip -DestinationPath $dest -Force; & (Join-Path $dest 'installer.ps1'); exit $LASTEXITCODE"
cmd='@echo off\r\nsetlocal EnableExtensions\r\nchcp 65001 >nul\r\ntitle BAZOR Studio - Correctif Session S2.3\r\nset "BAZOR_S2_SELF=%~f0"\r\npowershell.exe -NoProfile -ExecutionPolicy Bypass -Command "'+ps+'"\r\nset "BAZOR_S2_RC=%ERRORLEVEL%"\r\nif not "%BAZOR_S2_RC%"=="0" pause\r\nexit /b %BAZOR_S2_RC%\r\n::BAZOR_S2_DATA::\r\n'+base64.b64encode(payload).decode()+'\r\n'
(out/'BAZOR_STUDIO_SESSION_S2_1_CLIC.cmd').write_bytes(cmd.encode('ascii'))
receipt={'date':'2026-09-20','installer_revision':'S2.3','application_build':'3.0.5-session-s2.3','reported_windows_previous_attempt':'preflight_passed_stop_access_denied_before_application_writes','python_targeted_tests':50,'python_regression_tests':33,'javascript_unit_scenarios':20,'python_imports_verified':True,'python_syntax_verified':True,'javascript_syntax_verified':True,'browser_local':'NOT_EXECUTED_BROWSER_UNAVAILABLE','browser_ci':'PENDING_SEE_REPOSITORY_CI_RESULT','windows_installer_executed':False,'real_gpu_generation_tested':False,'embedded_payload_sha256':digest}
(fix/'VERIFICATION.json').write_text(json.dumps(receipt,indent=2))
with zipfile.ZipFile(out/'BAZOR_STUDIO_SESSION_S2_SOURCES.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in files+['test_session_s2.py','test_windows_stop.ps1','test_frontend.cjs','test_browser.cjs','tests-python.log','tests-regression.log','tests-frontend.log','VERIFICATION.json']:
  z.write(fix/name,'fix/'+name)
 # Include the exact tested source tree, no user databases or locally imported files.
 for p in (root/'work/studio/app').rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts:z.write(p,'work/studio/app/'+p.relative_to(root/'work/studio/app').as_posix())
 for p in (root/'work/studio/tests').glob('*'):
  if p.is_file():z.write(p,'work/studio/tests/'+p.name)
 z.write(root/'work/studio/release.json','work/studio/release.json')
 # Include every release-manifest file so a clean extraction passes startup.
 for name in json.loads((root/'work/studio/release.json').read_text())['files']:
  if not name.startswith(('app/','tests/')):
   z.write(root/'work/studio'/name,'work/studio/'+name)
 # Installation tests need original inputs; keep the supplied archive tree reproducible.
 base=root/'inspect/AI_Simple_Studio_BAZOR_V3_3.0.5_PLAYWRIGHT_INSTALL_FIX_20260917'
 for p in base.rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts:z.write(p,'inspect/'+base.name+'/'+p.relative_to(base).as_posix())
 z.write(out/'BAZOR_STUDIO_SESSION_S2_1_CLIC.cmd','BAZOR_STUDIO_SESSION_S2_1_CLIC.cmd')
 z.write(root/'build_delivery.py','build_delivery.py')
# Verify the actual self-extracting deliverable, not just its source.
stored=(out/'BAZOR_STUDIO_SESSION_S2_1_CLIC.cmd').read_text()
embedded=base64.b64decode(stored.rsplit('::BAZOR_S2_DATA::',1)[1].strip())
assert hashlib.sha256(embedded).hexdigest()==digest
with zipfile.ZipFile(io.BytesIO(embedded)) as z:assert z.testzip() is None;assert 'payload/studio_h3_inventory.py' in z.namelist()
for p in out.iterdir():print(p.name,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
